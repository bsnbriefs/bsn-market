# BSN Market — Master Development Guide & Specification

> **Tagline:** Your Community. Your Marketplace.  
> **Parent Network:** Barrister Street Network (BSN)  
> **Platform Target:** Mobile-First, Multi-Vendor E-Commerce Web Application for Nigeria (NGN ₦)

---

## 1. System Architecture Overview

BSN Market connects customers across Nigeria with verified independent retailers.

### Technology Stack
- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Canvas Confetti.
- **Backend Service:** Full-stack Express API with server-authoritative calculations, stock consistency, Paystack lifecycle verification, and audit logging.
- **Production Relational Schema & RLS:** PostgreSQL & Supabase migrations provided in `/supabase/migrations/20260320000000_bsn_market_schema.sql` with complete Row Level Security (RLS) policies.
- **Currency & Localization:** Nigerian Naira (NGN ₦) stored in Kobo (`price_kobo = NGN * 100`) to guarantee exact monetary representations rather than floating-point errors.
- **Payments:** Paystack payment integration structure supporting Card, Bank Transfer, and USSD with idempotent server verification.

---

## 2. Core User Roles & Workflows

### A. Customer
- **Discovery:** Browse and filter products without authentication by category, price, deals, and search queries.
- **Product Details:** High-resolution product showcase, variant selection (sizes/shades), stock limits, verified retailer badges, delivery & returns policies, and verified customer reviews.
- **Cart & Calculation:** Real-time multi-vendor package breakdown, coupon codes (`BSNWELCOME`, `LAGOSFREE`), and transparent delivery fee calculation.
- **Checkout & Escrow:** Nigerian addresses with State and LGA dropdowns, Paystack checkout popup simulation, and instant order creation.
- **Live Order Tracking:** Multi-stage timeline (`Order Placed` → `Payment Confirmed` → `Retailer Confirmed` → `Processing` → `Dispatched` → `Delivered`), tracking references, and cancellation/refund requests.

### B. Retailer Portal (e.g. Zaria Wears, Eko Gadgets Hub)
- **Overview Metrics:** Gross Merchandise Value (GMV), Orders Awaiting Confirmation, Orders In Processing, Completed Orders, Commission Deductions, Net Settlement Due, and Low-Stock warnings.
- **Order Fulfilment:** Independent sub-orders per vendor; actions to Confirm, Reject (with reason), Mark Packaging, and Dispatch to Nigerian couriers (GIG Logistics, Kwik, etc.) with tracking references.
- **Catalogue & Moderation:** Retailers create drafts and submit products for administrator moderation before public listing.
- **Settlement Statements:** Net payable records with bank account specifications.

### C. Administrator Dashboard (BSN Command Center)
- **Financial Integrity:** Transparently distinguishes Gross Merchandise Value (GMV), actual Platform Net Revenue (commission fees), Retailer Payable balances, and Refunds.
- **Retailer Moderation:** Inspect Corporate Affairs Commission (CAC) registrations, bank accounts, and business credentials; Approve, Reject, Suspend, or Reinstate.
- **Product Moderation Queue:** Review pending product submissions; Approve, Reject with reason, or Request correction.
- **Commission Policies:** Platform default rate (10%), category schedules, and retailer-specific negotiated overrides.
- **Settlement Payouts:** Record Nigerian bank transfers with NIP transaction session IDs.
- **Campaigns:** Create and manage discount coupon codes with minimum spends and caps.
- **Audit Logs:** Immutable audit stream of all sensitive actions.

---

## 3. Environment Variables Configuration

Copy `.env.example` to `.env` and fill in credentials:

```bash
# Application URL
APP_URL="https://your-domain.ng"

# Paystack API Keys (Nigeria)
VITE_PAYSTACK_PUBLIC_KEY="pk_test_xxxxxxxxxxxxxxxxxxxxxxxx"
PAYSTACK_SECRET_KEY="sk_test_xxxxxxxxxxxxxxxxxxxxxxxx"

# Supabase (PostgreSQL & Storage)
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-key"
SUPABASE_SERVICE_ROLE_KEY="your-service-role-key"

# Email Notifications (SMTP)
SMTP_HOST="smtp.mailprovider.com"
SMTP_PORT="587"
SMTP_USER="apikey"
SMTP_PASS="your-smtp-secret"
EMAIL_FROM="orders@bsnmarket.ng"
```

---

## 4. Local Development & Testing Instructions

### Prerequisites
- Node.js 20+
- npm or bun

### Commands
```bash
# 1. Install dependencies
npm install

# 2. Start full-stack development server on port 3000
npm run dev

# 3. Type check & Lint
npm run lint

# 4. Build for production
npm run build
```

### Testing User Journeys Locally
1. **Customer Checkout Flow:**
   - Add items from multiple retailers (e.g., *Structured Ankara Midi Dress* from Zaria Wears and *100W Braided Cable* from Eko Gadgets).
   - Open Cart, apply discount code `BSNWELCOME` (10% savings).
   - Proceed to Checkout, enter Nigerian address and phone number (`0803...`).
   - Click "Pay with Paystack", select Card or Bank Transfer, and click "Authorize Payment".
   - Confirm confetti celebration and live order tracking screen.
2. **Retailer Fulfilment Flow:**
   - In the top banner, switch the active persona to **Retailer Persona (Amina - Zaria Wears)**.
   - Click "Retailer Portal", review the new order awaiting confirmation.
   - Click "Confirm Order" → "Mark Packaging" → "Dispatch to Courier" with tracking number.
3. **Administrator Oversight Flow:**
   - Switch persona to **Administrator Persona**.
   - Review Platform Financials (GMV vs Platform Revenue vs Retailer Payable).
   - Review pending Retailer Applications and moderate new products.
   - Go to "Payouts & Settlements" and record a settlement payout with a Nigerian bank reference.

---

## 5. Deployment Guide

### Deploying to Cloud Run / Docker / VPS
1. Run `npm run build` to create static client assets in `dist/`.
2. Start the server using `node server.ts` (listens on `0.0.0.0:${PORT}`).

### Deploying Database Migrations to Supabase
1. Create a Supabase project at [supabase.com](https://supabase.com).
2. Go to SQL Editor in the Supabase dashboard.
3. Paste the contents of `/supabase/migrations/20260320000000_bsn_market_schema.sql` and run.
4. All tables, custom ENUMs, foreign keys, indexes, and Row Level Security (RLS) policies will be provisioned.
