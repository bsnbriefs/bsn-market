/**
 * BSN Market Full-Stack Express Server
 * Port 3000 entry point mounting API routes and Vite middleware
 */

import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { db } from './src/server/database.ts';

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // Default active user session simulation (or header auth)
  let currentUserId = 'user-customer-01';

  // Download Zipped Repository for GitHub deployment
  app.get('/api/download-zip', (_req, res) => {
    const zipPath = path.resolve(process.cwd(), 'bsn-market.zip');
    res.download(zipPath, 'bsn-market.zip', (err) => {
      if (err) {
        res.status(500).json({ error: 'Could not download zip file' });
      }
    });
  });

  // --- API ROUTES ---

  // Auth & Roles
  app.get('/api/auth/me', (req, res) => {
    const userId = (req.headers['x-user-id'] as string) || currentUserId;
    const user = db.findUserById(userId);
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }
    const retailer = user.role === 'retailer' ? db.getRetailerByOwnerId(user.id) : undefined;
    res.json({ user, retailer });
  });

  app.post('/api/auth/switch', (req, res) => {
    const { userId, role } = req.body;
    if (userId) {
      const user = db.findUserById(userId);
      if (user) {
        currentUserId = user.id;
        return res.json({ user });
      }
    }
    if (role) {
      const user = db.getUsers().find(u => u.role === role);
      if (user) {
        currentUserId = user.id;
        return res.json({ user });
      }
    }
    res.status(400).json({ error: 'User or role not found' });
  });

  app.post('/api/auth/register', (req, res) => {
    const { fullName, email, phoneNumber, role } = req.body;
    if (!fullName || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }
    const existing = db.findUserByEmail(email);
    if (existing) {
      return res.status(400).json({ error: 'Email already registered' });
    }
    const newUser = db.createUser({
      fullName,
      email,
      phoneNumber,
      role: role || 'customer'
    });
    currentUserId = newUser.id;
    res.status(201).json({ user: newUser });
  });

  // Categories
  app.get('/api/categories', (_req, res) => {
    res.json(db.getCategories());
  });

  app.get('/api/admin/categories', (_req, res) => {
    res.json(db.getAllCategoriesAdmin());
  });

  app.post('/api/admin/categories', (req, res) => {
    const { name, slug, description, displayOrder, defaultCommissionRate } = req.body;
    if (!name || !slug) return res.status(400).json({ error: 'Name and slug required' });
    const cat = db.createCategory({
      name,
      slug,
      description,
      displayOrder: displayOrder || 1,
      isActive: true,
      defaultCommissionRate: defaultCommissionRate || 10
    });
    res.status(201).json(cat);
  });

  app.put('/api/admin/categories/:id', (req, res) => {
    const updated = db.updateCategory(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Category not found' });
    res.json(updated);
  });

  // Products
  app.get('/api/products', (req, res) => {
    const { categoryId, search, minPrice, maxPrice, sortBy, retailerId, status } = req.query;
    const products = db.getProducts({
      categoryId: categoryId as string,
      search: search as string,
      minPriceKobo: minPrice ? Number(minPrice) * 100 : undefined,
      maxPriceKobo: maxPrice ? Number(maxPrice) * 100 : undefined,
      sortBy: sortBy as any,
      retailerId: retailerId as string,
      status: status as string
    });
    res.json(products);
  });

  app.get('/api/products/:id', (req, res) => {
    const product = db.getProductById(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  });

  app.post('/api/products/:id/reviews', (req, res) => {
    const { customerId, customerName, rating, title, comment } = req.body;
    if (!rating || !comment) return res.status(400).json({ error: 'Rating and comment required' });
    const review = db.addProductReview(req.params.id, {
      productId: req.params.id,
      customerId: customerId || currentUserId,
      customerName: customerName || 'Verified Customer',
      rating: Number(rating),
      title,
      comment,
      isVerifiedPurchase: true
    });
    if (!review) return res.status(404).json({ error: 'Product not found' });
    res.status(201).json(review);
  });

  // Cart & Calculation
  app.post('/api/cart/calculate', (req, res) => {
    const { items, discountCode } = req.body;
    if (!Array.isArray(items)) return res.status(400).json({ error: 'Items array required' });
    const calculation = db.calculateCart(items, discountCode);
    res.json(calculation);
  });

  // Orders
  app.post('/api/orders', (req, res) => {
    try {
      const order = db.createOrder(req.body);
      res.status(201).json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Could not place order' });
    }
  });

  app.get('/api/orders', (req, res) => {
    const { customerId } = req.query;
    const orders = db.getOrders({ customerId: (customerId as string) || currentUserId });
    res.json(orders);
  });

  app.get('/api/orders/:id', (req, res) => {
    const order = db.getOrderById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    res.json(order);
  });

  // Paystack Lifecycle
  app.post('/api/paystack/initialize', (req, res) => {
    try {
      const { orderId } = req.body;
      const paymentInit = db.initializePaystackPayment(orderId);
      res.json(paymentInit);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post('/api/paystack/verify', (req, res) => {
    try {
      const { reference, channel } = req.body;
      if (!reference) return res.status(400).json({ error: 'Reference required' });
      const result = db.verifyPaystackPayment(reference, channel || 'card');
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post('/api/paystack/webhook', (req, res) => {
    // Idempotent webhook receiver
    const event = req.body;
    if (event?.event === 'charge.success' && event.data?.reference) {
      db.verifyPaystackPayment(event.data.reference, event.data.channel || 'card');
    }
    res.sendStatus(200);
  });

  // Retailer Portal
  app.post('/api/retailer/apply', (req, res) => {
    const appData = db.submitRetailerApplication(req.body);
    res.status(201).json(appData);
  });

  app.get('/api/retailer/stats', (req, res) => {
    const { retailerId } = req.query;
    const targetRetailerId = (retailerId as string) || 'ret-zaria-01';
    const stats = db.getRetailerStats(targetRetailerId);
    res.json(stats);
  });

  app.get('/api/retailer/orders', (req, res) => {
    const { retailerId } = req.query;
    const targetRetailerId = (retailerId as string) || 'ret-zaria-01';
    const orders = db.getOrders({ retailerId: targetRetailerId });
    res.json(orders);
  });

  app.post('/api/retailer/orders/:id/action', (req, res) => {
    try {
      const { retailerId, action, reason, courierName, trackingReference } = req.body;
      const result = db.updateRetailerOrderStatus({
        retailerId: retailerId || 'ret-zaria-01',
        retailerOrderId: req.params.id,
        action,
        reason,
        courierName,
        trackingReference
      });
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get('/api/retailer/products', (req, res) => {
    const { retailerId } = req.query;
    const targetRetailerId = (retailerId as string) || 'ret-zaria-01';
    const prods = db.getProducts({ retailerId: targetRetailerId });
    res.json(prods);
  });

  app.post('/api/retailer/products', (req, res) => {
    const newProd = db.createProduct({
      ...req.body,
      status: 'under_review' // Retailer products go through moderation
    });
    res.status(201).json(newProd);
  });

  app.put('/api/retailer/products/:id', (req, res) => {
    const updated = db.updateProduct(req.params.id, req.body);
    if (!updated) return res.status(404).json({ error: 'Product not found' });
    res.json(updated);
  });

  // Admin Dashboard
  app.get('/api/admin/metrics', (_req, res) => {
    res.json(db.getPlatformMetrics());
  });

  app.get('/api/admin/retailer-applications', (_req, res) => {
    res.json(db.getRetailerApplications());
  });

  app.post('/api/admin/retailer-applications/:id/moderate', (req, res) => {
    const { status, rejectionReason } = req.body;
    const mod = db.moderateRetailerApplication(req.params.id, status, rejectionReason);
    if (!mod) return res.status(404).json({ error: 'Application not found' });
    res.json(mod);
  });

  app.get('/api/admin/retailers', (_req, res) => {
    res.json(db.getRetailers());
  });

  app.post('/api/admin/retailers/:id/status', (req, res) => {
    const { status } = req.body;
    const ret = db.updateRetailerStatus(req.params.id, status);
    if (!ret) return res.status(404).json({ error: 'Retailer not found' });
    res.json(ret);
  });

  app.get('/api/admin/products-moderation', (_req, res) => {
    const pending = db.getProducts({ status: 'under_review' });
    res.json(pending);
  });

  app.post('/api/admin/products/:id/moderate', (req, res) => {
    const { status, rejectionReason } = req.body;
    const prod = db.updateProduct(req.params.id, {
      status,
      rejectionReason: status === 'rejected' ? rejectionReason : undefined
    });
    if (!prod) return res.status(404).json({ error: 'Product not found' });
    res.json(prod);
  });

  app.get('/api/admin/settlements', (_req, res) => {
    res.json(db.getSettlements());
  });

  app.post('/api/admin/settlements', (req, res) => {
    try {
      const settlement = db.createSettlement(req.body);
      res.status(201).json(settlement);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get('/api/admin/audit-logs', (_req, res) => {
    res.json(db.getAuditLogs());
  });

  app.get('/api/admin/discount-codes', (_req, res) => {
    res.json(db.getDiscountCodes());
  });

  app.post('/api/admin/discount-codes', (req, res) => {
    const disc = db.createDiscountCode(req.body);
    res.status(201).json(disc);
  });

  // Notifications
  app.get('/api/notifications', (req, res) => {
    const userId = (req.query.userId as string) || currentUserId;
    res.json(db.getNotifications(userId));
  });

  app.post('/api/notifications/:id/read', (req, res) => {
    db.markNotificationRead(req.params.id);
    res.json({ success: true });
  });

  // Mount Vite or serve static assets
  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BSN Market full-stack server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start BSN Market server:', err);
  process.exit(1);
});
