/**
 * BSN Market - Master Application
 * Barrister Street Network (BSN) Multi-Vendor Marketplace for Nigeria
 * Tagline: "Your Community. Your Marketplace."
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  Filter,
  Sparkles,
  ShoppingBag,
  Store,
  ChevronDown,
  ArrowUpDown,
  CheckCircle,
  ShieldCheck,
  Tag,
  X
} from 'lucide-react';
import {
  UserProfile,
  RetailerProfile,
  Category,
  Product,
  CartItem,
  Order,
  InAppNotification
} from './types/index.ts';
import { api } from './services/api.ts';
import { Header } from './components/Header.tsx';
import { MobileNav } from './components/MobileNav.tsx';
import { HeroBanner } from './components/HeroBanner.tsx';
import { CategoryBar } from './components/CategoryBar.tsx';
import { ProductCard } from './components/ProductCard.tsx';
import { ProductDetailModal } from './components/ProductDetailModal.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { CheckoutModal } from './components/CheckoutModal.tsx';
import { PaystackModal } from './components/PaystackModal.tsx';
import { OrderTrackingModal } from './components/OrderTrackingModal.tsx';
import { RetailerPortal } from './components/RetailerPortal.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { RetailerApplicationModal } from './components/RetailerApplicationModal.tsx';
import { CustomerAccountModal } from './components/CustomerAccountModal.tsx';
import { PolicyModal } from './components/PolicyModal.tsx';
import { Footer } from './components/Footer.tsx';
import { formatNaira } from './utils/format.ts';

export default function App() {
  // Session & User Data
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [currentRetailer, setCurrentRetailer] = useState<RetailerProfile | null>(null);
  const [notifications, setNotifications] = useState<InAppNotification[]>([]);

  // Marketplace Catalog
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters & Search
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc' | 'rating'>('newest');
  const [showOnlyDeals, setShowOnlyDeals] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Cart & Orders
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem('bsn_cart');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [appliedDiscountCode, setAppliedDiscountCode] = useState('BSNWELCOME');
  const [cartCalculation, setCartCalculation] = useState({
    subtotalKobo: 0,
    deliveryFeeKobo: 0,
    discountKobo: 0,
    totalKobo: 0,
    retailerCount: 0
  });

  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);

  // Modals & Panels
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isRetailerPortalOpen, setIsRetailerPortalOpen] = useState(false);
  const [isAdminPortalOpen, setIsAdminPortalOpen] = useState(false);
  const [isRetailerApplyOpen, setIsRetailerApplyOpen] = useState(false);
  const [activeTrackingOrder, setActiveTrackingOrder] = useState<Order | null>(null);
  const [policyTopic, setPolicyTopic] = useState<'delivery' | 'returns' | 'terms' | 'privacy' | 'retailer_terms' | null>(null);

  // Paystack Modal State
  const [paystackSession, setPaystackSession] = useState<{
    isOpen: boolean;
    orderReference: string;
    amountKobo: number;
    email: string;
    paymentReference: string;
  } | null>(null);

  // Mobile Bottom Nav Active Tab
  const [mobileTab, setMobileTab] = useState('home');

  // Load Initial Session & Catalog Data
  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [authData, catList, prodList] = await Promise.all([
        api.getMe(),
        api.getCategories(),
        api.getProducts()
      ]);

      setCurrentUser(authData.user);
      if (authData.retailer) setCurrentRetailer(authData.retailer);
      setCategories(catList);
      setProducts(prodList);

      // Load user notifications and orders
      if (authData.user) {
        const [notifList, ordersList] = await Promise.all([
          api.getNotifications(authData.user.id),
          api.getCustomerOrders(authData.user.id)
        ]);
        setNotifications(notifList);
        setCustomerOrders(ordersList);
      }
    } catch (err) {
      console.error('Failed to initialize BSN Market data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadInitialData();
  }, []);

  // Persist cart to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bsn_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.warn('Could not store cart in localStorage', e);
    }
  }, [cartItems]);

  // Recalculate cart authoritatively on the server
  useEffect(() => {
    if (cartItems.length === 0) {
      setCartCalculation({
        subtotalKobo: 0,
        deliveryFeeKobo: 0,
        discountKobo: 0,
        totalKobo: 0,
        retailerCount: 0
      });
      return;
    }

    const payload = cartItems.map(it => ({
      productId: it.productId,
      variantId: it.variantId,
      quantity: it.quantity
    }));

    api.calculateCart(payload, appliedDiscountCode)
      .then(res => {
        setCartCalculation({
          subtotalKobo: res.subtotalKobo,
          deliveryFeeKobo: res.deliveryFeeKobo,
          discountKobo: res.discountKobo,
          totalKobo: res.totalKobo,
          retailerCount: res.retailerCount
        });
      })
      .catch(err => {
        console.error('Cart calculation error:', err);
      });
  }, [cartItems, appliedDiscountCode]);

  // Role persona switcher for evaluation & testing
  const handleSwitchRole = async (role: 'customer' | 'retailer' | 'admin') => {
    try {
      const res = await api.switchRole(role);
      setCurrentUser(res.user);
      if (role === 'retailer') {
        const ret = await api.getMe();
        if (ret.retailer) setCurrentRetailer(ret.retailer);
      }
      const [notifs, ords] = await Promise.all([
        api.getNotifications(res.user.id),
        api.getCustomerOrders(res.user.id)
      ]);
      setNotifications(notifs);
      setCustomerOrders(ords);
    } catch (err) {
      console.error(err);
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product, variantId?: string, quantity: number = 1) => {
    setCartItems(prev => {
      const existingIdx = prev.findIndex(
        it => it.productId === product.id && it.variantId === variantId
      );

      let unitPrice = product.priceKobo;
      let variantName: string | undefined;

      if (variantId && product.variants) {
        const v = product.variants.find(varItem => varItem.id === variantId);
        if (v) {
          unitPrice = v.priceKobo;
          variantName = v.name;
        }
      }

      if (existingIdx > -1) {
        const next = [...prev];
        next[existingIdx].quantity += quantity;
        return next;
      } else {
        const newItem: CartItem = {
          id: `ci-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          productId: product.id,
          product,
          variantId,
          variantName,
          quantity,
          unitPriceKobo: unitPrice
        };
        return [...prev, newItem];
      }
    });

    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, variantId: string | undefined, delta: number) => {
    setCartItems(prev => {
      return prev
        .map(it => {
          if (it.productId === productId && it.variantId === variantId) {
            const nextQty = it.quantity + delta;
            return nextQty > 0 ? { ...it, quantity: nextQty } : null;
          }
          return it;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveFromCart = (productId: string, variantId?: string) => {
    setCartItems(prev => prev.filter(it => !(it.productId === productId && it.variantId === variantId)));
  };

  const handleApplyDiscountCode = async (code: string) => {
    try {
      const calc = await api.calculateCart(
        cartItems.map(it => ({ productId: it.productId, variantId: it.variantId, quantity: it.quantity })),
        code
      );
      if (calc.discountKobo > 0) {
        setAppliedDiscountCode(code);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  // Instant Checkout shortcut
  const handleBuyNow = (product: Product, variantId?: string, quantity: number = 1) => {
    handleAddToCart(product, variantId, quantity);
    setSelectedProduct(null);
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Place Order and Initialize Paystack Lifecycle
  const handlePlaceOrderAndPay = async (orderPayload: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryCity: string;
    deliveryState: string;
    deliveryInstructions?: string;
    deliveryMethod: 'standard' | 'express' | 'pickup';
  }) => {
    if (!currentUser) throw new Error('Customer required');

    // Step 1: Create Order Server-Side
    const newOrder = await api.createOrder({
      customerId: currentUser.id,
      customerName: orderPayload.customerName,
      customerEmail: orderPayload.customerEmail,
      customerPhone: orderPayload.customerPhone,
      deliveryAddress: orderPayload.deliveryAddress,
      deliveryCity: orderPayload.deliveryCity,
      deliveryState: orderPayload.deliveryState,
      deliveryInstructions: orderPayload.deliveryInstructions,
      deliveryMethod: orderPayload.deliveryMethod,
      items: cartItems.map(it => ({
        productId: it.productId,
        variantId: it.variantId,
        quantity: it.quantity
      })),
      discountCode: appliedDiscountCode
    });

    // Step 2: Initialize Paystack Payment Reference
    const payInit = await api.initializePayment(newOrder.id);

    // Step 3: Open Paystack Checkout Dialog
    setIsCheckoutOpen(false);
    setPaystackSession({
      isOpen: true,
      orderReference: newOrder.orderReference,
      amountKobo: newOrder.totalKobo,
      email: newOrder.customerEmail,
      paymentReference: payInit.reference
    });
  };

  // Handle Paystack Payment Success
  const handlePaymentSuccess = (verifiedOrder: Order) => {
    setPaystackSession(null);
    setCartItems([]);
    setCustomerOrders(prev => [verifiedOrder, ...prev]);
    setActiveTrackingOrder(verifiedOrder);

    // Refresh catalog products (for decremented stock counts)
    api.getProducts().then(setProducts);
  };

  // Review submission
  const handleSubmitReview = async (productId: string, review: { rating: number; title?: string; comment: string }) => {
    if (!currentUser) return;
    await api.submitReview(productId, {
      ...review,
      customerName: currentUser.fullName
    });
    const updatedProd = await api.getProductById(productId);
    setSelectedProduct(updatedProd);
    setProducts(prev => prev.map(p => (p.id === productId ? updatedProd : p)));
  };

  // Filtered & Sorted Products
  const filteredProducts = useMemo(() => {
    let prods = [...products];

    if (selectedCategoryId !== 'all') {
      prods = prods.filter(p => p.categoryId === selectedCategoryId);
    }

    if (showOnlyDeals) {
      prods = prods.filter(p => p.compareAtPriceKobo && p.compareAtPriceKobo > p.priceKobo);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      prods = prods.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.categoryName.toLowerCase().includes(q) ||
          p.retailerName.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'price_asc') {
      prods.sort((a, b) => a.priceKobo - b.priceKobo);
    } else if (sortBy === 'price_desc') {
      prods.sort((a, b) => b.priceKobo - a.priceKobo);
    } else if (sortBy === 'rating') {
      prods.sort((a, b) => b.rating - a.rating);
    } else {
      prods.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return prods;
  }, [products, selectedCategoryId, showOnlyDeals, searchQuery, sortBy]);

  const totalCartCount = cartItems.reduce((sum, it) => sum + it.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      {/* Top Header */}
      <Header
        user={currentUser}
        retailer={currentRetailer}
        cartCount={totalCartCount}
        notifications={notifications}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
        onOpenRetailerPortal={() => setIsRetailerPortalOpen(true)}
        onOpenAdminPortal={() => setIsAdminPortalOpen(true)}
        onOpenRetailerApply={() => setIsRetailerApplyOpen(true)}
        onSwitchRole={handleSwitchRole}
        onNavigate={(section) => {
          if (section === 'home') {
            setSelectedCategoryId('all');
            setShowOnlyDeals(false);
            setSearchQuery('');
          } else if (section === 'deals') {
            setShowOnlyDeals(true);
            setSelectedCategoryId('all');
          } else if (section === 'categories') {
            setSelectedCategoryId('all');
          } else if (section === 'retailers') {
            // Filter by first retailer or show all
          }
        }}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16 md:pb-8">
        {/* Hero Section */}
        <HeroBanner
          onStartShopping={() => {
            setShowOnlyDeals(false);
            const el = document.getElementById('catalog-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreDeals={() => {
            setShowOnlyDeals(true);
            const el = document.getElementById('catalog-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Dynamic Category Bar */}
        <CategoryBar
          categories={categories}
          selectedCategoryId={selectedCategoryId}
          onSelectCategory={(id) => {
            setSelectedCategoryId(id);
            setShowOnlyDeals(false);
          }}
        />

        {/* Search Modal / Inline Bar */}
        {isSearchOpen && (
          <div className="bg-white border-b border-slate-200 p-4 transition-all">
            <div className="max-w-3xl mx-auto flex items-center gap-3">
              <Search className="w-5 h-5 text-slate-400 shrink-0" />
              <input
                type="text"
                autoFocus
                placeholder="Search products, brands (e.g. Kaftan, USB-C, Shea butter, Honey)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-sm outline-none text-slate-800 placeholder-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="p-1 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={() => setIsSearchOpen(false)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* Catalog Showcase Section */}
        <section id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-8 py-8 sm:py-12">
          {/* Section Header & Filters Toolbar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                  {showOnlyDeals
                    ? 'BSN Exclusive Deals'
                    : selectedCategoryId !== 'all'
                    ? categories.find(c => c.id === selectedCategoryId)?.name
                    : 'Curated Marketplace Collection'}
                </h2>
                <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {filteredProducts.length} items
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Authentic merchandise shipped directly from independent Nigerian businesses
              </p>
            </div>

            {/* Filter & Sort Controls */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Deals Toggle */}
              <button
                onClick={() => setShowOnlyDeals(!showOnlyDeals)}
                className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 border ${
                  showOnlyDeals
                    ? 'bg-red-600 text-white border-red-600 shadow-sm'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Deals Only</span>
              </button>

              {/* Sort Dropdown */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="min-h-[40px] appearance-none bg-white text-slate-700 text-xs font-semibold pl-3 pr-8 py-1.5 rounded-lg border border-slate-200 focus:outline-none hover:border-slate-300 cursor-pointer"
                >
                  <option value="newest">Sort: Newly Listed</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Product Grid */}
          {isLoading ? (
            <div className="py-24 text-center text-slate-400 text-sm">
              Loading BSN Marketplace collection...
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-20 text-center bg-white rounded-2xl border border-slate-200 p-8">
              <ShoppingBag className="w-12 h-12 stroke-1 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-800">No products match your criteria</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Try clearing your search terms, removing the deals filter, or selecting a different category.
              </p>
              <button
                onClick={() => {
                  setSelectedCategoryId('all');
                  setShowOnlyDeals(false);
                  setSearchQuery('');
                }}
                className="mt-4 px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg hover:bg-slate-800"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {filteredProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onSelect={setSelectedProduct}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          )}
        </section>

        {/* Verified Nigerian Retailers Showcase Section */}
        <section className="bg-white border-y border-slate-200 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
              <div>
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900">
                  Featured Nigerian Retailers
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  Every retailer on BSN Market undergoes business verification and CAC validation.
                </p>
              </div>
              <button
                onClick={() => setIsRetailerApplyOpen(true)}
                className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1"
              >
                <span>Register your store on BSN Market →</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">Zaria Wears & Textiles</span>
                  <span className="text-[10px] bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded">
                    Ikeja, Lagos
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Contemporary Nigerian ready-to-wear, structured linen formal wear, and bespoke Ankara tailoring.
                </p>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                  <span>CAC Verified: RC-1849204</span>
                  <span className="font-semibold text-slate-800">4.9 ★ (38 orders)</span>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">Eko Gadgets Hub</span>
                  <span className="text-[10px] bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded">
                    Computer Village, Lagos
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Direct importer of durable smartphone accessories, braided high-power cables, and certified audio.
                </p>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                  <span>CAC Verified: RC-2049100</span>
                  <span className="font-semibold text-slate-800">4.8 ★ (52 orders)</span>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">Kano Heritage Pantry</span>
                  <span className="text-[10px] bg-red-100 text-red-700 font-bold px-2 py-0.5 rounded">
                    Fagge, Kano
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Authentic northern Nigerian spices, raw unpasteurized acacia honey, and gourmet roasted cashews.
                </p>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                  <span>CAC Verified: RC-992140</span>
                  <span className="font-semibold text-slate-800">4.9 ★ (29 orders)</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer
        onOpenPolicy={(topic) => setPolicyTopic(topic)}
        onOpenRetailerApply={() => setIsRetailerApplyOpen(true)}
        onOpenAdminPortal={() => setIsAdminPortalOpen(true)}
        onOpenRetailerPortal={() => setIsRetailerPortalOpen(true)}
      />

      {/* Mobile Bottom Navigation Bar */}
      <MobileNav
        currentTab={mobileTab}
        cartCount={totalCartCount}
        onSelectTab={(tab) => {
          setMobileTab(tab);
          if (tab === 'home') {
            setSelectedCategoryId('all');
            setShowOnlyDeals(false);
          } else if (tab === 'categories') {
            // Scroll to category strip
            const el = document.getElementById('catalog-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          } else if (tab === 'deals') {
            setShowOnlyDeals(true);
            const el = document.getElementById('catalog-section');
            el?.scrollIntoView({ behavior: 'smooth' });
          }
        }}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAccount={() => setIsAccountOpen(true)}
      />

      {/* MODAL: Product Details PDP */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
          onBuyNow={handleBuyNow}
          onSubmitReview={handleSubmitReview}
        />
      )}

      {/* DRAWER: Shopping Cart */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        appliedDiscountCode={appliedDiscountCode}
        onApplyDiscountCode={handleApplyDiscountCode}
        subtotalKobo={cartCalculation.subtotalKobo}
        deliveryFeeKobo={cartCalculation.deliveryFeeKobo}
        discountKobo={cartCalculation.discountKobo}
        totalKobo={cartCalculation.totalKobo}
      />

      {/* MODAL: Checkout Experience */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cartItems}
        subtotalKobo={cartCalculation.subtotalKobo}
        deliveryFeeKobo={cartCalculation.deliveryFeeKobo}
        discountKobo={cartCalculation.discountKobo}
        totalKobo={cartCalculation.totalKobo}
        appliedDiscountCode={appliedDiscountCode}
        defaultCustomerName={currentUser?.fullName || ''}
        defaultEmail={currentUser?.email || ''}
        defaultPhone={currentUser?.phoneNumber || ''}
        onPlaceOrderAndPay={handlePlaceOrderAndPay}
      />

      {/* MODAL: Paystack Gateway Simulation */}
      {paystackSession && (
        <PaystackModal
          isOpen={paystackSession.isOpen}
          onClose={() => setPaystackSession(null)}
          orderReference={paystackSession.orderReference}
          amountKobo={paystackSession.amountKobo}
          email={paystackSession.email}
          paymentReference={paystackSession.paymentReference}
          onPaymentSuccess={handlePaymentSuccess}
          onVerifyPayment={(ref, channel) => api.verifyPayment(ref, channel)}
        />
      )}

      {/* MODAL: Order Tracking */}
      {activeTrackingOrder && (
        <OrderTrackingModal
          order={activeTrackingOrder}
          onClose={() => setActiveTrackingOrder(null)}
          onRequestRefund={async (ordId, reason) => {
            // Log refund request
            alert('Refund request logged. An administrator will review your ticket within 24 hours.');
          }}
        />
      )}

      {/* MODAL: Retailer Portal */}
      {isRetailerPortalOpen && (
        <RetailerPortal
          retailer={currentRetailer}
          onClose={() => setIsRetailerPortalOpen(false)}
          categories={categories}
        />
      )}

      {/* MODAL: Administrator Command Center */}
      {isAdminPortalOpen && (
        <AdminDashboard
          onClose={() => setIsAdminPortalOpen(false)}
          categories={categories}
          onRefreshCategories={() => api.getCategories().then(setCategories)}
        />
      )}

      {/* MODAL: Retailer Registration */}
      <RetailerApplicationModal
        isOpen={isRetailerApplyOpen}
        onClose={() => setIsRetailerApplyOpen(false)}
        userId={currentUser?.id || 'user-customer-01'}
      />

      {/* MODAL: Customer Account */}
      <CustomerAccountModal
        isOpen={isAccountOpen}
        onClose={() => setIsAccountOpen(false)}
        user={currentUser}
        orders={customerOrders}
        notifications={notifications}
        onSelectOrder={(ord) => setActiveTrackingOrder(ord)}
        onMarkNotificationRead={(id) => api.markNotificationRead(id)}
      />

      {/* MODAL: Policies */}
      <PolicyModal
        isOpen={policyTopic !== null}
        onClose={() => setPolicyTopic(null)}
        initialTopic={policyTopic || 'delivery'}
      />
    </div>
  );
}
