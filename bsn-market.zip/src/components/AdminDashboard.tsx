/**
 * BSN Market Administrator Dashboard
 * Section 6: Oversight, financial integrity, retailer moderation, product reviews, and commission settings
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  TrendingUp,
  Store,
  Package,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  Tag,
  Sliders,
  FileText,
  AlertTriangle,
  RotateCcw,
  Check,
  X
} from 'lucide-react';
import {
  PlatformMetrics,
  RetailerApplication,
  RetailerProfile,
  Product,
  RetailerSettlement,
  AuditLogEntry,
  DiscountCode,
  Category
} from '../types/index.ts';
import { formatNaira, formatDate, STATUS_CONFIG } from '../utils/format.ts';
import { api } from '../services/api.ts';

interface AdminDashboardProps {
  onClose: () => void;
  categories: Category[];
  onRefreshCategories: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onClose,
  categories,
  onRefreshCategories
}) => {
  const [activeTab, setActiveTab] = useState<
    'metrics' | 'applications' | 'moderation' | 'retailers' | 'settlements' | 'commissions' | 'discounts' | 'audits'
  >('metrics');

  const [metrics, setMetrics] = useState<PlatformMetrics | null>(null);
  const [applications, setApplications] = useState<RetailerApplication[]>([]);
  const [moderationProducts, setModerationProducts] = useState<Product[]>([]);
  const [retailers, setRetailers] = useState<RetailerProfile[]>([]);
  const [settlements, setSettlements] = useState<RetailerSettlement[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [discountCodes, setDiscountCodes] = useState<DiscountCode[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Settlement creation form
  const [settleRetailerId, setSettleRetailerId] = useState('');
  const [settleBankRef, setSettleBankRef] = useState('');
  const [settleNotes, setSettleNotes] = useState('');
  const [isProcessingSettlement, setIsProcessingSettlement] = useState(false);

  // Discount code creation
  const [newCodeName, setNewCodeName] = useState('');
  const [newCodeType, setNewCodeType] = useState<'percentage' | 'fixed_kobo'>('percentage');
  const [newCodeVal, setNewCodeVal] = useState('10');
  const [newCodeMin, setNewCodeMin] = useState('15000');
  const [isCreatingDiscount, setIsCreatingDiscount] = useState(false);

  // Rejection reason prompt
  const [rejectItemType, setRejectItemType] = useState<'app' | 'prod' | null>(null);
  const [rejectItemId, setRejectItemId] = useState<string | null>(null);
  const [rejectReasonText, setRejectReasonText] = useState('');

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [m, a, p, r, s, l, d] = await Promise.all([
        api.getAdminMetrics(),
        api.getRetailerApplications(),
        api.getProductsForModeration(),
        api.getAdminRetailers(),
        api.getSettlements(),
        api.getAuditLogs(),
        api.getDiscountCodes()
      ]);
      setMetrics(m);
      setApplications(a);
      setModerationProducts(p);
      setRetailers(r);
      setSettlements(s);
      setAuditLogs(l);
      setDiscountCodes(d);
      if (r.length > 0) setSettleRetailerId(r[0].id);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleModerateApplication = async (id: string, status: 'approved' | 'rejected', reason?: string) => {
    try {
      await api.moderateRetailerApplication(id, status, reason);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    }
  };

  const handleModerateProduct = async (id: string, status: 'approved' | 'rejected', reason?: string) => {
    try {
      await api.moderateProduct(id, status, reason);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    }
  };

  const handleExecuteSettlement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settleRetailerId || !settleBankRef.trim()) return;
    setIsProcessingSettlement(true);
    try {
      await api.createSettlement({
        retailerId: settleRetailerId,
        bankTransferReference: settleBankRef.trim(),
        notes: settleNotes.trim() || undefined
      });
      setSettleBankRef('');
      setSettleNotes('');
      await loadData();
      alert('Settlement successfully recorded!');
    } catch (err: any) {
      alert(err.message || 'Settlement failed');
    } finally {
      setIsProcessingSettlement(false);
    }
  };

  const handleCreateDiscount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCodeName.trim()) return;
    setIsCreatingDiscount(true);
    try {
      await api.createDiscountCode({
        code: newCodeName.trim().toUpperCase(),
        discountType: newCodeType,
        value: Number(newCodeVal),
        minOrderKobo: Math.round(Number(newCodeMin) * 100),
        usageLimit: 250,
        isActive: true
      });
      setNewCodeName('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to create discount code');
    } finally {
      setIsCreatingDiscount(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex justify-center p-3 sm:p-6">
      <div className="relative bg-white rounded-2xl max-w-6xl w-full max-h-[92vh] overflow-hidden shadow-2xl flex flex-col border border-slate-200">
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>BSN Market Administrator Command Center</span>
                <span className="text-[10px] bg-red-500/20 text-red-300 font-bold px-2 py-0.5 rounded border border-red-500/30">
                  PLATFORM OVERSIGHT
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Barrister Street Network (BSN) Multi-Vendor Governance & Financial Controls
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 flex items-center gap-1 overflow-x-auto text-xs font-semibold shrink-0">
          <button
            onClick={() => setActiveTab('metrics')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'metrics'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Platform Financials
          </button>
          <button
            onClick={() => setActiveTab('applications')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'applications'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Retailer Applications</span>
            {metrics && metrics.pendingApplicationsCount > 0 && (
              <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full tabular-nums">
                {metrics.pendingApplicationsCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'moderation'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Product Moderation</span>
            {metrics && metrics.productsAwaitingReviewCount > 0 && (
              <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full tabular-nums">
                {metrics.productsAwaitingReviewCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('retailers')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'retailers'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Verified Retailers ({retailers.length})
          </button>
          <button
            onClick={() => setActiveTab('settlements')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'settlements'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Payouts & Settlements
          </button>
          <button
            onClick={() => setActiveTab('commissions')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'commissions'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Commission Policies
          </button>
          <button
            onClick={() => setActiveTab('discounts')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'discounts'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Discount Campaigns
          </button>
          <button
            onClick={() => setActiveTab('audits')}
            className={`py-3 px-3.5 border-b-2 transition-colors ${
              activeTab === 'audits'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Audit Trail
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="py-20 text-center text-slate-400">Loading admin data...</div>
          ) : (
            <>
              {/* TAB 1: FINANCIALS */}
              {activeTab === 'metrics' && metrics && (
                <div className="space-y-6">
                  {/* Strict Distinction: Gross vs Net Revenue vs Payables */}
                  <div className="p-4 bg-red-50/70 border border-red-200 rounded-xl text-xs text-red-900 flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <div>
                      <strong>Financial Integrity Rule:</strong> BSN Marketplace distinguishes Gross Merchandise Value (GMV) from actual platform commission earnings. Retailer sales belong to independent merchants until settled.
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="text-xs text-slate-500 font-medium">Gross Merchandise Value (GMV)</div>
                      <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                        {formatNaira(metrics.gmvKobo)}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">Total customer checkout value</div>
                    </div>

                    <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200">
                      <div className="text-xs text-emerald-800 font-medium">Platform Net Revenue</div>
                      <div className="text-2xl font-bold text-emerald-900 mt-1 tabular-nums">
                        {formatNaira(metrics.platformNetRevenueKobo)}
                      </div>
                      <div className="text-[11px] text-emerald-700 mt-1">BSN commission earned</div>
                    </div>

                    <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
                      <div className="text-xs text-blue-800 font-medium">Retailer Payable Balance</div>
                      <div className="text-2xl font-bold text-blue-900 mt-1 tabular-nums">
                        {formatNaira(metrics.retailerPayableKobo)}
                      </div>
                      <div className="text-[11px] text-blue-700 mt-1">Due for merchant settlement</div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="text-xs text-slate-500 font-medium">Total Orders Handled</div>
                      <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums">
                        {metrics.totalOrdersCount}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">{metrics.completedOrdersCount} delivered · {metrics.pendingOrdersCount} pending</div>
                    </div>
                  </div>

                  {/* Operational Metrics */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900 mb-1">Active Retailers</div>
                      <div className="text-2xl font-extrabold text-slate-900">{metrics.activeRetailersCount}</div>
                      <div className="text-slate-500 mt-1">Vetted Nigerian vendors selling online</div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900 mb-1">Applications Awaiting Review</div>
                      <div className="text-2xl font-extrabold text-amber-700">{metrics.pendingApplicationsCount}</div>
                      <div className="text-slate-500 mt-1">CAC documents pending verification</div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                      <div className="font-bold text-slate-900 mb-1">Products in Moderation</div>
                      <div className="text-2xl font-extrabold text-purple-700">{metrics.productsAwaitingReviewCount}</div>
                      <div className="text-slate-500 mt-1">Submitted items pending quality check</div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: RETAILER APPLICATIONS */}
              {activeTab === 'applications' && (
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Vendor Registration Pipeline ({applications.length})
                  </h3>

                  {applications.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs">No pending applications</div>
                  ) : (
                    <div className="space-y-3">
                      {applications.map((app) => (
                        <div
                          key={app.id}
                          className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs"
                        >
                          <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-2">
                            <div>
                              <span className="font-bold text-slate-900 text-sm">{app.businessName}</span>
                              <span className="text-slate-500 ml-2">({app.businessType})</span>
                            </div>
                            <span className="font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 uppercase text-[10px]">
                              {app.status}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-slate-600">
                            <div>CAC Reg: <strong className="text-slate-900 font-mono">{app.cacRegNumber || 'N/A'}</strong></div>
                            <div>Contact: <strong className="text-slate-900">{app.contactPerson}</strong></div>
                            <div>Phone: <strong className="text-slate-900">{app.phone}</strong></div>
                            <div>Location: <strong className="text-slate-900">{app.city}, {app.state}</strong></div>
                          </div>

                          <div className="p-3 bg-white rounded-lg border border-slate-200 text-slate-700">
                            Settlement Bank: <strong>{app.bankName}</strong> · Acc: <strong className="font-mono">{app.bankAccountNumber}</strong> ({app.bankAccountName})
                          </div>

                          {app.status === 'pending_review' && (
                            <div className="flex items-center gap-2 pt-2">
                              <button
                                onClick={() => handleModerateApplication(app.id, 'approved')}
                                className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 flex items-center gap-1"
                              >
                                <Check className="w-3.5 h-3.5" /> Approve Retailer
                              </button>
                              <button
                                onClick={() => {
                                  const reason = prompt('Reason for rejection:');
                                  if (reason) handleModerateApplication(app.id, 'rejected', reason);
                                }}
                                className="px-4 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg font-semibold hover:bg-rose-100"
                              >
                                Reject with Reason
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: PRODUCT MODERATION */}
              {activeTab === 'moderation' && (
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Products Awaiting Administrator Approval ({moderationProducts.length})
                  </h3>

                  {moderationProducts.length === 0 ? (
                    <div className="p-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      All products have been moderated. Moderation queue is clear!
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {moderationProducts.map((p) => (
                        <div
                          key={p.id}
                          className="p-5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row gap-4 text-xs"
                        >
                          <div className="w-24 h-24 rounded-lg overflow-hidden bg-slate-200 shrink-0 border border-slate-200">
                            <img
                              src={p.images[0]}
                              alt={p.name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          <div className="flex-1 space-y-2">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-bold text-slate-900 text-sm">{p.name}</h4>
                                <span className="text-slate-500">Retailer: <strong>{p.retailerName}</strong> · Category: {p.categoryName}</span>
                              </div>
                              <span className="font-bold text-base text-slate-900 tabular-nums">
                                {formatNaira(p.priceKobo)}
                              </span>
                            </div>

                            <p className="text-slate-600 line-clamp-2">{p.description}</p>

                            <div className="flex items-center gap-2 pt-2">
                              <button
                                onClick={() => handleModerateProduct(p.id, 'approved')}
                                className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700 flex items-center gap-1"
                              >
                                <Check className="w-3.5 h-3.5" /> Approve Listing
                              </button>
                              <button
                                onClick={() => {
                                  const reason = prompt('Reason for product rejection:');
                                  if (reason) handleModerateProduct(p.id, 'rejected', reason);
                                }}
                                className="px-4 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg font-semibold hover:bg-rose-100"
                              >
                                Reject with Reason
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: VERIFIED RETAILERS */}
              {activeTab === 'retailers' && (
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Active Platform Merchants ({retailers.length})
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {retailers.map((r) => (
                      <div
                        key={r.id}
                        className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs"
                      >
                        <div className="flex items-center justify-between border-b pb-2">
                          <span className="font-bold text-slate-900 text-sm">{r.businessName}</span>
                          <span className="font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px]">
                            {r.status.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-slate-600">{r.description}</p>
                        <div className="text-slate-500">
                          Location: {r.city}, {r.state} · Tel: {r.phone}
                        </div>
                        <div className="flex items-center justify-between pt-2 border-t text-slate-700">
                          <span>Negotiated Commission: <strong>{r.commissionRateOverride || 10}%</strong></span>
                          <span>Rating: <strong>{r.rating} ★</strong></span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: PAYOUTS & SETTLEMENTS */}
              {activeTab === 'settlements' && (
                <div className="space-y-6">
                  {/* Payout Batch Execution Form */}
                  <form onSubmit={handleExecuteSettlement} className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4 text-xs">
                    <h3 className="font-bold text-slate-900 text-sm">
                      Execute Retailer Settlement Transfer
                    </h3>
                    <p className="text-slate-600">
                      Record an authorized Nigerian bank transfer payment for a retailer's fulfilled sub-orders.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Select Retailer *</label>
                        <select
                          value={settleRetailerId}
                          onChange={(e) => setSettleRetailerId(e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg bg-white"
                        >
                          {retailers.map((r) => (
                            <option key={r.id} value={r.id}>{r.businessName} ({r.bankName})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Bank Transfer Reference / Session ID *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. NIP-20260309-8472919"
                          value={settleBankRef}
                          onChange={(e) => setSettleBankRef(e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isProcessingSettlement}
                      className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 shadow-sm disabled:opacity-50"
                    >
                      {isProcessingSettlement ? 'Recording Transfer...' : 'Mark Settlement Paid'}
                    </button>
                  </form>

                  {/* Existing Settlement Records */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3">
                      Settlement Payout History ({settlements.length})
                    </h4>
                    {settlements.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 text-xs">No settlements recorded yet</div>
                    ) : (
                      <div className="space-y-3">
                        {settlements.map((s) => (
                          <div
                            key={s.id}
                            className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="font-bold text-slate-900">{s.retailerName} · {s.settlementReference}</div>
                              <div className="text-slate-500 mt-0.5">
                                Bank: {s.bankName} ({s.bankAccountNumber}) · Ref: <span className="font-mono">{s.bankTransferReference}</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-extrabold text-emerald-700 text-sm tabular-nums">
                                {formatNaira(s.netPayableKobo)}
                              </div>
                              <span className="text-[10px] text-slate-400">{formatDate(s.createdAt)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 6: COMMISSIONS */}
              {activeTab === 'commissions' && (
                <div className="space-y-4 max-w-xl text-xs">
                  <h3 className="font-bold uppercase tracking-wider text-slate-800">
                    BSN Marketplace Commission Configuration
                  </h3>
                  <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4">
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">Platform Default Commission Rate</label>
                      <input
                        type="number"
                        defaultValue={10}
                        className="w-32 px-3 py-2 border rounded-lg bg-white font-bold"
                      />
                      <span className="ml-2 font-bold">%</span>
                      <p className="text-slate-500 mt-1">Applied to standard vendor orders unless category or store overrides exist.</p>
                    </div>

                    <div className="pt-3 border-t">
                      <h4 className="font-bold text-slate-900 mb-2">Category Commission Schedules</h4>
                      <div className="space-y-2">
                        {categories.map((c) => (
                          <div key={c.id} className="flex items-center justify-between py-1 border-b border-slate-200">
                            <span>{c.name}</span>
                            <span className="font-bold">{c.defaultCommissionRate}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 7: DISCOUNTS */}
              {activeTab === 'discounts' && (
                <div className="space-y-6">
                  <form onSubmit={handleCreateDiscount} className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
                    <h3 className="font-bold text-slate-900 text-sm">Create New Promo Campaign</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block font-semibold mb-1">Coupon Code *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. ABUJAFLASH"
                          value={newCodeName}
                          onChange={(e) => setNewCodeName(e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg uppercase"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold mb-1">Discount % Value *</label>
                        <input
                          type="number"
                          required
                          value={newCodeVal}
                          onChange={(e) => setNewCodeVal(e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold mb-1">Min Order (₦)</label>
                        <input
                          type="number"
                          value={newCodeMin}
                          onChange={(e) => setNewCodeMin(e.target.value)}
                          className="w-full px-3 py-2 border rounded-lg"
                        />
                      </div>
                    </div>
                    <button
                      type="submit"
                      disabled={isCreatingDiscount}
                      className="px-4 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800"
                    >
                      Create Coupon Code
                    </button>
                  </form>

                  <div className="space-y-2">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Active Campaign Codes ({discountCodes.length})
                    </h4>
                    {discountCodes.map((d) => (
                      <div key={d.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                        <div>
                          <span className="font-mono font-bold text-red-600 text-sm">{d.code}</span>
                          <span className="text-slate-500 ml-3">
                            {d.value}% off · Min order {formatNaira(d.minOrderKobo)}
                          </span>
                        </div>
                        <span className="text-slate-500">Used: {d.usedCount} times</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 8: AUDIT TRAIL */}
              {activeTab === 'audits' && (
                <div className="space-y-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                    Immutable System Audit Trail ({auditLogs.length} events)
                  </h3>
                  <div className="space-y-2">
                    {auditLogs.map((log) => (
                      <div key={log.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-slate-900">{log.action}</span>
                          <span className="text-[11px] text-slate-400">{formatDate(log.createdAt)}</span>
                        </div>
                        <div className="text-slate-600 mt-1">
                          Actor: <strong>{log.actorEmail}</strong> ({log.actorRole}) · Entity: {log.entityType} ({log.entityId})
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
