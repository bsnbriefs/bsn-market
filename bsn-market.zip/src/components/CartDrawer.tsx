/**
 * BSN Market Shopping Cart Drawer
 * Section 4.E: Transparent multi-vendor breakdown, discount coupon validation, and live server totals
 */

import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, ShieldCheck, Store } from 'lucide-react';
import { CartItem } from '../types/index.ts';
import { formatNaira } from '../utils/format.ts';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, variantId: string | undefined, delta: number) => void;
  onRemoveItem: (productId: string, variantId?: string) => void;
  onProceedToCheckout: () => void;
  appliedDiscountCode: string;
  onApplyDiscountCode: (code: string) => Promise<boolean>;
  subtotalKobo: number;
  deliveryFeeKobo: number;
  discountKobo: number;
  totalKobo: number;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  appliedDiscountCode,
  onApplyDiscountCode,
  subtotalKobo,
  deliveryFeeKobo,
  discountKobo,
  totalKobo
}) => {
  if (!isOpen) return null;

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [isApplying, setIsApplying] = useState(false);

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setIsApplying(true);
    setCouponError('');
    try {
      const success = await onApplyDiscountCode(couponInput.trim().toUpperCase());
      if (!success) {
        setCouponError('Invalid or expired discount code');
      } else {
        setCouponInput('');
      }
    } catch {
      setCouponError('Could not apply discount');
    } finally {
      setIsApplying(false);
    }
  };

  // Group items by retailer for multi-vendor fulfilment transparency
  const itemsByRetailer = items.reduce<Record<string, { retailerName: string; items: CartItem[] }>>(
    (acc, it) => {
      const retId = it.product.retailerId;
      if (!acc[retId]) {
        acc[retId] = { retailerName: it.product.retailerName, items: [] };
      }
      acc[retId].items.push(it);
      return acc;
    },
    {}
  );

  const uniqueRetailerCount = Object.keys(itemsByRetailer).length;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-red-600" />
            <span className="font-bold text-slate-900 text-base">Shopping Cart</span>
            <span className="text-xs text-slate-500 font-medium">({items.length} items)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 divide-y divide-slate-100">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <ShoppingBag className="w-16 h-16 stroke-1 text-slate-300 mb-3" />
              <h3 className="font-semibold text-slate-800 text-sm">Your cart is empty</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Explore independent Nigerian stores to add curated fashion, tech, and pantry goods.
              </p>
              <button
                onClick={onClose}
                className="mt-6 px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800"
              >
                Start Browsing
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Multi-Vendor Fulfilment Note */}
              <div className="p-3 bg-red-50/70 border border-red-100 rounded-lg text-xs text-slate-700 flex items-start gap-2">
                <Store className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-900">Multi-Vendor Dispatch:</span> Items will be dispatched independently by each verified retailer ({uniqueRetailerCount} package{uniqueRetailerCount > 1 ? 's' : ''}).
                </div>
              </div>

              {/* Grouped by retailer */}
              {Object.entries(itemsByRetailer).map(([retId, group]) => (
                <div key={retId} className="space-y-3 pt-2">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                    <span>Package from: {group.retailerName}</span>
                  </div>

                  {group.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex gap-3 p-3 bg-slate-50/70 rounded-xl border border-slate-200/70"
                    >
                      <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-200 shrink-0 border border-slate-200">
                        <img
                          src={item.product.images[0]}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      <div className="flex-1 flex flex-col justify-between">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(item.productId, item.variantId)}
                            className="text-slate-400 hover:text-rose-600 p-0.5"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {item.variantName && (
                          <span className="text-[11px] text-slate-500 font-medium">
                            {item.variantName}
                          </span>
                        )}

                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs font-bold text-slate-900 tabular-nums">
                            {formatNaira(item.unitPriceKobo * item.quantity)}
                          </span>

                          {/* Stepper */}
                          <div className="flex items-center border border-slate-300 rounded bg-white">
                            <button
                              onClick={() => onUpdateQuantity(item.productId, item.variantId, -1)}
                              className="p-1 hover:bg-slate-100 text-slate-600"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-bold text-slate-800 tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.productId, item.variantId, 1)}
                              className="p-1 hover:bg-slate-100 text-slate-600"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-slate-200 bg-slate-50/70 space-y-4">
            {/* Promo Code Form */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Promo Code (e.g. BSNWELCOME)"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                  className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800 uppercase font-medium bg-white"
                />
              </div>
              <button
                type="submit"
                disabled={isApplying || !couponInput.trim()}
                className="px-3.5 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 disabled:opacity-50"
              >
                {isApplying ? 'Applying...' : 'Apply'}
              </button>
            </form>

            {couponError && <p className="text-[11px] text-rose-600 font-medium">{couponError}</p>}
            {appliedDiscountCode && (
              <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded">
                <span>Code Applied: {appliedDiscountCode}</span>
                <span className="tabular-nums">-{formatNaira(discountKobo)}</span>
              </div>
            )}

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Merchandise Subtotal</span>
                <span className="font-semibold text-slate-800 tabular-nums">{formatNaira(subtotalKobo)}</span>
              </div>
              <div className="flex justify-between">
                <span>Estimated Delivery ({uniqueRetailerCount} parcel{uniqueRetailerCount > 1 ? 's' : ''})</span>
                <span className="font-semibold text-slate-800 tabular-nums">{formatNaira(deliveryFeeKobo)}</span>
              </div>
              {discountKobo > 0 && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Discount Savings</span>
                  <span className="tabular-nums">-{formatNaira(discountKobo)}</span>
                </div>
              )}
              <div className="pt-2 border-t border-slate-200 flex justify-between text-sm font-extrabold text-slate-900">
                <span>Total Amount Due</span>
                <span className="tabular-nums text-red-600">{formatNaira(totalKobo)}</span>
              </div>
            </div>

            {/* Action CTA */}
            <button
              onClick={onProceedToCheckout}
              className="w-full min-h-[46px] py-3 px-4 rounded-xl bg-slate-900 text-white hover:bg-slate-800 active:scale-95 font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-md"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-700" />
              <span>Protected by Paystack Secure Escrow</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
