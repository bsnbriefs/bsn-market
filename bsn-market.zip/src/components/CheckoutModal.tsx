/**
 * BSN Market Checkout Experience
 * Section 4.F: Server-side order creation, Nigerian address validation, and Paystack trigger
 */

import React, { useState } from 'react';
import { X, ShieldCheck, MapPin, Phone, User, Mail, Truck, ArrowRight, AlertCircle } from 'lucide-react';
import { CartItem } from '../types/index.ts';
import { formatNaira, NIGERIAN_STATES } from '../utils/format.ts';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  subtotalKobo: number;
  deliveryFeeKobo: number;
  discountKobo: number;
  totalKobo: number;
  appliedDiscountCode: string;
  defaultCustomerName: string;
  defaultEmail: string;
  defaultPhone: string;
  onPlaceOrderAndPay: (orderPayload: {
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryCity: string;
    deliveryState: string;
    deliveryInstructions?: string;
    deliveryMethod: 'standard' | 'express' | 'pickup';
  }) => Promise<void>;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  subtotalKobo,
  deliveryFeeKobo,
  discountKobo,
  totalKobo,
  appliedDiscountCode,
  defaultCustomerName,
  defaultEmail,
  defaultPhone,
  onPlaceOrderAndPay
}) => {
  if (!isOpen) return null;

  const [fullName, setFullName] = useState(defaultCustomerName || 'Kobi Asy');
  const [email, setEmail] = useState(defaultEmail || 'asy.kobi@gmail.com');
  const [phone, setPhone] = useState(defaultPhone || '08031234567');
  const [address, setAddress] = useState('Flat 4B, Admiralty Way, Lekki Phase 1');
  const [city, setCity] = useState('Lekki / Eti-Osa');
  const [state, setState] = useState('Lagos');
  const [deliveryInstructions, setDeliveryInstructions] = useState('Call gate security upon arrival.');
  const [deliveryMethod, setDeliveryMethod] = useState<'standard' | 'express' | 'pickup'>('standard');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim() || !phone.trim() || !address.trim() || !city.trim()) {
      setErrorMsg('Please complete all required delivery details.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');
    try {
      await onPlaceOrderAndPay({
        customerName: fullName.trim(),
        customerEmail: email.trim(),
        customerPhone: phone.trim(),
        deliveryAddress: address.trim(),
        deliveryCity: city.trim(),
        deliveryState: state,
        deliveryInstructions: deliveryInstructions.trim() || undefined,
        deliveryMethod
      });
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to initialize order and payment.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
          <div>
            <h2 className="text-base font-bold text-slate-900">BSN Market Checkout</h2>
            <p className="text-xs text-slate-500">Secure escrow checkout with Nigerian delivery</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Customer Contact */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <User className="w-3.5 h-3.5 text-red-600" />
              <span>1. Customer Information</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-600 font-medium mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-slate-400" />
                  <span>Nigerian Phone Number *</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="0803 123 4567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-600 font-medium mb-1 flex items-center gap-1">
                  <Mail className="w-3 h-3 text-slate-400" />
                  <span>Email Address (for Paystack receipt & order tracking) *</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Nigerian Delivery Address */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-red-600" />
              <span>2. Delivery Destination (Nigeria)</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="sm:col-span-2">
                <label className="block text-slate-600 font-medium mb-1">Street Address *</label>
                <input
                  type="text"
                  required
                  placeholder="House number, Street, Landmark"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">State *</label>
                <select
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800 bg-white"
                >
                  {NIGERIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1">City / LGA *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ikeja, Lekki, Wuse 2"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-600 font-medium mb-1">Special Delivery Instructions (optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Leave with security / Call when near gate"
                  value={deliveryInstructions}
                  onChange={(e) => setDeliveryInstructions(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Delivery Method */}
          <div className="pt-4 border-t border-slate-100">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <Truck className="w-3.5 h-3.5 text-red-600" />
              <span>3. Shipping Method</span>
            </h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <label
                className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-all ${
                  deliveryMethod === 'standard'
                    ? 'border-slate-900 bg-slate-50 ring-1 ring-slate-900'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="deliveryMethod"
                    checked={deliveryMethod === 'standard'}
                    onChange={() => setDeliveryMethod('standard')}
                    className="accent-slate-900"
                  />
                  <span className="font-bold text-slate-900">Standard Delivery</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1">2-3 days dispatch</span>
              </label>

              <label
                className={`p-3 rounded-xl border flex flex-col justify-between cursor-pointer transition-all ${
                  deliveryMethod === 'express'
                    ? 'border-slate-900 bg-slate-50 ring-1 ring-slate-900'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="deliveryMethod"
                    checked={deliveryMethod === 'express'}
                    onChange={() => setDeliveryMethod('express')}
                    className="accent-slate-900"
                  />
                  <span className="font-bold text-slate-900">Priority Express</span>
                </div>
                <span className="text-[11px] text-slate-500 mt-1">Next-day Lagos dispatch</span>
              </label>
            </div>
          </div>

          {/* Section 4: Authoritative Financial Summary */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>Items Total ({items.length} items)</span>
              <span className="font-semibold text-slate-900 tabular-nums">{formatNaira(subtotalKobo)}</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Delivery Fee</span>
              <span className="font-semibold text-slate-900 tabular-nums">{formatNaira(deliveryFeeKobo)}</span>
            </div>
            {discountKobo > 0 && (
              <div className="flex justify-between text-emerald-700 font-semibold">
                <span>Discount ({appliedDiscountCode})</span>
                <span className="tabular-nums">-{formatNaira(discountKobo)}</span>
              </div>
            )}
            <div className="pt-2 border-t border-slate-200 flex justify-between text-base font-extrabold text-slate-900">
              <span>Total to Pay</span>
              <span className="tabular-nums text-red-600">{formatNaira(totalKobo)}</span>
            </div>
          </div>

          {/* Pay Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full min-h-[50px] py-3.5 px-6 rounded-xl bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-sm shadow-lg shadow-red-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <span>{isSubmitting ? 'Creating Order...' : `Pay ${formatNaira(totalKobo)} with Paystack`}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="mt-3 flex items-center justify-center gap-2 text-[11px] text-slate-500 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-700" />
              <span>Payments secured by Paystack Nigeria. Bank transfer, card, and USSD supported.</span>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
