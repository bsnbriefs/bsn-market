/**
 * BSN Market Customer Account Modal
 * Section 4.H: Profile, order history, tracking links, refund requests, and notifications
 */

import React, { useState } from 'react';
import { X, User, Package, Bell, MapPin, ChevronRight, ShieldCheck } from 'lucide-react';
import { UserProfile, Order, InAppNotification } from '../types/index.ts';
import { formatNaira, formatDate, STATUS_CONFIG } from '../utils/format.ts';

interface CustomerAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile | null;
  orders: Order[];
  notifications: InAppNotification[];
  onSelectOrder: (order: Order) => void;
  onMarkNotificationRead: (id: string) => void;
}

export const CustomerAccountModal: React.FC<CustomerAccountModalProps> = ({
  isOpen,
  onClose,
  user,
  orders,
  notifications,
  onSelectOrder,
  onMarkNotificationRead
}) => {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'orders' | 'profile' | 'notifications'>('orders');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-red-600" />
            <span className="font-bold text-slate-900 text-sm">Customer Account & Orders</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-100 text-xs font-semibold px-4">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'orders' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            My Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'notifications' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Notifications ({notifications.length})
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'profile' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Profile & Saved Address
          </button>
        </div>

        <div className="p-6">
          {/* TAB 1: ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              {orders.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  <Package className="w-12 h-12 stroke-1 text-slate-300 mx-auto mb-2" />
                  <p className="font-medium text-slate-700">No orders placed yet</p>
                  <p className="text-slate-500 mt-1">Start shopping to track your delivery parcels here.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((o) => {
                    const cfg = STATUS_CONFIG[o.status] || STATUS_CONFIG.order_placed;
                    return (
                      <div
                        key={o.id}
                        onClick={() => {
                          onSelectOrder(o);
                          onClose();
                        }}
                        className="p-4 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 cursor-pointer transition-colors text-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-sm">{o.orderReference}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
                              {cfg.label}
                            </span>
                          </div>
                          <div className="text-slate-500 mt-1">
                            {formatDate(o.createdAt)} · {o.items.length} items from {o.retailerOrders.length} retailer(s)
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="font-extrabold text-slate-900 text-sm tabular-nums">
                            {formatNaira(o.totalKobo)}
                          </span>
                          <ChevronRight className="w-4 h-4 text-slate-400" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: NOTIFICATIONS */}
          {activeTab === 'notifications' && (
            <div className="space-y-3">
              {notifications.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">No notifications</div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    onClick={() => onMarkNotificationRead(n.id)}
                    className={`p-3.5 rounded-xl border text-xs transition-colors ${
                      n.isRead ? 'bg-slate-50 border-slate-200' : 'bg-red-50/50 border-red-200'
                    }`}
                  >
                    <div className="font-bold text-slate-900 flex justify-between items-center">
                      <span>{n.title}</span>
                      <span className="text-[10px] text-slate-400">{formatDate(n.createdAt)}</span>
                    </div>
                    <p className="text-slate-600 mt-1">{n.message}</p>
                  </div>
                ))
              )}
            </div>
          )}

          {/* TAB 3: PROFILE */}
          {activeTab === 'profile' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
                  User Profile Information
                </h4>
                <div className="flex justify-between py-1 border-b">
                  <span className="text-slate-500">Full Name</span>
                  <span className="font-bold text-slate-900">{user?.fullName}</span>
                </div>
                <div className="flex justify-between py-1 border-b">
                  <span className="text-slate-500">Email Address</span>
                  <span className="font-semibold text-slate-900">{user?.email}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Phone</span>
                  <span className="font-semibold text-slate-900">{user?.phoneNumber || '+234 809 333 4455'}</span>
                </div>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-red-600" />
                  <span>Primary Nigerian Shipping Address</span>
                </h4>
                <p className="font-medium text-slate-800">Flat 4B, Admiralty Way, Lekki Phase 1</p>
                <p className="text-slate-600">Lagos State, Nigeria</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
