/**
 * BSN Market Footer
 * Clean, restrained design with brand identity, policy access, and Nigerian commercial credibility
 */

import React from 'react';
import { ShieldCheck, Mail, Phone, MapPin } from 'lucide-react';

interface FooterProps {
  onOpenPolicy: (topic: 'delivery' | 'returns' | 'terms' | 'privacy' | 'retailer_terms') => void;
  onOpenRetailerApply: () => void;
  onOpenAdminPortal: () => void;
  onOpenRetailerPortal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPolicy,
  onOpenRetailerApply,
  onOpenAdminPortal,
  onOpenRetailerPortal
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-20 md:pb-12 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Col 1: Brand & Ownership */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center font-bold text-sm">
                B
              </div>
              <span className="font-extrabold text-white text-base tracking-tight">BSN Market</span>
            </div>
            <p className="text-red-400 font-semibold text-xs">
              Your Community. Your Marketplace.
            </p>
            <p className="text-slate-400 text-xs leading-relaxed">
              A digital marketplace owned and operated by Barrister Street Network (BSN), connecting shoppers with independent, vetted Nigerian retailers.
            </p>
          </div>

          {/* Col 2: Marketplace Links */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Explore
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><button onClick={onOpenRetailerApply} className="hover:text-white transition-colors">Sell on BSN Market</button></li>
              <li><button onClick={onOpenRetailerPortal} className="hover:text-white transition-colors">Merchant Portal</button></li>
              <li><button onClick={onOpenAdminPortal} className="hover:text-white transition-colors">Administrator Access</button></li>
              <li><button onClick={() => onOpenPolicy('delivery')} className="hover:text-white transition-colors">Tracked Nigerian Couriers</button></li>
            </ul>
          </div>

          {/* Col 3: Customer Trust & Policies */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Trust & Policies
            </h4>
            <ul className="space-y-1.5 text-slate-400">
              <li><button onClick={() => onOpenPolicy('delivery')} className="hover:text-white transition-colors">Delivery Arrangements</button></li>
              <li><button onClick={() => onOpenPolicy('returns')} className="hover:text-white transition-colors">Returns & Refunds</button></li>
              <li><button onClick={() => onOpenPolicy('retailer_terms')} className="hover:text-white transition-colors">Retailer Code of Conduct</button></li>
              <li><button onClick={() => onOpenPolicy('terms')} className="hover:text-white transition-colors">Terms and Conditions</button></li>
              <li><button onClick={() => onOpenPolicy('privacy')} className="hover:text-white transition-colors">Privacy Notice</button></li>
            </ul>
          </div>

          {/* Col 4: Contact & Operations */}
          <div className="space-y-2.5 text-slate-400">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
              Barrister Street Network
            </h4>
            <div className="flex items-start gap-2">
              <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
              <span>Lagos & Abuja, Nigeria</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-red-500 shrink-0" />
              <span>support@bsnmarket.ng</span>
            </div>
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-red-500 shrink-0" />
              <span>+234 (0) 1 800 BSN</span>
            </div>
            <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>Paystack Secured Payments (NGN)</span>
            </div>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} Barrister Street Network (BSN). All rights reserved.
          </div>
          <div className="flex items-center gap-3">
            <span>Prices in Nigerian Naira (₦)</span>
            <span>·</span>
            <span>Independent Merchant Fulfilment</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
