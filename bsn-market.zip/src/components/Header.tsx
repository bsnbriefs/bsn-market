/**
 * BSN Market Header Navigation
 * Follows Top Bar Contract (Wordmark - 4 concise nav links - Primary Action)
 * Includes role switching for testing, search trigger, notifications, and cart trigger.
 */

import React, { useState } from 'react';
import { ShoppingBag, Search, Bell, Store, ShieldCheck, User, Sparkles, Check, Download } from 'lucide-react';
import { UserProfile, RetailerProfile, InAppNotification } from '../types/index.ts';

interface HeaderProps {
  user: UserProfile | null;
  retailer: RetailerProfile | null;
  cartCount: number;
  notifications: InAppNotification[];
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onOpenAccount: () => void;
  onOpenRetailerPortal: () => void;
  onOpenAdminPortal: () => void;
  onOpenRetailerApply: () => void;
  onSwitchRole: (role: 'customer' | 'retailer' | 'admin') => void;
  onNavigate: (section: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  retailer,
  cartCount,
  notifications,
  onOpenCart,
  onOpenSearch,
  onOpenAccount,
  onOpenRetailerPortal,
  onOpenAdminPortal,
  onOpenRetailerApply,
  onSwitchRole,
  onNavigate
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const unreadNotifs = notifications.filter(n => !n.isRead).length;

  return (
    <>
      {/* Top Utility & Role Testing Banner */}
      <div className="bg-[#18181B] text-slate-300 text-xs py-1.5 px-4 sm:px-8 border-b border-white/10">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-medium text-white">Barrister Street Network (BSN)</span>
            <span className="hidden sm:inline text-slate-500">·</span>
            <span className="hidden sm:inline text-slate-400">Nigeria's Community Marketplace</span>
          </div>

          <div className="flex items-center gap-4">
            {/* Quick Persona / Role Switcher for Development & Review */}
            <div className="relative">
              <button
                onClick={() => setShowRoleMenu(!showRoleMenu)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-white transition-colors text-[11px] font-medium"
                title="Switch active role persona"
              >
                <span>Active Role:</span>
                <span className="capitalize font-semibold text-red-400">{user?.role || 'Customer'}</span>
              </button>

              {showRoleMenu && (
                <div className="absolute right-0 top-full mt-1.5 w-56 bg-white text-slate-800 rounded-lg shadow-xl border border-slate-200 z-50 p-2 text-xs">
                  <div className="px-2 py-1 font-semibold text-slate-400 uppercase tracking-wider text-[10px]">
                    Switch Testing Persona
                  </div>
                  <button
                    onClick={() => {
                      onSwitchRole('customer');
                      setShowRoleMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded flex items-center justify-between hover:bg-slate-50 ${
                      user?.role === 'customer' ? 'font-semibold text-red-600 bg-red-50/50' : 'text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Customer Persona</div>
                      <div className="text-[11px] text-slate-500">Kobi Asy (Shopper)</div>
                    </div>
                    {user?.role === 'customer' && <Check className="w-4 h-4 text-red-600" />}
                  </button>
                  <button
                    onClick={() => {
                      onSwitchRole('retailer');
                      setShowRoleMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded flex items-center justify-between hover:bg-slate-50 ${
                      user?.role === 'retailer' ? 'font-semibold text-red-600 bg-red-50/50' : 'text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Retailer Persona</div>
                      <div className="text-[11px] text-slate-500">Amina (Zaria Wears)</div>
                    </div>
                    {user?.role === 'retailer' && <Check className="w-4 h-4 text-red-600" />}
                  </button>
                  <button
                    onClick={() => {
                      onSwitchRole('admin');
                      setShowRoleMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-2 rounded flex items-center justify-between hover:bg-slate-50 ${
                      user?.role === 'admin' ? 'font-semibold text-red-600 bg-red-50/50' : 'text-slate-700'
                    }`}
                  >
                    <div>
                      <div className="font-medium">Administrator Persona</div>
                      <div className="text-[11px] text-slate-500">BSN Admin Oversight</div>
                    </div>
                    {user?.role === 'admin' && <Check className="w-4 h-4 text-red-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* Download Project ZIP for GitHub */}
            <a
              href="/api/download-zip"
              download="bsn-market.zip"
              className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600 hover:bg-red-700 text-white transition-colors text-[11px] font-semibold shadow-sm"
              title="Download zipped repository to push to GitHub"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP for GitHub</span>
            </a>

            {/* Support / Deals Shortcut */}
            <button
              onClick={() => onNavigate('deals')}
              className="hidden md:inline hover:text-white transition-colors text-slate-400"
            >
              Today's Deals
            </button>
          </div>
        </div>
      </div>

      {/* Main Header conforming to Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between gap-6 md:gap-8">
          {/* Zone 1: Brand Wordmark (Single text element) */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-left group shrink-0"
          >
            <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center font-bold text-base shadow-sm group-hover:bg-red-700 transition-colors">
              B
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-extrabold tracking-tight text-slate-900 group-hover:text-red-600 transition-colors whitespace-nowrap">
                BSN Market
              </span>
            </div>
          </button>

          {/* Zone 2: 4 Clean Single-Line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 shrink-0">
            <button
              onClick={() => onNavigate('shop')}
              className="hover:text-red-600 transition-colors whitespace-nowrap"
            >
              Shop All
            </button>
            <button
              onClick={() => onNavigate('categories')}
              className="hover:text-red-600 transition-colors whitespace-nowrap"
            >
              Categories
            </button>
            <button
              onClick={() => onNavigate('deals')}
              className="hover:text-red-600 transition-colors whitespace-nowrap flex items-center gap-1 text-slate-800 font-semibold"
            >
              <Sparkles className="w-3.5 h-3.5 text-red-600" />
              BSN Deals
            </button>
            <button
              onClick={() => onNavigate('retailers')}
              className="hover:text-red-600 transition-colors whitespace-nowrap"
            >
              Retailers
            </button>
            {user?.role === 'retailer' ? (
              <button
                onClick={onOpenRetailerPortal}
                className="hover:text-red-600 transition-colors text-red-600 font-semibold whitespace-nowrap flex items-center gap-1"
              >
                <Store className="w-3.5 h-3.5" />
                Retailer Portal
              </button>
            ) : user?.role === 'admin' ? (
              <button
                onClick={onOpenAdminPortal}
                className="hover:text-red-600 transition-colors text-red-600 font-semibold whitespace-nowrap flex items-center gap-1"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Admin Dashboard
              </button>
            ) : (
              <button
                onClick={onOpenRetailerApply}
                className="hover:text-red-600 transition-colors whitespace-nowrap text-slate-500"
              >
                Sell on BSN
              </button>
            )}
          </nav>

          {/* Zone 3: Interactive Affordances (Search, Notifications, Account, Cart) */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {/* Search Trigger Button */}
            <button
              onClick={onOpenSearch}
              className="min-h-[44px] min-w-[44px] p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center justify-center"
              aria-label="Search products"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Notifications Trigger */}
            <div className="relative">
              <button
                onClick={() => setShowNotifMenu(!showNotifMenu)}
                className="min-h-[44px] min-w-[44px] p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center justify-center relative"
                aria-label="Notifications"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifs > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-600" />
                )}
              </button>

              {showNotifMenu && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 z-50 p-3">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-2">
                    <span className="font-semibold text-xs text-slate-800">Notifications</span>
                    <span className="text-[11px] text-slate-500">{notifications.length} updates</span>
                  </div>
                  <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 text-xs">
                    {notifications.length === 0 ? (
                      <div className="py-4 text-center text-slate-400">No notifications yet</div>
                    ) : (
                      notifications.map(n => (
                        <div key={n.id} className="py-2.5 px-1 hover:bg-slate-50 rounded">
                          <div className="font-semibold text-slate-800">{n.title}</div>
                          <p className="text-slate-600 text-[11px] mt-0.5">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Account / Profile Button */}
            <button
              onClick={onOpenAccount}
              className="min-h-[44px] min-w-[44px] p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center justify-center"
              aria-label="Customer Account"
            >
              <User className="w-5 h-5" />
            </button>

            {/* Shopping Cart Button */}
            <button
              onClick={onOpenCart}
              className="min-h-[44px] px-3.5 py-2 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 active:scale-95 rounded-lg transition-all flex items-center gap-2 shadow-sm whitespace-nowrap"
              aria-label={`Cart with ${cartCount} items`}
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Cart</span>
              {cartCount > 0 && (
                <span className="bg-red-600 text-white text-xs font-bold px-1.5 py-0.5 rounded-full tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>
    </>
  );
};
