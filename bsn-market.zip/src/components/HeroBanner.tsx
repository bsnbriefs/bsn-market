/**
 * BSN Market Hero Section
 * Conforming strictly to Section 4.A requirements and e-commerce design rules
 */

import React from 'react';
import { ShieldCheck, Truck, CreditCard, ChevronRight, Sparkles } from 'lucide-react';

interface HeroBannerProps {
  onStartShopping: () => void;
  onExploreDeals: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onStartShopping,
  onExploreDeals
}) => {
  return (
    <section className="relative bg-white border-b border-slate-200 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 md:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Hero Content */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Tagline / Subtitle */}
            <div className="flex items-center gap-2 mb-4 text-xs font-semibold uppercase tracking-wider text-red-600">
              <span className="w-2 h-2 rounded-full bg-red-600" />
              <span>Your Community. Your Marketplace.</span>
            </div>

            {/* Headline with balanced wrap */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.15] text-balance">
              Discover Great Products. <br className="hidden sm:inline" />
              Shop With Confidence.
            </h1>

            {/* Supporting Text */}
            <p className="mt-4 text-base sm:text-lg text-slate-600 max-w-xl leading-relaxed">
              Explore products from verified Nigerian independent retailers, discover special deals, and shop conveniently through BSN Market.
            </p>

            {/* Primary & Secondary Action CTAs */}
            <div className="mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
              <button
                onClick={onStartShopping}
                className="min-h-[48px] px-6 py-3 rounded-xl bg-slate-900 text-white hover:bg-slate-800 active:scale-95 font-semibold text-sm transition-all shadow-md flex items-center gap-2"
              >
                <span>Start Shopping</span>
                <ChevronRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreDeals}
                className="min-h-[48px] px-6 py-3 rounded-xl bg-red-50 text-red-700 hover:bg-red-100 active:scale-95 font-semibold text-sm transition-all border border-red-200 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-red-600" />
                <span>Explore Deals</span>
              </button>
            </div>

            {/* 3 Nigerian Trust Pillars */}
            <div className="mt-10 pt-6 border-t border-slate-100 grid grid-cols-3 gap-4 text-xs">
              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <ShieldCheck className="w-4 h-4 text-red-600 shrink-0" />
                  <span>Verified Retailers</span>
                </div>
                <span className="text-slate-500 text-[11px]">CAC registered stores</span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <CreditCard className="w-4 h-4 text-red-600 shrink-0" />
                  <span>Paystack Escrow</span>
                </div>
                <span className="text-slate-500 text-[11px]">Funds protected until delivery</span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <Truck className="w-4 h-4 text-red-600 shrink-0" />
                  <span>Nigeria-Wide</span>
                </div>
                <span className="text-slate-500 text-[11px]">Tracked city courier dispatch</span>
              </div>
            </div>
          </div>

          {/* Right Hero Image Asset */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/3] lg:aspect-square bg-slate-100 border border-slate-200 shadow-xl group">
              <img
                src="/src/assets/images/hero_nigerian_market_1791585883007.jpg"
                alt="Contemporary Nigerian boutique shopping experience in Victoria Island Lagos"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 text-white">
                <div className="text-xs uppercase font-bold tracking-widest text-red-300">Community Marketplace</div>
                <div className="text-sm font-semibold mt-0.5">Connecting independent Nigerian retailers to shoppers nationwide</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
