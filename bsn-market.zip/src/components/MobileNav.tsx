/**
 * BSN Market Mobile Bottom Navigation Bar
 * Optimized for Nigerian smartphone viewports & one-handed thumb ergonomics
 * Strictly respects 15% viewport height cap and 44px minimum hitbox
 */

import React from 'react';
import { Home, Grid, Sparkles, ShoppingBag, User } from 'lucide-react';

interface MobileNavProps {
  currentTab: string;
  cartCount: number;
  onSelectTab: (tab: string) => void;
  onOpenCart: () => void;
  onOpenAccount: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentTab,
  cartCount,
  onSelectTab,
  onOpenCart,
  onOpenAccount
}) => {
  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 h-16 pb-safe px-2"
      aria-label="Mobile Navigation"
    >
      <div className="grid grid-cols-5 h-full items-center">
        {/* Home */}
        <button
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] ${
            currentTab === 'home' ? 'text-red-600 font-semibold' : 'text-slate-500'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Home</span>
        </button>

        {/* Categories */}
        <button
          onClick={() => onSelectTab('categories')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] ${
            currentTab === 'categories' ? 'text-red-600 font-semibold' : 'text-slate-500'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Categories</span>
        </button>

        {/* Deals */}
        <button
          onClick={() => onSelectTab('deals')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] ${
            currentTab === 'deals' ? 'text-red-600 font-semibold' : 'text-slate-500'
          }`}
        >
          <Sparkles className="w-5 h-5 text-red-600" />
          <span className="text-[10px] tracking-tight mt-1">Deals</span>
        </button>

        {/* Cart */}
        <button
          onClick={onOpenCart}
          className="flex flex-col items-center justify-center min-h-[44px] min-w-[44px] relative text-slate-500"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-red-600 text-white text-[9px] font-bold px-1 rounded-full tabular-nums">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] tracking-tight mt-1">Cart</span>
        </button>

        {/* Account */}
        <button
          onClick={onOpenAccount}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] ${
            currentTab === 'account' ? 'text-red-600 font-semibold' : 'text-slate-500'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Account</span>
        </button>
      </div>
    </nav>
  );
};
