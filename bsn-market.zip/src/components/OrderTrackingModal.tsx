/**
 * BSN Market Order Tracking & Details Modal
 * Section 4.G: Live multi-stage status timeline, parcel tracking numbers, and refund requests
 */

import React, { useState } from 'react';
import {
  X,
  Package,
  CheckCircle,
  Clock,
  Truck,
  RotateCcw,
  Store,
  ChevronRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Order, OrderStatus } from '../types/index.ts';
import { formatNaira, formatDate, STATUS_CONFIG } from '../utils/format.ts';

interface OrderTrackingModalProps {
  order: Order | null;
  onClose: () => void;
  onRequestRefund?: (orderId: string, reason: string) => void;
}

const ORDER_STEPS: { status: OrderStatus; label: string }[] = [
  { status: 'order_placed', label: 'Order Placed' },
  { status: 'payment_confirmed', label: 'Payment Verified' },
  { status: 'retailer_confirmed', label: 'Retailer Confirmed' },
  { status: 'processing', label: 'Processing & Packaged' },
  { status: 'dispatched', label: 'Dispatched to Courier' },
  { status: 'delivered', label: 'Delivered' }
];

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  order,
  onClose,
  onRequestRefund
}) => {
  if (!order) return null;

  const [refundReason, setRefundReason] = useState('');
  const [showRefundForm, setShowRefundForm] = useState(false);
  const [refundSubmitted, setRefundSubmitted] = useState(false);

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'order_placed':
        return 0;
      case 'payment_confirmed':
        return 1;
      case 'retailer_confirmed':
        return 2;
      case 'processing':
        return 3;
      case 'dispatched':
        return 4;
      case 'delivered':
        return 5;
      default:
        return 1;
    }
  };

  const currentStepIdx = getStepIndex(order.status);
  const statusCfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.order_placed;

  const handleRefundSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundReason.trim()) return;
    if (onRequestRefund) {
      onRequestRefund(order.id, refundReason.trim());
      setRefundSubmitted(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-900 text-base">Order {order.orderReference}</span>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${statusCfg.bg} ${statusCfg.text} ${statusCfg.border}`}>
                {statusCfg.label}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Placed on {formatDate(order.createdAt)}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status Stepper Progression */}
          <div className="p-5 bg-slate-50 rounded-xl border border-slate-200">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-4">
              Fulfilment Progression
            </h3>

            <div className="relative flex flex-col sm:flex-row justify-between gap-4 sm:gap-2">
              {ORDER_STEPS.map((step, idx) => {
                const isPassed = idx <= currentStepIdx;
                const isCurrent = idx === currentStepIdx;

                return (
                  <div key={step.status} className="flex-1 flex sm:flex-col items-center gap-3 sm:gap-2 text-left sm:text-center">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                        isCurrent
                          ? 'bg-red-600 text-white ring-4 ring-red-100 shadow'
                          : isPassed
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-200 text-slate-400'
                      }`}
                    >
                      {isPassed ? <CheckCircle className="w-4 h-4" /> : idx + 1}
                    </div>

                    <div>
                      <div className={`text-xs font-semibold ${isPassed ? 'text-slate-900' : 'text-slate-400'}`}>
                        {step.label}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Per-Retailer Fulfilment Packages */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3 flex items-center gap-2">
              <Store className="w-4 h-4 text-red-600" />
              <span>Retailer Fulfilment Packages ({order.retailerOrders.length})</span>
            </h3>

            <div className="space-y-4">
              {order.retailerOrders.map((ro) => {
                const roCfg = STATUS_CONFIG[ro.fulfilmentStatus] || STATUS_CONFIG.order_placed;
                return (
                  <div key={ro.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{ro.retailerName}</span>
                        <span className="text-[11px] font-mono text-slate-500">Ref: {ro.retailerOrderRef}</span>
                      </div>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${roCfg.bg} ${roCfg.text} ${roCfg.border}`}>
                        {roCfg.label}
                      </span>
                    </div>

                    {/* Dispatch info if available */}
                    {ro.courierName && (
                      <div className="p-2.5 bg-white rounded-lg border border-slate-200 text-xs flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Truck className="w-4 h-4 text-slate-600" />
                          <span>Dispatched via <strong>{ro.courierName}</strong></span>
                        </div>
                        {ro.trackingReference && (
                          <span className="font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                            Track: {ro.trackingReference}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Items inside this package */}
                    <div className="space-y-2">
                      {ro.items.map((it) => (
                        <div key={it.id} className="flex items-center justify-between text-xs py-1">
                          <div className="flex items-center gap-2">
                            <span className="text-slate-500 font-semibold">{it.quantity}x</span>
                            <span className="text-slate-800 font-medium">{it.productName}</span>
                            {it.variantName && <span className="text-slate-400">({it.variantName})</span>}
                          </div>
                          <span className="font-bold text-slate-900 tabular-nums">
                            {formatNaira(it.subtotalKobo)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Delivery & Payment Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                Delivery Details
              </h4>
              <p className="text-slate-800 font-semibold">{order.customerName}</p>
              <p className="text-slate-600 mt-0.5">{order.customerPhone}</p>
              <p className="text-slate-600 mt-1">{order.deliveryAddress}</p>
              <p className="text-slate-600">{order.deliveryCity}, {order.deliveryState}</p>
              {order.deliveryInstructions && (
                <p className="text-slate-500 italic mt-2">Note: {order.deliveryInstructions}</p>
              )}
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px] mb-2">
                Financial Summary
              </h4>
              <div className="space-y-1 text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-semibold text-slate-900 tabular-nums">{formatNaira(order.subtotalKobo)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee:</span>
                  <span className="font-semibold text-slate-900 tabular-nums">{formatNaira(order.deliveryFeeKobo)}</span>
                </div>
                {order.discountKobo > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>Discount:</span>
                    <span className="tabular-nums">-{formatNaira(order.discountKobo)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-200 flex justify-between font-bold text-slate-900 text-sm">
                  <span>Total Paid:</span>
                  <span className="tabular-nums text-red-600">{formatNaira(order.totalKobo)}</span>
                </div>
              </div>

              {order.paymentReference && (
                <div className="mt-3 pt-2 border-t border-slate-200 text-[11px] text-slate-500 font-mono">
                  Paystack Ref: {order.paymentReference}
                </div>
              )}
            </div>
          </div>

          {/* Refund / Cancellation Action */}
          {order.status !== 'delivered' && order.status !== 'cancelled' && order.status !== 'refunded' && (
            <div className="pt-4 border-t border-slate-200">
              {!showRefundForm ? (
                <button
                  onClick={() => setShowRefundForm(true)}
                  className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Request Cancellation / Refund</span>
                </button>
              ) : refundSubmitted ? (
                <div className="p-3 bg-emerald-50 text-emerald-700 text-xs rounded-lg font-medium">
                  Your refund request has been logged. BSN administrators and the retailer will review within 24 hours.
                </div>
              ) : (
                <form onSubmit={handleRefundSubmit} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800">Submit Cancellation & Refund Request</h4>
                  <textarea
                    rows={2}
                    required
                    placeholder="Provide a clear reason for cancellation (e.g. wrong item ordered, address change)..."
                    value={refundReason}
                    onChange={(e) => setRefundReason(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800 bg-white"
                  />
                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="px-4 py-2 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700"
                    >
                      Confirm Request
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowRefundForm(false)}
                      className="px-4 py-2 text-slate-600 hover:text-slate-800 text-xs font-semibold"
                    >
                      Dismiss
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Audit Timeline Stream */}
          <div className="pt-4 border-t border-slate-200">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-3">
              Order Event Log & Audits
            </h3>
            <div className="space-y-3 border-l-2 border-slate-200 pl-4 text-xs">
              {order.timeline.map((evt, idx) => (
                <div key={idx} className="relative">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-slate-400" />
                  <div className="font-semibold text-slate-800">{evt.title}</div>
                  <p className="text-slate-600 mt-0.5">{evt.description}</p>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {formatDate(evt.timestamp)} {evt.actor ? `· Actor: ${evt.actor}` : ''}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
