/**
 * BSN Market Paystack Checkout Interface
 * Section 4.F: Server-side payment verification simulation and Paystack lifecycle
 */

import React, { useState } from 'react';
import { X, ShieldCheck, CreditCard, Landmark, PhoneCall, CheckCircle, Loader2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { formatNaira } from '../utils/format.ts';

interface PaystackModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderReference: string;
  amountKobo: number;
  email: string;
  paymentReference: string;
  onPaymentSuccess: (verifiedOrder: any) => void;
  onVerifyPayment: (ref: string, channel: string) => Promise<any>;
}

export const PaystackModal: React.FC<PaystackModalProps> = ({
  isOpen,
  onClose,
  orderReference,
  amountKobo,
  email,
  paymentReference,
  onPaymentSuccess,
  onVerifyPayment
}) => {
  if (!isOpen) return null;

  const [activeChannel, setActiveChannel] = useState<'card' | 'bank' | 'ussd'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [cardNumber, setCardNumber] = useState('4084 0841 1121 0000');
  const [cardExpiry, setCardExpiry] = useState('09/28');
  const [cardCvv, setCardCvv] = useState('481');

  const handleAuthorizePayment = async () => {
    setIsProcessing(true);
    setErrorMsg('');

    try {
      // Execute authoritative server-side verification
      const result = await onVerifyPayment(paymentReference, activeChannel);

      // Trigger celebratory confetti
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      onPaymentSuccess(result.order);
    } catch (err: any) {
      setErrorMsg(err.message || 'Payment verification failed');
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
        {/* Paystack Header Banner */}
        <div className="bg-[#001328] text-white p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-[#00C3F7]">paystack</span>
              <span className="text-[10px] bg-white/10 text-slate-300 px-1.5 py-0.5 rounded font-mono">
                SECURE CHECKOUT
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">{email}</p>
          </div>

          <div className="text-right">
            <div className="text-xs text-slate-400">Paying</div>
            <div className="text-lg font-bold text-white tabular-nums">
              {formatNaira(amountKobo)}
            </div>
          </div>
        </div>

        {/* Order Reference Strip */}
        <div className="bg-slate-50 px-5 py-2.5 border-b border-slate-200 flex items-center justify-between text-xs text-slate-600">
          <span>BSN Order: <strong className="text-slate-900">{orderReference}</strong></span>
          <span className="font-mono text-[11px] text-slate-400">Ref: {paymentReference.slice(0, 16)}...</span>
        </div>

        {/* Channel Selector Tabs */}
        <div className="grid grid-cols-3 border-b border-slate-200 bg-slate-100 text-xs font-semibold">
          <button
            onClick={() => setActiveChannel('card')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors ${
              activeChannel === 'card'
                ? 'bg-white text-slate-900 border-b-2 border-[#00C3F7]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>Card</span>
          </button>

          <button
            onClick={() => setActiveChannel('bank')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors ${
              activeChannel === 'bank'
                ? 'bg-white text-slate-900 border-b-2 border-[#00C3F7]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Landmark className="w-3.5 h-3.5" />
            <span>Transfer</span>
          </button>

          <button
            onClick={() => setActiveChannel('ussd')}
            className={`py-3 flex items-center justify-center gap-1.5 transition-colors ${
              activeChannel === 'ussd'
                ? 'bg-white text-slate-900 border-b-2 border-[#00C3F7]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>USSD</span>
          </button>
        </div>

        {/* Channel Form */}
        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
              {errorMsg}
            </div>
          )}

          {activeChannel === 'card' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Card Number</label>
                <div className="relative">
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full text-xs font-mono px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[10px] text-slate-400 font-bold">
                    <span>VERVE / VISA / MC</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Valid Till</label>
                  <input
                    type="text"
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(e.target.value)}
                    className="w-full text-xs font-mono px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">CVV</label>
                  <input
                    type="password"
                    maxLength={3}
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value)}
                    className="w-full text-xs font-mono px-3 py-2.5 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800"
                  />
                </div>
              </div>
            </div>
          )}

          {activeChannel === 'bank' && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
              <div className="text-slate-600">Transfer exactly {formatNaira(amountKobo)} to:</div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1">
                <div className="font-bold text-slate-900 text-sm">Wema Bank / Paystack Titan</div>
                <div className="font-mono text-base font-extrabold text-blue-700">9910 4829 11</div>
                <div className="text-[11px] text-slate-500">BSN Market Checkout / {orderReference}</div>
              </div>
              <p className="text-[11px] text-slate-500">Account expires in 30 minutes. Click below once transferred.</p>
            </div>
          )}

          {activeChannel === 'ussd' && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs text-center">
              <div className="text-slate-600">Dial the code on your mobile phone:</div>
              <div className="p-3 bg-white rounded-lg border border-slate-200 font-mono text-base font-extrabold text-slate-900">
                *737*000*8921#
              </div>
              <p className="text-[11px] text-slate-500">Works with GTBank, Zenith (*966#), UBA (*919#), and Access (*901#).</p>
            </div>
          )}

          {/* Authorize Action Button */}
          <div className="mt-6 space-y-3">
            <button
              onClick={handleAuthorizePayment}
              disabled={isProcessing}
              className="w-full min-h-[48px] py-3 px-4 bg-[#09A5DB] hover:bg-[#0092c7] active:scale-95 text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Verifying Transaction Server-Side...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Authorize {formatNaira(amountKobo)}</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              disabled={isProcessing}
              className="w-full py-2 text-slate-500 hover:text-slate-800 text-xs font-semibold"
            >
              Cancel Payment
            </button>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-center gap-2 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
            <span>256-bit encrypted SSL Paystack payment verification</span>
          </div>
        </div>
      </div>
    </div>
  );
};
