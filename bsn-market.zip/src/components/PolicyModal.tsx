/**
 * BSN Market Customer Trust & Policy Center
 * Section 12: Transparent policies detailing fulfilment roles, refunds, delivery, and terms
 */

import React, { useState } from 'react';
import { X, ShieldCheck, Truck, RotateCcw, FileText, Lock, Store } from 'lucide-react';

interface PolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTopic?: 'delivery' | 'returns' | 'terms' | 'privacy' | 'retailer_terms';
}

export const PolicyModal: React.FC<PolicyModalProps> = ({
  isOpen,
  onClose,
  initialTopic = 'delivery'
}) => {
  if (!isOpen) return null;

  const [topic, setTopic] = useState(initialTopic);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-600" />
            <span className="font-bold text-slate-900 text-sm">BSN Market Policy & Trust Center</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Topic navigation tabs */}
        <div className="flex border-b border-slate-200 bg-slate-100 text-xs font-semibold px-4 overflow-x-auto">
          <button
            onClick={() => setTopic('delivery')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap ${
              topic === 'delivery' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Delivery Policy
          </button>
          <button
            onClick={() => setTopic('returns')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap ${
              topic === 'returns' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Returns & Refunds
          </button>
          <button
            onClick={() => setTopic('terms')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap ${
              topic === 'terms' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Terms of Use
          </button>
          <button
            onClick={() => setTopic('privacy')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap ${
              topic === 'privacy' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Privacy Policy
          </button>
          <button
            onClick={() => setTopic('retailer_terms')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap ${
              topic === 'retailer_terms' ? 'border-red-600 text-red-600 bg-white' : 'text-slate-600'
            }`}
          >
            Retailer Agreement
          </button>
        </div>

        <div className="p-6 text-xs text-slate-700 leading-relaxed space-y-4">
          {topic === 'delivery' && (
            <>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Truck className="w-4 h-4 text-red-600" />
                <span>Marketplace Delivery Arrangements</span>
              </h3>
              <p>
                BSN Market is a digital marketplace owned by Barrister Street Network (BSN). BSN connects customers with independent retailers and does not operate its own centralized delivery fleet.
              </p>
              <h4 className="font-bold text-slate-800">Fulfilment Responsibility:</h4>
              <p>
                Each independent retailer is responsible for safely packaging and dispatching customer items through reliable third-party Nigerian courier services (such as Kwik, GIG Logistics, DHL, or approved dispatch riders).
              </p>
              <h4 className="font-bold text-slate-800">Delivery Timelines:</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li><strong>Intra-City (e.g. within Lagos State):</strong> Typically delivered within 24 to 48 business hours after retailer confirmation.</li>
                <li><strong>Inter-State / Nationwide:</strong> Typically delivered within 2 to 4 business days.</li>
              </ul>
              <p>
                Delivery fees are calculated per participating retailer package and displayed transparently before payment is authorized.
              </p>
            </>
          )}

          {topic === 'returns' && (
            <>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-red-600" />
                <span>Returns, Cancellations & Refund Policy</span>
              </h3>
              <p>
                BSN Market utilizes Paystack escrow-style payment capture to protect customer funds until orders are verified.
              </p>
              <h4 className="font-bold text-slate-800">Eligible Returns:</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>Products that arrived defective, damaged in transit, or significantly different from the retailer's listing.</li>
                <li>Items reported within 48 hours of physical delivery confirmation.</li>
              </ul>
              <h4 className="font-bold text-slate-800">Refund Workflow:</h4>
              <p>
                When a retailer rejects an order or a verified cancellation is accepted, the order transitions to <span className="font-mono bg-slate-100 px-1 rounded">refund_requested</span>. BSN administrators review the audit record and process the refund back to the customer's original payment method via Paystack.
              </p>
            </>
          )}

          {topic === 'terms' && (
            <>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-red-600" />
                <span>BSN Market Terms of Service</span>
              </h3>
              <p>
                By using BSN Market, customers and retailers agree to conduct transactions in good faith according to Nigerian commercial regulations. BSN acts as an intermediary marketplace platform facilitating discovery, ordering, payment processing, and moderation.
              </p>
              <p>
                Prices and stock counts displayed on BSN Market are maintained authoritatively by approved independent merchants. Tampering with client-side pricing or circumventing payment channels is strictly prohibited.
              </p>
            </>
          )}

          {topic === 'privacy' && (
            <>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Lock className="w-4 h-4 text-red-600" />
                <span>Privacy & Data Protection Notice</span>
              </h3>
              <p>
                We collect personal information (name, delivery address, Nigerian telephone number, email) strictly to facilitate order fulfilment, courier communication, and transaction receipts.
              </p>
              <p>
                Payment card details and bank authentication credentials are processed directly by Paystack via encrypted protocols and are never stored on BSN servers.
              </p>
            </>
          )}

          {topic === 'retailer_terms' && (
            <>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Store className="w-4 h-4 text-red-600" />
                <span>Retailer Agreement & Commission Structure</span>
              </h3>
              <p>
                Independent retailers must submit valid Nigerian Corporate Affairs Commission (CAC) registration or business verification before publishing live products.
              </p>
              <h4 className="font-bold text-slate-800">Commission Deductions:</h4>
              <p>
                BSN Market automatically snapshots agreed commission rates (default 10%, or category/retailer override) at the time of order creation. Settlements are calculated on eligible product subtotal excluding delivery fees.
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
