/**
 * BSN Market Product Card
 * Section 4.C: Complies with zero-pill discipline, authentic discount calculations, and resilient image fallbacks
 */

import React, { useState } from 'react';
import { ShoppingBag, Star, CheckCircle, Eye } from 'lucide-react';
import { Product } from '../types/index.ts';
import { formatNaira } from '../utils/format.ts';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  onAddToCart
}) => {
  const [imageError, setImageError] = useState(false);

  // Genuine discount calculation
  const hasDiscount =
    product.compareAtPriceKobo && product.compareAtPriceKobo > product.priceKobo;
  const discountPercent = hasDiscount
    ? Math.round(
        ((product.compareAtPriceKobo! - product.priceKobo) /
          product.compareAtPriceKobo!) *
          100
      )
    : 0;

  const isOutOfStock = product.stockQuantity <= 0;

  return (
    <div className="group bg-white rounded-xl border border-slate-200/80 hover:border-slate-300 hover:shadow-md transition-all duration-200 flex flex-col overflow-hidden">
      {/* Product Image Area */}
      <div
        onClick={() => onSelect(product)}
        className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden cursor-pointer"
      >
        {!imageError && product.images && product.images[0] ? (
          <img
            src={product.images[0]}
            alt={product.name}
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-slate-50 text-slate-400">
            <ShoppingBag className="w-10 h-10 mb-2 text-slate-300" />
            <span className="text-xs text-center font-medium line-clamp-1">{product.name}</span>
          </div>
        )}

        {/* Genuine Discount Tag (only when genuine previous price exists) */}
        {hasDiscount && (
          <div className="absolute top-2.5 left-2.5 bg-red-600 text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-sm">
            Save {discountPercent}%
          </div>
        )}

        {/* Quick View Overlay Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSelect(product);
          }}
          className="absolute bottom-2.5 right-2.5 p-2 bg-white/90 backdrop-blur-sm text-slate-700 hover:text-red-600 rounded-lg shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
          title="Quick View"
        >
          <Eye className="w-4 h-4" />
        </button>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata: Category & Retailer (Zero-Pill clean text with · separator) */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <span className="truncate max-w-[140px] font-medium text-slate-700 flex items-center gap-1">
              {product.retailerName}
              <span title="Verified Nigerian Retailer">
                <CheckCircle className="w-3 h-3 text-red-600 shrink-0 inline" />
              </span>
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{product.categoryName}</span>
          </div>

          {/* Product Name */}
          <h3
            onClick={() => onSelect(product)}
            className="font-semibold text-slate-900 text-sm leading-snug line-clamp-2 hover:text-red-600 cursor-pointer transition-colors"
          >
            {product.name}
          </h3>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100">
          {/* Price & Rating Row */}
          <div className="flex items-baseline justify-between mb-3">
            <div className="flex items-baseline gap-2">
              <span className="text-base font-bold text-slate-900 tabular-nums">
                {formatNaira(product.priceKobo)}
              </span>
              {hasDiscount && (
                <span className="text-xs text-slate-400 line-through tabular-nums">
                  {formatNaira(product.compareAtPriceKobo!)}
                </span>
              )}
            </div>

            {/* Rating */}
            <div className="flex items-center gap-1 text-xs text-amber-600 font-semibold tabular-nums">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{product.rating.toFixed(1)}</span>
              <span className="text-slate-400 font-normal text-[11px]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Action Button: Add to Cart */}
          <button
            onClick={() => onAddToCart(product)}
            disabled={isOutOfStock}
            className={`w-full min-h-[40px] py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
              isOutOfStock
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                : 'bg-slate-900 text-white hover:bg-slate-800 active:scale-95 shadow-sm'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{isOutOfStock ? 'Sold Out' : 'Add to Cart'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
