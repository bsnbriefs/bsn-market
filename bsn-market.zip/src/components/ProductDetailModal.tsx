/**
 * BSN Market Product Details View (PDP)
 * Section 4.D: Detailed product page with variant selections, delivery & return terms, and reviews
 */

import React, { useState } from 'react';
import {
  X,
  Star,
  ShieldCheck,
  Truck,
  RotateCcw,
  CheckCircle,
  ShoppingBag,
  Plus,
  Minus,
  MessageSquare
} from 'lucide-react';
import { Product, ProductVariant } from '../types/index.ts';
import { formatNaira, formatDate } from '../utils/format.ts';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, variantId?: string, quantity?: number) => void;
  onBuyNow: (product: Product, variantId?: string, quantity?: number) => void;
  onSubmitReview: (productId: string, review: { rating: number; title?: string; comment: string }) => Promise<void>;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onSubmitReview
}) => {
  if (!product) return null;

  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(
    product.variants && product.variants.length > 0 ? product.variants[0] : null
  );
  const [quantity, setQuantity] = useState(1);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  const activePriceKobo = selectedVariant ? selectedVariant.priceKobo : product.priceKobo;
  const hasDiscount = product.compareAtPriceKobo && product.compareAtPriceKobo > activePriceKobo;
  const discountPercent = hasDiscount
    ? Math.round(((product.compareAtPriceKobo! - activePriceKobo) / product.compareAtPriceKobo!) * 100)
    : 0;

  const availableStock = selectedVariant ? selectedVariant.stockQuantity : product.stockQuantity;
  const isOutOfStock = availableStock <= 0;

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setIsSubmittingReview(true);
    try {
      await onSubmitReview(product.id, {
        rating: newRating,
        title: newTitle.trim() || undefined,
        comment: newComment.trim()
      });
      setReviewSuccess(true);
      setNewComment('');
      setNewTitle('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6">
      <div className="relative bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 text-slate-400 hover:text-slate-700 bg-white/80 hover:bg-slate-100 rounded-full transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left: Product Media Gallery */}
            <div className="flex flex-col gap-4">
              <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-slate-200 relative">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {hasDiscount && (
                  <span className="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-2.5 py-1 rounded shadow">
                    Save {discountPercent}%
                  </span>
                )}
              </div>

              {/* Retailer Info Strip */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500 font-medium">Sold & fulfilled by:</div>
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-1.5 mt-0.5">
                    <span>{product.retailerName}</span>
                    <span title="Verified Nigerian Independent Business">
                      <CheckCircle className="w-4 h-4 text-red-600" />
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Retailer Rating</div>
                  <div className="text-xs font-semibold text-slate-800 flex items-center justify-end gap-1 mt-0.5">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>4.9 / 5.0</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Contiguous Purchase Module */}
            <div className="flex flex-col justify-between">
              <div>
                {/* Category & SKU */}
                <div className="text-xs text-slate-500 flex items-center gap-2 mb-1.5">
                  <span>{product.categoryName}</span>
                  {product.sku && (
                    <>
                      <span>·</span>
                      <span>SKU: {product.sku}</span>
                    </>
                  )}
                </div>

                {/* Title */}
                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                  {product.name}
                </h1>

                {/* Price Display */}
                <div className="mt-4 flex items-baseline gap-3">
                  <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                    {formatNaira(activePriceKobo)}
                  </span>
                  {hasDiscount && (
                    <span className="text-base text-slate-400 line-through tabular-nums">
                      {formatNaira(product.compareAtPriceKobo!)}
                    </span>
                  )}
                </div>

                {/* Variants Selection */}
                {product.variants && product.variants.length > 0 && (
                  <div className="mt-5">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                      Select Variant / Option:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {product.variants.map((v) => {
                        const isSelected = selectedVariant?.id === v.id;
                        return (
                          <button
                            key={v.id}
                            onClick={() => setSelectedVariant(v)}
                            className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-all ${
                              isSelected
                                ? 'border-slate-900 bg-slate-900 text-white shadow-sm'
                                : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                            }`}
                          >
                            <span>{v.name}</span>
                            <span className="ml-1.5 opacity-80">({formatNaira(v.priceKobo)})</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Quantity Stepper & Stock Warning */}
                <div className="mt-5 flex items-center gap-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Quantity:
                    </label>
                    <div className="flex items-center border border-slate-300 rounded-lg overflow-hidden bg-white">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        disabled={quantity <= 1 || isOutOfStock}
                        className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-4 text-xs font-bold text-slate-900 tabular-nums">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity(Math.min(availableStock, quantity + 1))}
                        disabled={quantity >= availableStock || isOutOfStock}
                        className="p-2 text-slate-600 hover:bg-slate-100 disabled:opacity-40"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="pt-5 text-xs">
                    {isOutOfStock ? (
                      <span className="text-rose-600 font-semibold">Out of Stock</span>
                    ) : availableStock <= 5 ? (
                      <span className="text-amber-700 font-medium">
                        Only {availableStock} left in stock
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> In Stock & Ready to Dispatch
                      </span>
                    )}
                  </div>
                </div>

                {/* CTAs: Add to Cart and Buy Now */}
                <div className="mt-6 flex flex-col sm:flex-row gap-3">
                  <button
                    onClick={() => onAddToCart(product, selectedVariant?.id, quantity)}
                    disabled={isOutOfStock}
                    className="flex-1 min-h-[46px] px-5 py-2.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 active:scale-95 font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Cart</span>
                  </button>
                  <button
                    onClick={() => onBuyNow(product, selectedVariant?.id, quantity)}
                    disabled={isOutOfStock}
                    className="flex-1 min-h-[46px] px-5 py-2.5 rounded-xl bg-red-600 text-white hover:bg-red-700 active:scale-95 font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
                  >
                    <span>Instant Checkout</span>
                  </button>
                </div>
              </div>

              {/* Delivery & Returns Info */}
              <div className="mt-6 pt-5 border-t border-slate-200 grid grid-cols-2 gap-4 text-xs text-slate-600">
                <div className="flex items-start gap-2">
                  <Truck className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-900 block">Delivery Terms</span>
                    <span>{product.deliveryInfo || '24-48 hours delivery across Lagos and major cities.'}</span>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <RotateCcw className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-900 block">Returns Policy</span>
                    <span>{product.returnPolicy || '7-day verified return policy.'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Description Section */}
          <div className="mt-10 pt-6 border-t border-slate-200">
            <h3 className="text-base font-bold text-slate-900 mb-2">Product Description</h3>
            <p className="text-sm text-slate-700 leading-relaxed max-w-3xl whitespace-pre-line">
              {product.description}
            </p>
          </div>

          {/* Verified Customer Reviews Section */}
          <div className="mt-10 pt-6 border-t border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-red-600" />
                <span>Customer Reviews ({product.reviewCount})</span>
              </h3>
            </div>

            {/* Existing Reviews List */}
            {product.reviews && product.reviews.length > 0 ? (
              <div className="space-y-4 mb-8">
                {product.reviews.map((rev) => (
                  <div key={rev.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200/80">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-900">{rev.customerName}</span>
                        {rev.isVerifiedPurchase && (
                          <span className="text-[11px] text-emerald-700 font-medium flex items-center gap-0.5">
                            <CheckCircle className="w-3 h-3" /> Verified Purchase
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-slate-400">{formatDate(rev.createdAt)}</span>
                    </div>

                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3.5 h-3.5 ${
                            i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                          }`}
                        />
                      ))}
                    </div>

                    {rev.title && <h4 className="text-xs font-bold text-slate-800 mb-1">{rev.title}</h4>}
                    <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 mb-6 italic">No reviews yet for this product. Be the first to review!</p>
            )}

            {/* Leave a review form */}
            <form onSubmit={handleReviewSubmit} className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-3">
                Write a Verified Product Review
              </h4>
              {reviewSuccess ? (
                <div className="p-3 bg-emerald-50 text-emerald-700 text-xs rounded-lg font-medium">
                  Thank you! Your verified review has been posted.
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-600 font-medium">Rating:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((num) => (
                        <button
                          type="button"
                          key={num}
                          onClick={() => setNewRating(num)}
                          className="p-1 focus:outline-none"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              num <= newRating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <input
                      type="text"
                      placeholder="Review Headline (optional)"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800 bg-white"
                    />
                  </div>

                  <div>
                    <textarea
                      placeholder="Share your experience with the item quality, fit, or delivery..."
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      required
                      rows={3}
                      className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:outline-none focus:border-slate-800 bg-white"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview || !newComment.trim()}
                    className="min-h-[38px] px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 disabled:opacity-50"
                  >
                    {isSubmittingReview ? 'Submitting...' : 'Post Review'}
                  </button>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
