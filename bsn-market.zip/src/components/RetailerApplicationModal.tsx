/**
 * BSN Market Retailer Registration / Application Modal
 * Section 3.B: "Sell on BSN Market" application flow
 */

import React, { useState } from 'react';
import { X, Store, ShieldCheck, CheckCircle, ArrowRight } from 'lucide-react';
import { api } from '../services/api.ts';
import { NIGERIAN_STATES } from '../utils/format.ts';

interface RetailerApplicationModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
}

export const RetailerApplicationModal: React.FC<RetailerApplicationModalProps> = ({
  isOpen,
  onClose,
  userId
}) => {
  if (!isOpen) return null;

  const [businessName, setBusinessName] = useState('');
  const [cacRegNumber, setCacRegNumber] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [businessType, setBusinessType] = useState('Fashion & Footwear Retailer');
  const [state, setState] = useState('Lagos');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [bankName, setBankName] = useState('Access Bank');
  const [bankAccountNumber, setBankAccountNumber] = useState('');
  const [bankAccountName, setBankAccountName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await api.applyAsRetailer({
        userId,
        businessName,
        cacRegNumber: cacRegNumber || undefined,
        contactPerson,
        email,
        phone,
        businessType,
        state,
        city,
        address,
        bankName,
        bankAccountNumber,
        bankAccountName
      });
      setIsSubmitted(true);
    } catch (err: any) {
      alert(err.message || 'Application failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-red-600" />
            <span className="font-bold text-slate-900 text-sm">Sell on BSN Market</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {isSubmitted ? (
            <div className="text-center py-8 space-y-3">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Application Submitted!</h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                Our verification team will review your business information and CAC registration. Once approved, you can immediately access your Retailer Portal and list products.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-6 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800"
              >
                Return to Marketplace
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-red-50/70 border border-red-100 rounded-lg text-slate-700 text-[11px] flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-red-600 shrink-0" />
                <span>Join vetted Nigerian retailers reaching customers nationwide with protected payouts.</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Registered Business Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lagos Modern Living Ltd"
                  value={businessName}
                  onChange={(e) => setBusinessName(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">CAC Registration (RC/BN)</label>
                  <input
                    type="text"
                    placeholder="e.g. RC-1849204"
                    value={cacRegNumber}
                    onChange={(e) => setCacRegNumber(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Primary Product Category *</label>
                  <select
                    value={businessType}
                    onChange={(e) => setBusinessType(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg bg-white"
                  >
                    <option value="Fashion & Footwear">Fashion and Footwear</option>
                    <option value="Phones and Electronics Accessories">Phones & Electronics</option>
                    <option value="Beauty and Personal Care">Beauty and Personal Care</option>
                    <option value="Food and Household Essentials">Food & Household Essentials</option>
                    <option value="Home and Kitchen">Home and Kitchen</option>
                    <option value="Bags and Accessories">Bags and Accessories</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Contact Person *</label>
                  <input
                    type="text"
                    required
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="0803 000 0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Business Email *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">State *</label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg bg-white"
                  >
                    {NIGERIAN_STATES.map((st) => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">City / LGA *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ikeja, Wuse 2"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Physical Store / Warehouse Address *</label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg"
                />
              </div>

              {/* Settlement Bank Details */}
              <div className="pt-3 border-t">
                <span className="font-bold text-slate-900 block mb-2">Nigerian Settlement Bank Details</span>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block font-medium text-slate-600 mb-1">Bank</label>
                    <input
                      type="text"
                      required
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      className="w-full px-2.5 py-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-600 mb-1">Account No.</label>
                    <input
                      type="text"
                      required
                      placeholder="10 digits"
                      value={bankAccountNumber}
                      onChange={(e) => setBankAccountNumber(e.target.value)}
                      className="w-full px-2.5 py-2 border rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-600 mb-1">Account Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Account Title"
                      value={bankAccountName}
                      onChange={(e) => setBankAccountName(e.target.value)}
                      className="w-full px-2.5 py-2 border rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full min-h-[44px] py-2.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>{isSubmitting ? 'Submitting Application...' : 'Submit Vendor Application'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
