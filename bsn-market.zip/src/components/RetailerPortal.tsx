/**
 * BSN Market Retailer Portal & Merchant Dashboard
 * Section 5: Protected dashboard for verified Nigerian retailers
 */

import React, { useState, useEffect } from 'react';
import {
  Store,
  Package,
  ShoppingBag,
  Clock,
  CheckCircle,
  Truck,
  AlertTriangle,
  Plus,
  DollarSign,
  TrendingUp,
  FileText,
  Settings,
  HelpCircle,
  ShieldCheck,
  Search,
  ChevronRight,
  X
} from 'lucide-react';
import { RetailerProfile, RetailerStats, RetailerSubOrder, Product, Category } from '../types/index.ts';
import { formatNaira, formatDate, STATUS_CONFIG } from '../utils/format.ts';
import { api } from '../services/api.ts';

interface RetailerPortalProps {
  retailer: RetailerProfile | null;
  onClose: () => void;
  categories: Category[];
}

export const RetailerPortal: React.FC<RetailerPortalProps> = ({
  retailer,
  onClose,
  categories
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'products' | 'settlements' | 'settings'>('overview');
  const [stats, setStats] = useState<RetailerStats | null>(null);
  const [orders, setOrders] = useState<RetailerSubOrder[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Order action state
  const [actionOrder, setActionOrder] = useState<RetailerSubOrder | null>(null);
  const [actionType, setActionType] = useState<'confirm' | 'reject' | 'processing' | 'dispatch' | 'delivered' | null>(null);
  const [courierName, setCourierName] = useState('GIG Logistics');
  const [trackingNumber, setTrackingNumber] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [isUpdatingOrder, setIsUpdatingOrder] = useState(false);

  // New product form state
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCat, setNewProdCat] = useState(categories[0]?.id || 'cat-fashion');
  const [newProdPrice, setNewProdPrice] = useState('');
  const [newProdCompare, setNewProdCompare] = useState('');
  const [newProdStock, setNewProdStock] = useState('15');
  const [newProdSku, setNewProdSku] = useState('');
  const [newProdDesc, setNewProdDesc] = useState('');
  const [newProdDelivery, setNewProdDelivery] = useState('Ships within 24 hours via Lagos courier.');
  const [newProdReturn, setNewProdReturn] = useState('7-day verified return guarantee.');
  const [newProdImg, setNewProdImg] = useState('/src/assets/images/category_fashion_ankara_1791585893952.jpg');
  const [isSavingProduct, setIsSavingProduct] = useState(false);

  const retailerId = retailer?.id || 'ret-zaria-01';

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [statsData, ordersData, prodsData] = await Promise.all([
        api.getRetailerStats(retailerId),
        api.getRetailerOrders(retailerId),
        api.getRetailerProducts(retailerId)
      ]);
      setStats(statsData);
      setOrders(ordersData);
      setProducts(prodsData);
    } catch (err) {
      console.error('Failed to load retailer data', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [retailerId]);

  const handleOrderActionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionOrder || !actionType) return;
    setIsUpdatingOrder(true);
    try {
      await api.updateRetailerOrderStatus(actionOrder.id, actionType, {
        retailerId,
        reason: rejectReason || undefined,
        courierName: courierName || undefined,
        trackingReference: trackingNumber || undefined
      });
      setActionOrder(null);
      setActionType(null);
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    } finally {
      setIsUpdatingOrder(false);
    }
  };

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProdName.trim() || !newProdPrice) return;
    setIsSavingProduct(true);
    try {
      const catObj = categories.find(c => c.id === newProdCat);
      await api.createRetailerProduct({
        retailerId,
        retailerName: retailer?.businessName || 'Zaria Wears & Textiles',
        categoryId: newProdCat,
        categoryName: catObj?.name || 'General',
        name: newProdName.trim(),
        slug: newProdName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        description: newProdDesc.trim(),
        sku: newProdSku.trim() || undefined,
        priceKobo: Math.round(Number(newProdPrice) * 100),
        compareAtPriceKobo: newProdCompare ? Math.round(Number(newProdCompare) * 100) : undefined,
        stockQuantity: Number(newProdStock) || 1,
        lowStockThreshold: 3,
        images: [newProdImg],
        variants: [],
        deliveryInfo: newProdDelivery,
        returnPolicy: newProdReturn
      });
      setShowAddProduct(false);
      setNewProdName('');
      setNewProdPrice('');
      setNewProdCompare('');
      setNewProdDesc('');
      await loadData();
    } catch (err: any) {
      alert(err.message || 'Failed to submit product');
    } finally {
      setIsSavingProduct(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex justify-center p-3 sm:p-6">
      <div className="relative bg-white rounded-2xl max-w-6xl w-full max-h-[92vh] overflow-hidden shadow-2xl flex flex-col border border-slate-200">
        {/* Top Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  {retailer?.businessName || 'Zaria Wears & Textiles'}
                </h2>
                <span className="text-[10px] bg-red-500/20 text-red-300 border border-red-500/30 font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-red-400" /> CAC VERIFIED
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Independent Retailer Dashboard · {retailer?.city || 'Ikeja'}, {retailer?.state || 'Lagos'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 flex items-center gap-2 overflow-x-auto text-xs font-semibold shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'orders'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Orders</span>
            {stats && stats.awaitingConfirmationCount > 0 && (
              <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full tabular-nums">
                {stats.awaitingConfirmationCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('products')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'products'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Products ({products.length})
          </button>
          <button
            onClick={() => setActiveTab('settlements')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'settlements'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Settlements & Payouts
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'settings'
                ? 'border-red-600 text-red-600 bg-white'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Store Profile
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="py-20 text-center text-slate-400">Loading retailer data...</div>
          ) : (
            <>
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && stats && (
                <div className="space-y-6">
                  {/* KPI Metric Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                      <div className="text-xs text-slate-500 font-medium">Gross Sales Value</div>
                      <div className="text-xl font-bold text-slate-900 mt-1 tabular-nums">
                        {formatNaira(stats.grossSalesKobo)}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">From completed & active orders</div>
                    </div>

                    <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200">
                      <div className="text-xs text-amber-800 font-medium">Awaiting Confirmation</div>
                      <div className="text-xl font-bold text-amber-900 mt-1 tabular-nums">
                        {stats.awaitingConfirmationCount}
                      </div>
                      <div className="text-[11px] text-amber-700 mt-1">Requires retailer confirmation</div>
                    </div>

                    <div className="p-4 rounded-xl bg-purple-50/60 border border-purple-200">
                      <div className="text-xs text-purple-800 font-medium">In Processing / Transit</div>
                      <div className="text-xl font-bold text-purple-900 mt-1 tabular-nums">
                        {stats.processingCount}
                      </div>
                      <div className="text-[11px] text-purple-700 mt-1">Packaging or handed to courier</div>
                    </div>

                    <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200">
                      <div className="text-xs text-emerald-800 font-medium">Pending Settlement</div>
                      <div className="text-xl font-bold text-emerald-900 mt-1 tabular-nums">
                        {formatNaira(stats.pendingSettlementKobo)}
                      </div>
                      <div className="text-[11px] text-emerald-700 mt-1">Net amount due for payout</div>
                    </div>
                  </div>

                  {/* Commission Notice */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-slate-700" />
                      <span>
                        Commission policy: Standard <strong>{retailer?.commissionRateOverride || 10}%</strong> platform deduction applies on fulfilled merchandise.
                      </span>
                    </div>
                    <div className="font-semibold text-slate-900">
                      Commission Deducted: {formatNaira(stats.commissionDeductionsKobo)}
                    </div>
                  </div>

                  {/* Low Stock Alerts */}
                  {stats.lowStockItemsCount > 0 && (
                    <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-between text-xs text-rose-800">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span><strong>{stats.lowStockItemsCount} items</strong> are at or below their low-stock threshold. Restock recommended.</span>
                      </div>
                      <button
                        onClick={() => setActiveTab('products')}
                        className="font-bold underline hover:text-rose-900"
                      >
                        Inspect Inventory
                      </button>
                    </div>
                  )}

                  {/* Recent Orders List */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                        Recent Retailer Orders
                      </h3>
                      <button
                        onClick={() => setActiveTab('orders')}
                        className="text-xs font-semibold text-red-600 hover:text-red-700"
                      >
                        View All Orders →
                      </button>
                    </div>

                    {orders.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                        No orders assigned to your store yet.
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {orders.slice(0, 3).map((o) => {
                          const cfg = STATUS_CONFIG[o.fulfilmentStatus] || STATUS_CONFIG.order_placed;
                          return (
                            <div key={o.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
                              <div>
                                <div className="font-bold text-slate-900">{o.retailerOrderRef}</div>
                                <div className="text-slate-500 mt-0.5">{o.items.length} item(s) · {formatDate(o.createdAt)}</div>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className={`font-bold px-2 py-0.5 rounded border text-[11px] ${cfg.bg} ${cfg.text} ${cfg.border}`}>
                                  {cfg.label}
                                </span>
                                <span className="font-extrabold text-slate-900 tabular-nums">
                                  {formatNaira(o.subtotalKobo)}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: ORDERS MANAGEMENT */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Order Fulfilment Pipeline ({orders.length})
                    </h3>
                  </div>

                  {orders.length === 0 ? (
                    <div className="p-12 text-center text-slate-400 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                      No orders for this store yet.
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => {
                        const cfg = STATUS_CONFIG[order.fulfilmentStatus] || STATUS_CONFIG.order_placed;
                        return (
                          <div
                            key={order.id}
                            className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-4"
                          >
                            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/80 pb-3">
                              <div>
                                <span className="font-bold text-slate-900 text-sm">{order.retailerOrderRef}</span>
                                <span className="text-xs text-slate-500 ml-2">({formatDate(order.createdAt)})</span>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className={`text-xs font-bold px-2.5 py-1 rounded border ${cfg.bg} ${cfg.text} ${cfg.border}`}>
                                  {cfg.label}
                                </span>
                                <span className="font-extrabold text-slate-900 text-sm tabular-nums">
                                  Net: {formatNaira(order.retailerPayableKobo)}
                                </span>
                              </div>
                            </div>

                            {/* Order Items */}
                            <div className="space-y-2">
                              {order.items.map((it) => (
                                <div key={it.id} className="flex items-center justify-between text-xs py-1">
                                  <div className="flex items-center gap-2">
                                    <span className="font-bold text-slate-500">{it.quantity}x</span>
                                    <span className="font-semibold text-slate-800">{it.productName}</span>
                                    {it.variantName && <span className="text-slate-400">({it.variantName})</span>}
                                  </div>
                                  <span className="font-bold text-slate-900 tabular-nums">
                                    {formatNaira(it.subtotalKobo)}
                                  </span>
                                </div>
                              ))}
                            </div>

                            {/* Financial snapshot */}
                            <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-600 flex flex-wrap justify-between gap-4">
                              <div>Gross: <strong>{formatNaira(order.subtotalKobo)}</strong></div>
                              <div>Commission ({order.commissionRateSnapshot}%): <strong>{formatNaira(order.commissionAmountKobo)}</strong></div>
                              <div>Settlement Payout: <strong className="text-emerald-700">{formatNaira(order.retailerPayableKobo)}</strong></div>
                              <div>Status: <strong>{order.settlementStatus.toUpperCase()}</strong></div>
                            </div>

                            {/* Retailer Action Toolbar */}
                            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200/80">
                              {order.fulfilmentStatus === 'payment_confirmed' && (
                                <>
                                  <button
                                    onClick={() => {
                                      setActionOrder(order);
                                      setActionType('confirm');
                                    }}
                                    className="px-3.5 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800"
                                  >
                                    Confirm Order
                                  </button>
                                  <button
                                    onClick={() => {
                                      setActionOrder(order);
                                      setActionType('reject');
                                    }}
                                    className="px-3.5 py-1.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold hover:bg-rose-100"
                                  >
                                    Reject Order
                                  </button>
                                </>
                              )}

                              {order.fulfilmentStatus === 'retailer_confirmed' && (
                                <button
                                  onClick={() => {
                                    setActionOrder(order);
                                    setActionType('processing');
                                  }}
                                  className="px-3.5 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-semibold hover:bg-purple-700"
                                >
                                  Mark Packaging / In Progress
                                </button>
                              )}

                              {order.fulfilmentStatus === 'processing' && (
                                <button
                                  onClick={() => {
                                    setActionOrder(order);
                                    setActionType('dispatch');
                                  }}
                                  className="px-3.5 py-1.5 bg-cyan-700 text-white rounded-lg text-xs font-semibold hover:bg-cyan-800 flex items-center gap-1.5"
                                >
                                  <Truck className="w-3.5 h-3.5" />
                                  <span>Dispatch to Courier</span>
                                </button>
                              )}

                              {order.fulfilmentStatus === 'dispatched' && (
                                <button
                                  onClick={() => {
                                    setActionOrder(order);
                                    setActionType('delivered');
                                  }}
                                  className="px-3.5 py-1.5 bg-emerald-600 text-white rounded-lg text-xs font-semibold hover:bg-emerald-700 flex items-center gap-1.5"
                                >
                                  <CheckCircle className="w-3.5 h-3.5" />
                                  <span>Mark Delivered</span>
                                </button>
                              )}

                              {order.trackingReference && (
                                <span className="text-xs text-slate-500 font-mono ml-auto">
                                  Courier: {order.courierName} ({order.trackingReference})
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: PRODUCTS */}
              {activeTab === 'products' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Product Catalogue ({products.length})
                    </h3>
                    <button
                      onClick={() => setShowAddProduct(true)}
                      className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-semibold hover:bg-slate-800 flex items-center gap-1.5 shadow-sm"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New Product Listing</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {products.map((p) => {
                      const pCfg = STATUS_CONFIG[p.status] || STATUS_CONFIG.approved;
                      return (
                        <div
                          key={p.id}
                          className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex gap-4 text-xs"
                        >
                          <div className="w-20 h-20 rounded-lg overflow-hidden bg-slate-200 shrink-0 border border-slate-200">
                            <img
                              src={p.images[0]}
                              alt={p.name}
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          </div>

                          <div className="flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex items-center justify-between gap-1">
                                <span className="font-bold text-slate-900 text-sm line-clamp-1">
                                  {p.name}
                                </span>
                                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${pCfg.bg} ${pCfg.text} ${pCfg.border}`}>
                                  {pCfg.label}
                                </span>
                              </div>
                              <span className="text-slate-500 mt-0.5 block">{p.categoryName}</span>
                            </div>

                            <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200">
                              <span className="font-extrabold text-slate-900 tabular-nums">
                                {formatNaira(p.priceKobo)}
                              </span>
                              <span className={`font-semibold ${p.stockQuantity <= 3 ? 'text-rose-600' : 'text-slate-600'}`}>
                                Stock: {p.stockQuantity} units
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 4: SETTLEMENTS */}
              {activeTab === 'settlements' && stats && (
                <div className="space-y-6">
                  <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                      Retailer Bank Account For Settlement Transfers
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                      <div>
                        <span className="text-slate-500 block">Bank Name</span>
                        <span className="font-bold text-slate-900">{retailer?.bankName || 'Access Bank'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Account Number</span>
                        <span className="font-mono font-bold text-slate-900">{retailer?.bankAccountNumber || '0129845512'}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block">Beneficiary Name</span>
                        <span className="font-bold text-slate-900">{retailer?.bankAccountName || 'Zaria Wears Ltd'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="text-xs text-slate-500">Gross Lifetime Sales</div>
                      <div className="text-xl font-bold text-slate-900 mt-1 tabular-nums">{formatNaira(stats.grossSalesKobo)}</div>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="text-xs text-slate-500">Commission Deductions</div>
                      <div className="text-xl font-bold text-slate-900 mt-1 tabular-nums">{formatNaira(stats.commissionDeductionsKobo)}</div>
                    </div>
                    <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                      <div className="text-xs text-emerald-800 font-medium">Pending Settlement</div>
                      <div className="text-xl font-bold text-emerald-900 mt-1 tabular-nums">{formatNaira(stats.pendingSettlementKobo)}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: STORE PROFILE */}
              {activeTab === 'settings' && (
                <div className="space-y-4 max-w-xl text-xs">
                  <h3 className="font-bold uppercase tracking-wider text-slate-800 text-xs">
                    Registered Business Information
                  </h3>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div>
                      <span className="text-slate-500">Business Name:</span>
                      <p className="font-bold text-slate-900 text-sm mt-0.5">{retailer?.businessName}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">CAC Registration:</span>
                      <p className="font-mono font-semibold text-slate-800 mt-0.5">{retailer?.cacRegNumber || 'RC-1849204'}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">Physical Address:</span>
                      <p className="font-medium text-slate-800 mt-0.5">{retailer?.physicalAddress || '14 Allen Avenue, Ikeja, Lagos'}</p>
                    </div>
                    <div>
                      <span className="text-slate-500">Contact Phone:</span>
                      <p className="font-medium text-slate-800 mt-0.5">{retailer?.phone || '+234 803 456 7890'}</p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Modal: Order Action (Confirm, Reject, Dispatch) */}
        {actionOrder && actionType && (
          <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
              <h3 className="font-bold text-slate-900 text-sm mb-3">
                {actionType === 'confirm' && 'Confirm Order Acceptance'}
                {actionType === 'reject' && 'Reject Order with Reason'}
                {actionType === 'processing' && 'Mark Order In Processing'}
                {actionType === 'dispatch' && 'Dispatch Order to Nigerian Courier'}
                {actionType === 'delivered' && 'Confirm Delivery'}
              </h3>

              <form onSubmit={handleOrderActionSubmit} className="space-y-4 text-xs">
                {actionType === 'reject' && (
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Reason for Rejection *</label>
                    <textarea
                      required
                      rows={3}
                      placeholder="e.g. Item currently out of stock; refund required"
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg"
                    />
                  </div>
                )}

                {actionType === 'dispatch' && (
                  <>
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">Courier Service</label>
                      <input
                        type="text"
                        value={courierName}
                        onChange={(e) => setCourierName(e.target.value)}
                        placeholder="e.g. Kwik, GIG Logistics, DHL"
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-700 font-semibold mb-1">Tracking Code / Rider Phone</label>
                      <input
                        type="text"
                        required
                        value={trackingNumber}
                        onChange={(e) => setTrackingNumber(e.target.value)}
                        placeholder="e.g. GIG-184921 / 0803 999 8888"
                        className="w-full px-3 py-2 border rounded-lg"
                      />
                    </div>
                  </>
                )}

                <p className="text-slate-600">
                  Target: <strong>{actionOrder.retailerOrderRef}</strong> ({formatNaira(actionOrder.retailerPayableKobo)})
                </p>

                <div className="flex gap-2 justify-end pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setActionOrder(null);
                      setActionType(null);
                    }}
                    className="px-4 py-2 text-slate-600 hover:text-slate-900 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isUpdatingOrder}
                    className="px-4 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 disabled:opacity-50"
                  >
                    {isUpdatingOrder ? 'Updating...' : 'Confirm Action'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Modal: Add New Product */}
        {showAddProduct && (
          <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b mb-4">
                <h3 className="font-bold text-slate-900 text-sm">Create Product for Moderation</h3>
                <button onClick={() => setShowAddProduct(false)} className="text-slate-400 hover:text-slate-700">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={newProdName}
                    onChange={(e) => setNewProdName(e.target.value)}
                    placeholder="e.g. Embroidered Traditional Kaftan"
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Category *</label>
                    <select
                      value={newProdCat}
                      onChange={(e) => setNewProdCat(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg bg-white"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Stock Quantity *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={newProdStock}
                      onChange={(e) => setNewProdStock(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Price (₦ Naira) *</label>
                    <input
                      type="number"
                      required
                      placeholder="e.g. 25000"
                      value={newProdPrice}
                      onChange={(e) => setNewProdPrice(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Compare-at Price (optional)</label>
                    <input
                      type="number"
                      placeholder="e.g. 30000"
                      value={newProdCompare}
                      onChange={(e) => setNewProdCompare(e.target.value)}
                      className="w-full px-3 py-2 border rounded-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Description *</label>
                  <textarea
                    required
                    rows={3}
                    value={newProdDesc}
                    onChange={(e) => setNewProdDesc(e.target.value)}
                    placeholder="Describe material, fit, specifications..."
                    className="w-full px-3 py-2 border rounded-lg"
                  />
                </div>

                <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-[11px]">
                  All new retailer products enter the BSN administrator moderation queue before becoming purchasable by customers.
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddProduct(false)}
                    className="px-4 py-2 text-slate-600 font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingProduct}
                    className="px-4 py-2 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 disabled:opacity-50"
                  >
                    {isSavingProduct ? 'Submitting...' : 'Submit for Review'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
