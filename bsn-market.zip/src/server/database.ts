/**
 * BSN Market Database Engine & Seed Store
 * Server-side persistent storage with atomic JSON writes and relational constraints
 */

import fs from 'fs';
import path from 'path';
import {
  UserProfile,
  RetailerProfile,
  RetailerApplication,
  Category,
  Product,
  ProductReview,
  Order,
  RetailerSubOrder,
  OrderItem,
  PaymentRecord,
  RetailerSettlement,
  DiscountCode,
  InAppNotification,
  AuditLogEntry,
  PlatformMetrics,
  RetailerStats,
  OrderStatus,
  PaymentStatus,
  SettlementStatus
} from '../types/index.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'bsn_market_db.json');

export interface DatabaseState {
  users: UserProfile[];
  retailers: RetailerProfile[];
  retailerApplications: RetailerApplication[];
  categories: Category[];
  products: Product[];
  orders: Order[];
  payments: PaymentRecord[];
  settlements: RetailerSettlement[];
  discountCodes: DiscountCode[];
  notifications: InAppNotification[];
  auditLogs: AuditLogEntry[];
}

// Initial Seed Data with Nigerian Retailers and Products
const INITIAL_USERS: UserProfile[] = [
  {
    id: 'user-admin-01',
    fullName: 'Barrister Street Administrator',
    email: 'admin@bsnmarket.ng',
    phoneNumber: '+234 802 000 0001',
    role: 'admin',
    createdAt: '2026-01-01T00:00:00.000Z'
  },
  {
    id: 'user-retailer-01',
    fullName: 'Amina Bello',
    email: 'amina@zariawears.ng',
    phoneNumber: '+234 803 456 7890',
    role: 'retailer',
    createdAt: '2026-01-10T10:00:00.000Z'
  },
  {
    id: 'user-retailer-02',
    fullName: 'Emeka Okafor',
    email: 'emeka@ekogadgets.ng',
    phoneNumber: '+234 805 789 1234',
    role: 'retailer',
    createdAt: '2026-01-12T11:00:00.000Z'
  },
  {
    id: 'user-customer-01',
    fullName: 'Kobi Asy',
    email: 'asy.kobi@gmail.com',
    phoneNumber: '+234 809 333 4455',
    role: 'customer',
    createdAt: '2026-02-01T09:00:00.000Z'
  }
];

const INITIAL_RETAILERS: RetailerProfile[] = [
  {
    id: 'ret-zaria-01',
    ownerId: 'user-retailer-01',
    businessName: 'Zaria Wears & Textiles',
    businessSlug: 'zaria-wears',
    cacRegNumber: 'RC-1849204',
    description: 'Premier contemporary Nigerian ready-to-wear, structured Ankara formal wear, and luxury linen couture.',
    phone: '+234 803 456 7890',
    email: 'orders@zariawears.ng',
    state: 'Lagos',
    city: 'Ikeja',
    physicalAddress: '14 Allen Avenue, Ikeja, Lagos State',
    bankName: 'Access Bank',
    bankAccountNumber: '0129845512',
    bankAccountName: 'Zaria Wears Enterprises Ltd',
    status: 'approved',
    commissionRateOverride: 9.0, // 9% negotiated commission
    rating: 4.9,
    reviewCount: 38,
    verifiedBadge: true,
    createdAt: '2026-01-10T10:00:00.000Z',
    updatedAt: '2026-03-01T12:00:00.000Z'
  },
  {
    id: 'ret-eko-02',
    ownerId: 'user-retailer-02',
    businessName: 'Eko Gadgets Hub',
    businessSlug: 'eko-gadgets',
    cacRegNumber: 'RC-2049100',
    description: 'Direct importer of genuine smartphone accessories, high-speed charging cables, and certified wireless audio.',
    phone: '+234 805 789 1234',
    email: 'sales@ekogadgets.ng',
    state: 'Lagos',
    city: 'Ikeja',
    physicalAddress: 'Shop 8, Computer Village, Ikeja, Lagos State',
    bankName: 'Guaranty Trust Bank (GTBank)',
    bankAccountNumber: '0238841921',
    bankAccountName: 'Eko Gadgets Technologies',
    status: 'approved',
    commissionRateOverride: 8.5,
    rating: 4.8,
    reviewCount: 52,
    verifiedBadge: true,
    createdAt: '2026-01-12T11:00:00.000Z',
    updatedAt: '2026-03-02T14:00:00.000Z'
  },
  {
    id: 'ret-lekki-03',
    ownerId: 'user-retailer-03',
    businessName: 'Lekki Glow Organics',
    businessSlug: 'lekki-glow',
    cacRegNumber: 'BN-3194012',
    description: 'Handcrafted raw unrefined shea butter, Nigerian cold-pressed botanical oils, and natural skincare treatments.',
    phone: '+234 812 345 6789',
    email: 'contact@lekkiglow.com',
    state: 'Lagos',
    city: 'Lekki',
    physicalAddress: 'Plot 22 Admiralty Way, Lekki Phase 1, Lagos',
    bankName: 'Zenith Bank',
    bankAccountNumber: '1014928471',
    bankAccountName: 'Lekki Glow Wellness Care',
    status: 'approved',
    rating: 5.0,
    reviewCount: 44,
    verifiedBadge: true,
    createdAt: '2026-01-15T09:00:00.000Z',
    updatedAt: '2026-03-01T10:00:00.000Z'
  },
  {
    id: 'ret-kano-04',
    ownerId: 'user-retailer-04',
    businessName: 'Kano Heritage Pantry',
    businessSlug: 'kano-pantry',
    cacRegNumber: 'RC-992140',
    description: 'Authentic Nigerian northern spices, artisanal raw honey, premium roasted cashews, and organic dried hibiscus.',
    phone: '+234 806 991 2233',
    email: 'orders@kanopantry.ng',
    state: 'Kano',
    city: 'Fagge',
    physicalAddress: '7 Bompai Road, Fagge, Kano State',
    bankName: 'First Bank of Nigeria',
    bankAccountNumber: '2019482910',
    bankAccountName: 'Kano Heritage Foods',
    status: 'approved',
    rating: 4.9,
    reviewCount: 29,
    verifiedBadge: true,
    createdAt: '2026-01-18T14:00:00.000Z',
    updatedAt: '2026-03-05T11:00:00.000Z'
  },
  {
    id: 'ret-abuja-05',
    ownerId: 'user-retailer-05',
    businessName: 'Abuja Leathercraft Vault',
    businessSlug: 'abuja-leathercraft',
    cacRegNumber: 'BN-882194',
    description: 'Fine genuine leather briefcases, handcrafted weekend bags, and bespoke leather footwear made in Abuja.',
    phone: '+234 807 441 5522',
    email: 'leather@abujavault.com',
    state: 'FCT Abuja',
    city: 'Wuse 2',
    physicalAddress: 'Aminu Kano Crescent, Wuse 2, Abuja',
    bankName: 'Stanbic IBTC',
    bankAccountNumber: '0039281726',
    bankAccountName: 'Abuja Leather Studio',
    status: 'approved',
    rating: 4.7,
    reviewCount: 19,
    verifiedBadge: true,
    createdAt: '2026-01-22T16:00:00.000Z',
    updatedAt: '2026-03-06T15:00:00.000Z'
  }
];

const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-fashion',
    name: 'Fashion and Footwear',
    slug: 'fashion-and-footwear',
    description: 'Contemporary Nigerian ready-to-wear, bespoke tailoring, traditional textiles, and designer footwear.',
    displayOrder: 1,
    isActive: true,
    defaultCommissionRate: 10.0,
    imageUrl: '/src/assets/images/category_fashion_ankara_1791585893952.jpg'
  },
  {
    id: 'cat-tech',
    name: 'Phones and Electronics Accessories',
    slug: 'phones-and-electronics-accessories',
    description: 'Certified audio gear, braided fast chargers, power banks, and smartphone accessories.',
    displayOrder: 2,
    isActive: true,
    defaultCommissionRate: 8.0,
    imageUrl: '/src/assets/images/category_tech_gadgets_1791585903912.jpg'
  },
  {
    id: 'cat-beauty',
    name: 'Beauty and Personal Care',
    slug: 'beauty-and-personal-care',
    description: 'Unrefined shea butter, organic facial glow oils, black soaps, and holistic wellness.',
    displayOrder: 3,
    isActive: true,
    defaultCommissionRate: 10.0,
    imageUrl: '/src/assets/images/category_beauty_skincare_1791585915844.jpg'
  },
  {
    id: 'cat-food',
    name: 'Food and Household Essentials',
    slug: 'food-and-household-essentials',
    description: 'Raw forest honey, authentic northern suya spices, organic dried hibiscus zobo, and gourmet snacks.',
    displayOrder: 4,
    isActive: true,
    defaultCommissionRate: 7.5,
    imageUrl: '/src/assets/images/category_food_pantry_1791585926747.jpg'
  },
  {
    id: 'cat-home',
    name: 'Home and Kitchen',
    slug: 'home-and-kitchen',
    description: 'Durable culinary essentials, insulated drinkware, handmade storage baskets, and modern homeware.',
    displayOrder: 5,
    isActive: true,
    defaultCommissionRate: 10.0
  },
  {
    id: 'cat-bags',
    name: 'Bags and Accessories',
    slug: 'bags-and-accessories',
    description: 'Handcrafted Nigerian leather goods, laptop bags, travel duffels, and belts.',
    displayOrder: 6,
    isActive: true,
    defaultCommissionRate: 10.0
  }
];

const INITIAL_PRODUCTS: Product[] = [
  // Fashion Products (Zaria Wears)
  {
    id: 'prod-01',
    retailerId: 'ret-zaria-01',
    retailerName: 'Zaria Wears & Textiles',
    categoryId: 'cat-fashion',
    categoryName: 'Fashion and Footwear',
    name: 'Structured Ankara Midi Dress with Linen Bodice',
    slug: 'structured-ankara-midi-dress',
    description: 'Expertly tailored contemporary midi dress uniting crisp structured raw linen with vibrant authentic Nigerian Ankara print. Features tailored pleating, side pockets, and an elegant mandarin collar.',
    sku: 'ZW-ANK-01',
    priceKobo: 3850000, // ₦38,500
    compareAtPriceKobo: 4500000, // ₦45,000 (genuine 14% discount)
    stockQuantity: 18,
    lowStockThreshold: 4,
    images: ['/src/assets/images/category_fashion_ankara_1791585893952.jpg'],
    variants: [
      { id: 'var-01-s', productId: 'prod-01', name: 'Size S (UK 8)', priceKobo: 3850000, stockQuantity: 5 },
      { id: 'var-01-m', productId: 'prod-01', name: 'Size M (UK 10)', priceKobo: 3850000, stockQuantity: 8 },
      { id: 'var-01-l', productId: 'prod-01', name: 'Size L (UK 12)', priceKobo: 3850000, stockQuantity: 5 }
    ],
    status: 'approved',
    deliveryInfo: 'Ships within 24-48 hours from Ikeja, Lagos. Next-day delivery available across Lagos State.',
    returnPolicy: '7-day unworn exchange policy with original tag attached.',
    weightKg: 0.65,
    isFeatured: true,
    rating: 4.9,
    reviewCount: 16,
    reviews: [
      {
        id: 'rev-01',
        productId: 'prod-01',
        customerId: 'user-customer-01',
        customerName: 'Kobi Asy',
        rating: 5,
        title: 'Impeccable tailoring and fit',
        comment: 'The stitching on the bodice is world-class. Wore it to a gallery opening in Victoria Island and received endless compliments.',
        isVerifiedPurchase: true,
        createdAt: '2026-02-14T11:20:00.000Z'
      }
    ],
    createdAt: '2026-02-01T10:00:00.000Z',
    updatedAt: '2026-03-01T12:00:00.000Z'
  },
  {
    id: 'prod-02',
    retailerId: 'ret-zaria-01',
    retailerName: 'Zaria Wears & Textiles',
    categoryId: 'cat-fashion',
    categoryName: 'Fashion and Footwear',
    name: 'Men\'s Tailored Grandad Linen Kaftan in Cream',
    slug: 'mens-tailored-grandad-linen-kaftan',
    description: 'Hand-finished Nigerian grandad collar kaftan set with tailored drawstring trousers. Crafted from breathable heavyweight Irish linen with subtle geometric embroidery at the placket.',
    sku: 'ZW-LIN-02',
    priceKobo: 5200000, // ₦52,000
    stockQuantity: 12,
    lowStockThreshold: 3,
    images: ['/src/assets/images/category_fashion_ankara_1791585893952.jpg'],
    variants: [
      { id: 'var-02-m', productId: 'prod-02', name: 'Size M (Chest 40)', priceKobo: 5200000, stockQuantity: 4 },
      { id: 'var-02-l', productId: 'prod-02', name: 'Size L (Chest 42)', priceKobo: 5200000, stockQuantity: 5 },
      { id: 'var-02-xl', productId: 'prod-02', name: 'Size XL (Chest 44)', priceKobo: 5200000, stockQuantity: 3 }
    ],
    status: 'approved',
    deliveryInfo: 'Ships from Ikeja, Lagos. Dispatch within 2 business days.',
    returnPolicy: '7-day exchange on standard sizes.',
    weightKg: 0.85,
    isFeatured: true,
    rating: 4.8,
    reviewCount: 9,
    createdAt: '2026-02-05T14:00:00.000Z',
    updatedAt: '2026-03-01T12:00:00.000Z'
  },

  // Tech Products (Eko Gadgets Hub)
  {
    id: 'prod-03',
    retailerId: 'ret-eko-02',
    retailerName: 'Eko Gadgets Hub',
    categoryId: 'cat-tech',
    categoryName: 'Phones and Electronics Accessories',
    name: '100W Braided USB-C Fast-Charging Cable (2 Meters)',
    slug: '100w-braided-fast-charging-cable',
    description: 'Heavy-duty Kevlar-reinforced braided nylon charging cable certified for 100W Power Delivery and high-speed data transfer. Tested for 25,000 bend cycles; built for demanding Nigerian usage.',
    sku: 'EG-CBL-100W',
    priceKobo: 1250000, // ₦12,500
    compareAtPriceKobo: 1500000, // ₦15,000
    stockQuantity: 45,
    lowStockThreshold: 10,
    images: ['/src/assets/images/category_tech_gadgets_1791585903912.jpg'],
    variants: [
      { id: 'var-03-blk', productId: 'prod-03', name: 'Midnight Charcoal', priceKobo: 1250000, stockQuantity: 25 },
      { id: 'var-03-gry', productId: 'prod-03', name: 'Gunmetal Silver', priceKobo: 1250000, stockQuantity: 20 }
    ],
    status: 'approved',
    deliveryInfo: 'Same-day Lagos dispatch for orders placed before 1:00 PM. 2-3 days nationwide delivery.',
    returnPolicy: '14-day replacement guarantee against manufacturing defects.',
    weightKg: 0.15,
    isFeatured: true,
    rating: 4.9,
    reviewCount: 31,
    createdAt: '2026-02-08T11:00:00.000Z',
    updatedAt: '2026-03-02T14:00:00.000Z'
  },
  {
    id: 'prod-04',
    retailerId: 'ret-eko-02',
    retailerName: 'Eko Gadgets Hub',
    categoryId: 'cat-tech',
    categoryName: 'Phones and Electronics Accessories',
    name: 'Wireless Active Noise-Cancelling Earbuds Pro',
    slug: 'wireless-anc-earbuds-pro',
    description: 'Crisp studio audio with 35dB hybrid active noise cancellation, dual transparency mode, and 30-hour total battery life with wireless charging case. IPX5 sweat-resistant for workouts and commutes.',
    sku: 'EG-AUD-PRO',
    priceKobo: 4800000, // ₦48,000
    compareAtPriceKobo: 5800000, // ₦58,000
    stockQuantity: 24,
    lowStockThreshold: 5,
    images: ['/src/assets/images/category_tech_gadgets_1791585903912.jpg'],
    variants: [
      { id: 'var-04-blk', productId: 'prod-04', name: 'Matte Obsidian', priceKobo: 4800000, stockQuantity: 14 },
      { id: 'var-04-wht', productId: 'prod-04', name: 'Pure Chalk', priceKobo: 4800000, stockQuantity: 10 }
    ],
    status: 'approved',
    deliveryInfo: 'Insured delivery with tracking code sent via SMS & email.',
    returnPolicy: '30-day warranty with receipt and box.',
    weightKg: 0.22,
    isFeatured: true,
    rating: 4.8,
    reviewCount: 22,
    createdAt: '2026-02-10T12:00:00.000Z',
    updatedAt: '2026-03-02T14:00:00.000Z'
  },

  // Beauty & Personal Care (Lekki Glow Organics)
  {
    id: 'prod-05',
    retailerId: 'ret-lekki-03',
    retailerName: 'Lekki Glow Organics',
    categoryId: 'cat-beauty',
    categoryName: 'Beauty and Personal Care',
    name: 'Pure Raw Unrefined African Shea Butter (200g Jar)',
    slug: 'pure-raw-unrefined-shea-butter-200g',
    description: '100% hand-harvested organic shea butter directly from women-led cooperatives in Kwara State. Naturally rich in vitamins A, E, and F to nourish dry skin, calm eczema, and condition hair.',
    sku: 'LG-SHEA-200',
    priceKobo: 750000, // ₦7,500
    stockQuantity: 60,
    lowStockThreshold: 12,
    images: ['/src/assets/images/category_beauty_skincare_1791585915844.jpg'],
    variants: [
      { id: 'var-05-nat', productId: 'prod-05', name: 'Unscented Pure Grade A', priceKobo: 750000, stockQuantity: 40 },
      { id: 'var-05-lav', productId: 'prod-05', name: 'Infused Lavender & Vanilla', priceKobo: 850000, stockQuantity: 20 }
    ],
    status: 'approved',
    deliveryInfo: 'Dispatches daily from Lekki Phase 1. 24-hr turnaround in Lagos.',
    returnPolicy: 'Replacement if sealed glass container is broken in transit.',
    weightKg: 0.35,
    isFeatured: true,
    rating: 5.0,
    reviewCount: 28,
    createdAt: '2026-02-12T09:30:00.000Z',
    updatedAt: '2026-03-01T10:00:00.000Z'
  },
  {
    id: 'prod-06',
    retailerId: 'ret-lekki-03',
    retailerName: 'Lekki Glow Organics',
    categoryId: 'cat-beauty',
    categoryName: 'Beauty and Personal Care',
    name: 'Botanical Radiance Facial Glow Oil (30ml Dropper)',
    slug: 'botanical-radiance-facial-glow-oil',
    description: 'Lightweight, fast-absorbing facial elixirs formulated with cold-pressed rosehip seed oil, Nigerian moringa extract, and jojoba. Restores skin barrier while adding a lit-from-within glow.',
    sku: 'LG-OIL-30',
    priceKobo: 1650000, // ₦16,500
    compareAtPriceKobo: 1950000, // ₦19,500
    stockQuantity: 35,
    lowStockThreshold: 8,
    images: ['/src/assets/images/category_beauty_skincare_1791585915844.jpg'],
    variants: [],
    status: 'approved',
    deliveryInfo: 'Packed in protective bubble insulation. Ships nationwide.',
    returnPolicy: 'Hygiene product: Returns only on unopened sealed packaging.',
    weightKg: 0.18,
    isFeatured: false,
    rating: 4.9,
    reviewCount: 17,
    createdAt: '2026-02-14T15:00:00.000Z',
    updatedAt: '2026-03-01T10:00:00.000Z'
  },

  // Food & Pantry (Kano Heritage Pantry)
  {
    id: 'prod-07',
    retailerId: 'ret-kano-04',
    retailerName: 'Kano Heritage Pantry',
    categoryId: 'cat-food',
    categoryName: 'Food and Household Essentials',
    name: 'Artisanal Raw Wildflower Honey (690g Glass Jar)',
    slug: 'artisanal-raw-wildflower-honey-690g',
    description: 'Pure, unpasteurized wild-harvested honey from northern Nigerian acacia woodlands. Never diluted or heated, retaining natural pollens, enzymes, and rich amber caramel undertones.',
    sku: 'KP-HNY-690',
    priceKobo: 950000, // ₦9,500
    stockQuantity: 50,
    lowStockThreshold: 15,
    images: ['/src/assets/images/category_food_pantry_1791585926747.jpg'],
    variants: [],
    status: 'approved',
    deliveryInfo: 'Securely packaged in crash-proof cardboard containers.',
    returnPolicy: 'Satisfaction guarantee: Immediate replacement if seal is broken.',
    weightKg: 0.95,
    isFeatured: true,
    rating: 5.0,
    reviewCount: 24,
    createdAt: '2026-02-16T10:00:00.000Z',
    updatedAt: '2026-03-05T11:00:00.000Z'
  },
  {
    id: 'prod-08',
    retailerId: 'ret-kano-04',
    retailerName: 'Kano Heritage Pantry',
    categoryId: 'cat-food',
    categoryName: 'Food and Household Essentials',
    name: 'Gourmet Roasted Jumbo Cashew Nuts (500g)',
    slug: 'gourmet-roasted-cashew-nuts-500g',
    description: 'Slow-roasted, premium whole jumbo cashews with a touch of natural sea salt. Packed in resealable airtight freshness canisters. Rich in healthy monounsaturated fats.',
    sku: 'KP-CSH-500',
    priceKobo: 1100000, // ₦11,000
    stockQuantity: 40,
    lowStockThreshold: 10,
    images: ['/src/assets/images/category_food_pantry_1791585926747.jpg'],
    variants: [
      { id: 'var-08-salt', productId: 'prod-08', name: 'Lightly Salted', priceKobo: 1100000, stockQuantity: 25 },
      { id: 'var-08-raw', productId: 'prod-08', name: 'Unsalted Raw Roast', priceKobo: 1100000, stockQuantity: 15 }
    ],
    status: 'approved',
    deliveryInfo: 'Fresh batch roasted weekly. Dispatched from Kano/Lagos depots.',
    returnPolicy: 'Immediate replacement if quality guarantee is not met.',
    weightKg: 0.55,
    isFeatured: false,
    rating: 4.9,
    reviewCount: 15,
    createdAt: '2026-02-18T14:00:00.000Z',
    updatedAt: '2026-03-05T11:00:00.000Z'
  },
  {
    id: 'prod-09',
    retailerId: 'ret-kano-04',
    retailerName: 'Kano Heritage Pantry',
    categoryId: 'cat-food',
    categoryName: 'Food and Household Essentials',
    name: 'Organic Whole Dried Hibiscus Calyces (Zobo) 150g',
    slug: 'organic-dried-hibiscus-zobo-150g',
    description: 'Deep ruby-red dried hibiscus sabdariffa harvested organically in northern Nigeria. Produces a tangy, antioxidant-rich ruby infusion perfect for hot tea or chilled Nigerian Zobo drink.',
    sku: 'KP-ZOB-150',
    priceKobo: 420000, // ₦4,200
    stockQuantity: 70,
    lowStockThreshold: 20,
    images: ['/src/assets/images/category_food_pantry_1791585926747.jpg'],
    variants: [],
    status: 'approved',
    deliveryInfo: 'Standard 24-48 hr courier across major Nigerian cities.',
    returnPolicy: 'Food items are non-returnable once opened.',
    weightKg: 0.2,
    isFeatured: false,
    rating: 4.8,
    reviewCount: 11,
    createdAt: '2026-02-20T11:30:00.000Z',
    updatedAt: '2026-03-05T11:00:00.000Z'
  },

  // Bags & Accessories (Abuja Leathercraft Vault)
  {
    id: 'prod-10',
    retailerId: 'ret-abuja-05',
    retailerName: 'Abuja Leathercraft Vault',
    categoryId: 'cat-bags',
    categoryName: 'Bags and Accessories',
    name: 'Handcrafted Full-Grain Leather Executive Briefcase',
    slug: 'handcrafted-full-grain-leather-briefcase',
    description: 'Bespoke executive document satchel handcrafted from durable full-grain vegetable-tanned Nigerian leather. Accommodates 15-inch laptops, documents, brass hardware, and detachable shoulder strap.',
    sku: 'AL-BRF-01',
    priceKobo: 7800000, // ₦78,000
    compareAtPriceKobo: 9500000, // ₦95,000
    stockQuantity: 8,
    lowStockThreshold: 2,
    images: ['/src/assets/images/hero_nigerian_market_1791585883007.jpg'],
    variants: [
      { id: 'var-10-brn', productId: 'prod-10', name: 'Cognac Saddle Brown', priceKobo: 7800000, stockQuantity: 5 },
      { id: 'var-10-blk', productId: 'prod-10', name: 'Onyx Black', priceKobo: 7800000, stockQuantity: 3 }
    ],
    status: 'approved',
    deliveryInfo: 'Ships from Wuse 2, Abuja. Air courier to Lagos within 24 hours.',
    returnPolicy: '14-day inspection return window. 1-year craftsmanship warranty.',
    weightKg: 1.4,
    isFeatured: true,
    rating: 5.0,
    reviewCount: 12,
    createdAt: '2026-02-22T13:00:00.000Z',
    updatedAt: '2026-03-06T15:00:00.000Z'
  }
];

const INITIAL_DISCOUNTS: DiscountCode[] = [
  {
    id: 'disc-01',
    code: 'BSNWELCOME',
    discountType: 'percentage',
    value: 10, // 10%
    minOrderKobo: 1000000, // ₦10,000
    maxDiscountKobo: 500000, // ₦5,000 cap
    usageLimit: 500,
    usedCount: 42,
    isActive: true,
    expiresAt: '2026-12-31T23:59:59.000Z'
  },
  {
    id: 'disc-02',
    code: 'LAGOSFREE',
    discountType: 'fixed_kobo',
    value: 250000, // ₦2,500 off delivery
    minOrderKobo: 2000000, // ₦20,000
    usageLimit: 300,
    usedCount: 88,
    isActive: true,
    expiresAt: '2026-12-31T23:59:59.000Z'
  }
];

const INITIAL_APPLICATIONS: RetailerApplication[] = [
  {
    id: 'app-01',
    userId: 'user-retailer-01',
    businessName: 'Zaria Wears & Textiles',
    cacRegNumber: 'RC-1849204',
    contactPerson: 'Amina Bello',
    email: 'amina@zariawears.ng',
    phone: '+234 803 456 7890',
    businessType: 'Fashion & Apparel Manufacturer',
    state: 'Lagos',
    city: 'Ikeja',
    address: '14 Allen Avenue, Ikeja, Lagos State',
    bankName: 'Access Bank',
    bankAccountNumber: '0129845512',
    bankAccountName: 'Zaria Wears Enterprises Ltd',
    status: 'approved',
    reviewedAt: '2026-01-10T14:00:00.000Z',
    createdAt: '2026-01-08T09:00:00.000Z'
  },
  {
    id: 'app-02',
    userId: 'user-applicant-02',
    businessName: 'Ibadan Ceramic Crafts',
    cacRegNumber: 'BN-449102',
    contactPerson: 'Taiwo Adeyemi',
    email: 'taiwo@ibadancrafts.ng',
    phone: '+234 802 881 9922',
    businessType: 'Ceramics & Tableware',
    state: 'Oyo',
    city: 'Ibadan',
    address: 'Ring Road, Ibadan, Oyo State',
    bankName: 'UBA',
    bankAccountNumber: '2093847192',
    bankAccountName: 'Ibadan Pottery Studio',
    status: 'pending_review',
    createdAt: '2026-03-08T11:00:00.000Z'
  }
];

class DatabaseService {
  private state: DatabaseState;
  private isSaving = false;

  constructor() {
    this.state = this.loadOrInitialize();
  }

  private loadOrInitialize(): DatabaseState {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw) as DatabaseState;
        return {
          users: parsed.users || INITIAL_USERS,
          retailers: parsed.retailers || INITIAL_RETAILERS,
          retailerApplications: parsed.retailerApplications || INITIAL_APPLICATIONS,
          categories: parsed.categories || INITIAL_CATEGORIES,
          products: parsed.products || INITIAL_PRODUCTS,
          orders: parsed.orders || [],
          payments: parsed.payments || [],
          settlements: parsed.settlements || [],
          discountCodes: parsed.discountCodes || INITIAL_DISCOUNTS,
          notifications: parsed.notifications || [],
          auditLogs: parsed.auditLogs || []
        };
      }
    } catch (err) {
      console.warn('Could not read existing database file, initializing defaults:', err);
    }

    const defaultState: DatabaseState = {
      users: INITIAL_USERS,
      retailers: INITIAL_RETAILERS,
      retailerApplications: INITIAL_APPLICATIONS,
      categories: INITIAL_CATEGORIES,
      products: INITIAL_PRODUCTS,
      orders: [],
      payments: [],
      settlements: [],
      discountCodes: INITIAL_DISCOUNTS,
      notifications: [
        {
          id: 'notif-welcome',
          userId: 'user-customer-01',
          title: 'Welcome to BSN Market!',
          message: 'Explore verified Nigerian retailers. Use code BSNWELCOME for 10% off your initial purchase.',
          type: 'system',
          isRead: false,
          createdAt: new Date().toISOString()
        }
      ],
      auditLogs: [
        {
          id: 'audit-init-01',
          actorId: 'user-admin-01',
          actorEmail: 'admin@bsnmarket.ng',
          actorRole: 'admin',
          action: 'marketplace.initialized',
          entityType: 'platform',
          entityId: 'bsn-root',
          details: { note: 'Initial seed deployed with 5 verified Nigerian retailers' },
          createdAt: new Date().toISOString()
        }
      ]
    };

    this.persist(defaultState);
    return defaultState;
  }

  private persist(data: DatabaseState) {
    if (this.isSaving) return;
    this.isSaving = true;
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write database file:', e);
    } finally {
      this.isSaving = false;
    }
  }

  private save() {
    this.persist(this.state);
  }

  // --- USERS & AUTH ---
  public getUsers() {
    return this.state.users;
  }

  public findUserById(id: string) {
    return this.state.users.find(u => u.id === id);
  }

  public findUserByEmail(email: string) {
    return this.state.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(user: Omit<UserProfile, 'id' | 'createdAt'>) {
    const newUser: UserProfile = {
      ...user,
      id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString()
    };
    this.state.users.push(newUser);
    this.save();
    return newUser;
  }

  // --- CATEGORIES ---
  public getCategories() {
    return this.state.categories.filter(c => c.isActive).sort((a, b) => a.displayOrder - b.displayOrder);
  }

  public getAllCategoriesAdmin() {
    return this.state.categories.sort((a, b) => a.displayOrder - b.displayOrder);
  }

  public createCategory(category: Omit<Category, 'id'>) {
    const newCat: Category = {
      ...category,
      id: `cat-${Date.now()}`
    };
    this.state.categories.push(newCat);
    this.save();
    return newCat;
  }

  public updateCategory(id: string, updates: Partial<Category>) {
    const idx = this.state.categories.findIndex(c => c.id === id);
    if (idx === -1) return null;
    this.state.categories[idx] = { ...this.state.categories[idx], ...updates };
    this.save();
    return this.state.categories[idx];
  }

  // --- PRODUCTS ---
  public getProducts(filters?: {
    categoryId?: string;
    search?: string;
    minPriceKobo?: number;
    maxPriceKobo?: number;
    sortBy?: 'price_asc' | 'price_desc' | 'newest' | 'rating';
    retailerId?: string;
    status?: string;
  }) {
    let prods = [...this.state.products];

    // Filter by status (public view only sees approved)
    if (filters?.status) {
      prods = prods.filter(p => p.status === filters.status);
    } else if (!filters?.retailerId) {
      prods = prods.filter(p => p.status === 'approved');
    }

    if (filters?.categoryId && filters.categoryId !== 'all') {
      prods = prods.filter(p => p.categoryId === filters.categoryId);
    }

    if (filters?.retailerId) {
      prods = prods.filter(p => p.retailerId === filters.retailerId);
    }

    if (filters?.search) {
      const q = filters.search.toLowerCase().trim();
      prods = prods.filter(
        p =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.categoryName.toLowerCase().includes(q) ||
          p.retailerName.toLowerCase().includes(q)
      );
    }

    if (filters?.minPriceKobo !== undefined) {
      prods = prods.filter(p => p.priceKobo >= filters.minPriceKobo!);
    }
    if (filters?.maxPriceKobo !== undefined) {
      prods = prods.filter(p => p.priceKobo <= filters.maxPriceKobo!);
    }

    // Sort
    if (filters?.sortBy === 'price_asc') {
      prods.sort((a, b) => a.priceKobo - b.priceKobo);
    } else if (filters?.sortBy === 'price_desc') {
      prods.sort((a, b) => b.priceKobo - a.priceKobo);
    } else if (filters?.sortBy === 'rating') {
      prods.sort((a, b) => b.rating - a.rating);
    } else {
      // Default: newest
      prods.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return prods;
  }

  public getProductById(id: string) {
    return this.state.products.find(p => p.id === id);
  }

  public createProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'rating' | 'reviewCount'>) {
    const newProd: Product = {
      ...product,
      id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      rating: 5.0,
      reviewCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    this.state.products.push(newProd);
    this.save();
    return newProd;
  }

  public updateProduct(id: string, updates: Partial<Product>) {
    const idx = this.state.products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.state.products[idx] = {
      ...this.state.products[idx],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.save();
    return this.state.products[idx];
  }

  public addProductReview(productId: string, review: Omit<ProductReview, 'id' | 'createdAt'>) {
    const prod = this.getProductById(productId);
    if (!prod) return null;
    const newReview = {
      ...review,
      id: `rev-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    if (!prod.reviews) prod.reviews = [];
    prod.reviews.unshift(newReview);
    prod.reviewCount = prod.reviews.length;
    prod.rating = Number((prod.reviews.reduce((sum, r) => sum + r.rating, 0) / prod.reviewCount).toFixed(1));
    this.save();
    return newReview;
  }

  // --- RETAILERS ---
  public getRetailers() {
    return this.state.retailers;
  }

  public getRetailerById(id: string) {
    return this.state.retailers.find(r => r.id === id);
  }

  public getRetailerByOwnerId(ownerId: string) {
    return this.state.retailers.find(r => r.ownerId === ownerId);
  }

  public getRetailerApplications() {
    return this.state.retailerApplications;
  }

  public submitRetailerApplication(app: Omit<RetailerApplication, 'id' | 'status' | 'createdAt'>) {
    const newApp: RetailerApplication = {
      ...app,
      id: `app-${Date.now()}`,
      status: 'pending_review',
      createdAt: new Date().toISOString()
    };
    this.state.retailerApplications.push(newApp);
    this.save();
    return newApp;
  }

  public moderateRetailerApplication(appId: string, status: 'approved' | 'rejected', rejectionReason?: string) {
    const app = this.state.retailerApplications.find(a => a.id === appId);
    if (!app) return null;
    app.status = status;
    app.rejectionReason = rejectionReason;
    app.reviewedAt = new Date().toISOString();

    if (status === 'approved') {
      // Create retailer profile
      const newRetailer: RetailerProfile = {
        id: `ret-${Date.now()}`,
        ownerId: app.userId,
        businessName: app.businessName,
        businessSlug: app.businessName.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
        cacRegNumber: app.cacRegNumber,
        description: `${app.businessType} operating in ${app.city}, ${app.state}`,
        phone: app.phone,
        email: app.email,
        state: app.state,
        city: app.city,
        physicalAddress: app.address,
        bankName: app.bankName,
        bankAccountNumber: app.bankAccountNumber,
        bankAccountName: app.bankAccountName,
        status: 'approved',
        rating: 5.0,
        reviewCount: 0,
        verifiedBadge: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      this.state.retailers.push(newRetailer);

      // Upgrade user role
      const user = this.findUserById(app.userId);
      if (user) {
        user.role = 'retailer';
      }
    }

    this.save();
    return app;
  }

  public updateRetailerStatus(retailerId: string, status: 'approved' | 'suspended' | 'rejected') {
    const ret = this.getRetailerById(retailerId);
    if (!ret) return null;
    ret.status = status;
    ret.updatedAt = new Date().toISOString();
    this.save();
    return ret;
  }

  // --- CART CALCULATION (Server-authoritative) ---
  public calculateCart(items: { productId: string; variantId?: string; quantity: number }[], discountCode?: string) {
    let subtotalKobo = 0;
    const validatedItems: {
      productId: string;
      productName: string;
      retailerId: string;
      retailerName: string;
      variantId?: string;
      variantName?: string;
      unitPriceKobo: number;
      quantity: number;
      subtotalKobo: number;
      image: string;
    }[] = [];

    const retailerMap = new Map<string, number>();

    for (const item of items) {
      const prod = this.getProductById(item.productId);
      if (!prod || prod.status !== 'approved') continue;

      let unitPrice = prod.priceKobo;
      let variantName: string | undefined;

      if (item.variantId) {
        const variant = prod.variants.find(v => v.id === item.variantId);
        if (variant) {
          unitPrice = variant.priceKobo;
          variantName = variant.name;
        }
      }

      const cappedQty = Math.max(1, Math.min(item.quantity, prod.stockQuantity));
      const lineSubtotal = unitPrice * cappedQty;
      subtotalKobo += lineSubtotal;

      retailerMap.set(prod.retailerId, (retailerMap.get(prod.retailerId) || 0) + lineSubtotal);

      validatedItems.push({
        productId: prod.id,
        productName: prod.name,
        retailerId: prod.retailerId,
        retailerName: prod.retailerName,
        variantId: item.variantId,
        variantName,
        unitPriceKobo: unitPrice,
        quantity: cappedQty,
        subtotalKobo: lineSubtotal,
        image: prod.images[0] || ''
      });
    }

    // Delivery fee calculation: ₦2,000 standard per participating retailer
    const retailerCount = Math.max(1, retailerMap.size);
    const deliveryFeeKobo = validatedItems.length > 0 ? retailerCount * 200000 : 0; // ₦2,000 per retailer

    // Discount validation
    let discountKobo = 0;
    let appliedCode: string | undefined;

    if (discountCode) {
      const disc = this.state.discountCodes.find(d => d.code.toUpperCase() === discountCode.toUpperCase() && d.isActive);
      if (disc && subtotalKobo >= disc.minOrderKobo) {
        if (disc.discountType === 'percentage') {
          discountKobo = Math.round((subtotalKobo * disc.value) / 100);
          if (disc.maxDiscountKobo && discountKobo > disc.maxDiscountKobo) {
            discountKobo = disc.maxDiscountKobo;
          }
        } else {
          discountKobo = disc.value;
        }
        appliedCode = disc.code;
      }
    }

    const totalKobo = Math.max(0, subtotalKobo + deliveryFeeKobo - discountKobo);

    return {
      items: validatedItems,
      subtotalKobo,
      deliveryFeeKobo,
      discountKobo,
      totalKobo,
      appliedCode,
      retailerCount
    };
  }

  // --- ORDERS & TRANSACTIONS ---
  public createOrder(params: {
    customerId: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryCity: string;
    deliveryState: string;
    deliveryInstructions?: string;
    deliveryMethod: 'standard' | 'express' | 'pickup';
    items: { productId: string; variantId?: string; quantity: number }[];
    discountCode?: string;
  }) {
    const calc = this.calculateCart(params.items, params.discountCode);
    if (calc.items.length === 0) {
      throw new Error('Cart is empty or items unavailable');
    }

    const orderId = `ord-${Date.now()}`;
    const orderRef = `BSN-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    // Group items by retailer for multi-vendor sub-orders
    const itemsByRetailer = new Map<string, typeof calc.items>();
    for (const item of calc.items) {
      const list = itemsByRetailer.get(item.retailerId) || [];
      list.push(item);
      itemsByRetailer.set(item.retailerId, list);
    }

    const retailerOrders: RetailerSubOrder[] = [];
    const allOrderItems: OrderItem[] = [];

    let retIdx = 1;
    for (const [retailerId, retailerItems] of itemsByRetailer.entries()) {
      const retailer = this.getRetailerById(retailerId);
      const retSubtotal = retailerItems.reduce((sum, it) => sum + it.subtotalKobo, 0);
      const retDelivery = 200000; // ₦2,000 for this retailer's package

      // Snapshot commission rate: category or retailer override
      const commissionRate = retailer?.commissionRateOverride ?? 10.0;
      const commissionAmount = Math.round((retSubtotal * commissionRate) / 100);
      const retailerPayable = retSubtotal - commissionAmount;

      const retSubOrderId = `retord-${Date.now()}-${retIdx}`;
      const retOrderRef = `${orderRef}-R${retIdx++}`;

      const subOrderItems: OrderItem[] = retailerItems.map((it, idx) => ({
        id: `oi-${Date.now()}-${idx}`,
        orderId,
        retailerOrderId: retSubOrderId,
        retailerId,
        productId: it.productId,
        variantId: it.variantId,
        productName: it.productName,
        variantName: it.variantName,
        productImage: it.image,
        unitPriceKobo: it.unitPriceKobo,
        quantity: it.quantity,
        subtotalKobo: it.subtotalKobo
      }));

      allOrderItems.push(...subOrderItems);

      retailerOrders.push({
        id: retSubOrderId,
        orderId,
        retailerId,
        retailerName: retailer?.businessName || 'Retailer',
        retailerOrderRef: retOrderRef,
        subtotalKobo: retSubtotal,
        deliveryFeeKobo: retDelivery,
        commissionRateSnapshot: commissionRate,
        commissionAmountKobo: commissionAmount,
        retailerPayableKobo: retailerPayable,
        fulfilmentStatus: 'order_placed',
        settlementStatus: 'not_due',
        items: subOrderItems,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }

    const order: Order = {
      id: orderId,
      orderReference: orderRef,
      customerId: params.customerId,
      customerName: params.customerName,
      customerEmail: params.customerEmail,
      customerPhone: params.customerPhone,
      deliveryAddress: params.deliveryAddress,
      deliveryCity: params.deliveryCity,
      deliveryState: params.deliveryState,
      deliveryInstructions: params.deliveryInstructions,
      deliveryMethod: params.deliveryMethod,
      subtotalKobo: calc.subtotalKobo,
      deliveryFeeKobo: calc.deliveryFeeKobo,
      discountKobo: calc.discountKobo,
      totalKobo: calc.totalKobo,
      amountRefundedKobo: 0,
      status: 'order_placed',
      paymentStatus: 'pending',
      appliedDiscountCode: calc.appliedCode,
      retailerOrders,
      items: allOrderItems,
      timeline: [
        {
          status: 'order_placed',
          title: 'Order Placed',
          description: `Order ${orderRef} initialized. Awaiting payment confirmation.`,
          timestamp: new Date().toISOString(),
          actor: params.customerName
        }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Deduct stock safely
    for (const item of calc.items) {
      const prod = this.getProductById(item.productId);
      if (prod) {
        prod.stockQuantity = Math.max(0, prod.stockQuantity - item.quantity);
        if (item.variantId) {
          const varItem = prod.variants.find(v => v.id === item.variantId);
          if (varItem) {
            varItem.stockQuantity = Math.max(0, varItem.stockQuantity - item.quantity);
          }
        }
      }
    }

    // Increment discount usage
    if (calc.appliedCode) {
      const disc = this.state.discountCodes.find(d => d.code === calc.appliedCode);
      if (disc) disc.usedCount++;
    }

    this.state.orders.unshift(order);
    this.save();
    return order;
  }

  public getOrders(filters?: { customerId?: string; retailerId?: string }) {
    if (filters?.customerId) {
      return this.state.orders.filter(o => o.customerId === filters.customerId);
    }
    if (filters?.retailerId) {
      // Return sub-orders for that retailer
      const retailerSubOrders: RetailerSubOrder[] = [];
      for (const order of this.state.orders) {
        for (const ro of order.retailerOrders) {
          if (ro.retailerId === filters.retailerId) {
            retailerSubOrders.push(ro);
          }
        }
      }
      return retailerSubOrders;
    }
    return this.state.orders;
  }

  public getOrderById(id: string) {
    return this.state.orders.find(o => o.id === id || o.orderReference === id);
  }

  // --- PAYMENTS & PAYSTACK LIFECYCLE ---
  public initializePaystackPayment(orderId: string) {
    const order = this.getOrderById(orderId);
    if (!order) throw new Error('Order not found');

    const reference = `BSN-PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const payment: PaymentRecord = {
      id: `pay-${Date.now()}`,
      orderId: order.id,
      orderReference: order.orderReference,
      provider: 'paystack',
      reference,
      amountKobo: order.totalKobo,
      currency: 'NGN',
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    this.state.payments.push(payment);
    this.save();

    return {
      reference,
      amountKobo: order.totalKobo,
      currency: 'NGN',
      email: order.customerEmail,
      orderReference: order.orderReference
    };
  }

  public verifyPaystackPayment(reference: string, simChannel = 'card') {
    const payment = this.state.payments.find(p => p.reference === reference);
    if (!payment) throw new Error('Payment reference not found');

    if (payment.status === 'successful') {
      return { success: true, payment, message: 'Payment already verified (Idempotent)' };
    }

    payment.status = 'successful';
    payment.paidAt = new Date().toISOString();
    payment.verifiedAt = new Date().toISOString();
    payment.channel = simChannel;

    // Update parent order
    const order = this.getOrderById(payment.orderId);
    if (order) {
      order.paymentStatus = 'successful';
      order.status = 'payment_confirmed';
      order.paymentReference = reference;
      order.timeline.push({
        status: 'payment_confirmed',
        title: 'Payment Verified via Paystack',
        description: `Verified ₦${(payment.amountKobo / 100).toLocaleString()} through Paystack (${simChannel.toUpperCase()}). Reference: ${reference}`,
        timestamp: new Date().toISOString(),
        actor: 'Paystack Gateway'
      });

      // Update retailer sub-orders to retailer_confirmed or payment_confirmed
      for (const ro of order.retailerOrders) {
        ro.fulfilmentStatus = 'payment_confirmed';
        ro.settlementStatus = 'pending'; // Now due for future settlement
      }

      // Add Notification
      this.state.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: order.customerId,
        title: 'Payment Confirmed',
        message: `Your payment for order ${order.orderReference} was successful. Retailers are preparing your package.`,
        type: 'payment',
        link: `/orders/${order.orderReference}`,
        isRead: false,
        createdAt: new Date().toISOString()
      });
    }

    // Add Audit Log
    this.state.auditLogs.unshift({
      id: `audit-${Date.now()}`,
      actorId: 'system-paystack',
      actorEmail: 'gateway@paystack.co',
      actorRole: 'admin',
      action: 'payment.verified',
      entityType: 'payment',
      entityId: payment.id,
      details: { reference, amountKobo: payment.amountKobo, orderReference: payment.orderReference },
      createdAt: new Date().toISOString()
    });

    this.save();
    return { success: true, payment, order };
  }

  // --- RETAILER ORDER ACTIONS ---
  public updateRetailerOrderStatus(params: {
    retailerId: string;
    retailerOrderId: string;
    action: 'confirm' | 'reject' | 'processing' | 'dispatch' | 'delivered';
    reason?: string;
    courierName?: string;
    trackingReference?: string;
  }) {
    let targetOrder: Order | undefined;
    let targetSubOrder: RetailerSubOrder | undefined;

    for (const order of this.state.orders) {
      for (const ro of order.retailerOrders) {
        if (ro.id === params.retailerOrderId && ro.retailerId === params.retailerId) {
          targetOrder = order;
          targetSubOrder = ro;
          break;
        }
      }
      if (targetSubOrder) break;
    }

    if (!targetOrder || !targetSubOrder) {
      throw new Error('Retailer order not found or unauthorized');
    }

    const timestamp = new Date().toISOString();

    if (params.action === 'confirm') {
      targetSubOrder.fulfilmentStatus = 'retailer_confirmed';
      targetOrder.timeline.push({
        status: 'retailer_confirmed',
        title: `${targetSubOrder.retailerName} Confirmed Order`,
        description: 'Retailer acknowledged order and is preparing items.',
        timestamp,
        actor: targetSubOrder.retailerName
      });
    } else if (params.action === 'processing') {
      targetSubOrder.fulfilmentStatus = 'processing';
      targetOrder.timeline.push({
        status: 'processing',
        title: `${targetSubOrder.retailerName} Processing & Packaging`,
        description: 'Items are being boxed and prepared for courier pickup.',
        timestamp,
        actor: targetSubOrder.retailerName
      });
    } else if (params.action === 'dispatch') {
      targetSubOrder.fulfilmentStatus = 'dispatched';
      targetSubOrder.courierName = params.courierName || 'Kwik / GIG Logistics';
      targetSubOrder.trackingReference = params.trackingReference || `TRK-NG-${Math.floor(100000 + Math.random() * 900000)}`;
      targetOrder.timeline.push({
        status: 'dispatched',
        title: `Package Dispatched by ${targetSubOrder.retailerName}`,
        description: `Handed over to ${targetSubOrder.courierName}. Tracking reference: ${targetSubOrder.trackingReference}`,
        timestamp,
        actor: targetSubOrder.retailerName
      });
    } else if (params.action === 'delivered') {
      targetSubOrder.fulfilmentStatus = 'delivered';
      targetOrder.timeline.push({
        status: 'delivered',
        title: `Package Delivered (${targetSubOrder.retailerName})`,
        description: 'Customer confirmed delivery receipt.',
        timestamp,
        actor: targetSubOrder.retailerName
      });
    } else if (params.action === 'reject') {
      targetSubOrder.fulfilmentStatus = 'cancelled';
      targetSubOrder.rejectionReason = params.reason || 'Item unavailable';
      targetOrder.timeline.push({
        status: 'cancelled',
        title: `Order Rejected by ${targetSubOrder.retailerName}`,
        description: `Reason: ${targetSubOrder.rejectionReason}. Refund process initiated.`,
        timestamp,
        actor: targetSubOrder.retailerName
      });
      // Trigger refund queue
      targetOrder.status = 'refund_requested';
      targetOrder.paymentStatus = 'refund_pending';
    }

    // Check if overall parent order status should advance
    const allStatuses = targetOrder.retailerOrders.map(ro => ro.fulfilmentStatus);
    if (allStatuses.every(s => s === 'delivered')) {
      targetOrder.status = 'delivered';
    } else if (allStatuses.some(s => s === 'dispatched')) {
      targetOrder.status = 'dispatched';
    } else if (allStatuses.some(s => s === 'processing')) {
      targetOrder.status = 'processing';
    } else if (allStatuses.some(s => s === 'retailer_confirmed')) {
      targetOrder.status = 'retailer_confirmed';
    }

    targetOrder.updatedAt = timestamp;
    this.save();
    return { order: targetOrder, subOrder: targetSubOrder };
  }

  // --- ADMIN FINANCIALS & METRICS ---
  public getPlatformMetrics(): PlatformMetrics {
    let gmv = 0;
    let netRevenue = 0;
    let retailerPayable = 0;
    let refunds = 0;
    let completedCount = 0;
    let pendingCount = 0;

    for (const order of this.state.orders) {
      if (order.paymentStatus === 'successful') {
        gmv += order.totalKobo;
        for (const ro of order.retailerOrders) {
          netRevenue += ro.commissionAmountKobo;
          if (ro.settlementStatus !== 'settled') {
            retailerPayable += ro.retailerPayableKobo;
          }
        }
      }
      if (order.status === 'delivered') completedCount++;
      if (order.status === 'order_placed' || order.status === 'payment_confirmed') pendingCount++;
      if (order.amountRefundedKobo) refunds += order.amountRefundedKobo;
    }

    const activeRetailers = this.state.retailers.filter(r => r.status === 'approved').length;
    const pendingApps = this.state.retailerApplications.filter(a => a.status === 'pending_review').length;
    const productsAwaitingReview = this.state.products.filter(p => p.status === 'under_review').length;

    return {
      gmvKobo: gmv,
      platformNetRevenueKobo: netRevenue,
      retailerPayableKobo: retailerPayable,
      totalRefundsKobo: refunds,
      totalOrdersCount: this.state.orders.length,
      completedOrdersCount: completedCount,
      pendingOrdersCount: pendingCount,
      activeRetailersCount: activeRetailers,
      pendingApplicationsCount: pendingApps,
      productsAwaitingReviewCount: productsAwaitingReview
    };
  }

  public getRetailerStats(retailerId: string): RetailerStats {
    let totalOrders = 0;
    let awaitingConfirmation = 0;
    let processing = 0;
    let completed = 0;
    let grossSales = 0;
    let commissionDeductions = 0;
    let netPayable = 0;
    let settled = 0;
    let pendingSettlement = 0;

    for (const order of this.state.orders) {
      for (const ro of order.retailerOrders) {
        if (ro.retailerId === retailerId) {
          totalOrders++;
          if (ro.fulfilmentStatus === 'payment_confirmed') awaitingConfirmation++;
          if (ro.fulfilmentStatus === 'processing' || ro.fulfilmentStatus === 'dispatched') processing++;
          if (ro.fulfilmentStatus === 'delivered') completed++;

          if (order.paymentStatus === 'successful') {
            grossSales += ro.subtotalKobo;
            commissionDeductions += ro.commissionAmountKobo;
            netPayable += ro.retailerPayableKobo;
            if (ro.settlementStatus === 'settled') {
              settled += ro.retailerPayableKobo;
            } else {
              pendingSettlement += ro.retailerPayableKobo;
            }
          }
        }
      }
    }

    const lowStockCount = this.state.products.filter(
      p => p.retailerId === retailerId && p.stockQuantity <= p.lowStockThreshold
    ).length;

    return {
      retailerId,
      totalOrdersCount: totalOrders,
      awaitingConfirmationCount: awaitingConfirmation,
      processingCount: processing,
      completedCount: completed,
      grossSalesKobo: grossSales,
      commissionDeductionsKobo: commissionDeductions,
      netPayableKobo: netPayable,
      settledKobo: settled,
      pendingSettlementKobo: pendingSettlement,
      lowStockItemsCount: lowStockCount
    };
  }

  // --- SETTLEMENT ACTIONS ---
  public getSettlements() {
    return this.state.settlements;
  }

  public createSettlement(params: {
    retailerId: string;
    bankTransferReference: string;
    notes?: string;
  }) {
    const retailer = this.getRetailerById(params.retailerId);
    if (!retailer) throw new Error('Retailer not found');

    // Collect pending retailer sub-orders
    const eligibleOrders: RetailerSubOrder[] = [];
    let grossSales = 0;
    let commission = 0;
    let netPayable = 0;

    for (const order of this.state.orders) {
      if (order.paymentStatus === 'successful') {
        for (const ro of order.retailerOrders) {
          if (ro.retailerId === params.retailerId && ro.settlementStatus === 'pending') {
            eligibleOrders.push(ro);
            grossSales += ro.subtotalKobo;
            commission += ro.commissionAmountKobo;
            netPayable += ro.retailerPayableKobo;
          }
        }
      }
    }

    if (eligibleOrders.length === 0) {
      throw new Error('No pending orders ready for settlement');
    }

    const settlement: RetailerSettlement = {
      id: `stl-${Date.now()}`,
      settlementReference: `STL-NG-${Date.now().toString().slice(-6)}`,
      retailerId: retailer.id,
      retailerName: retailer.businessName,
      bankName: retailer.bankName,
      bankAccountNumber: retailer.bankAccountNumber,
      bankAccountName: retailer.bankAccountName,
      grossSalesKobo: grossSales,
      commissionDeductionsKobo: commission,
      netPayableKobo: netPayable,
      status: 'settled',
      bankTransferReference: params.bankTransferReference,
      transferredAt: new Date().toISOString(),
      orderReferences: eligibleOrders.map(o => o.retailerOrderRef),
      notes: params.notes,
      createdAt: new Date().toISOString()
    };

    // Mark suborders settled
    for (const ro of eligibleOrders) {
      ro.settlementStatus = 'settled';
    }

    this.state.settlements.unshift(settlement);

    // Audit Log
    this.state.auditLogs.unshift({
      id: `audit-${Date.now()}`,
      actorId: 'admin-01',
      actorEmail: 'admin@bsnmarket.ng',
      actorRole: 'admin',
      action: 'settlement.recorded',
      entityType: 'settlement',
      entityId: settlement.id,
      details: {
        retailerName: retailer.businessName,
        netPayableKobo: netPayable,
        bankRef: params.bankTransferReference
      },
      createdAt: new Date().toISOString()
    });

    this.save();
    return settlement;
  }

  // --- DISCOUNTS ---
  public getDiscountCodes() {
    return this.state.discountCodes;
  }

  public createDiscountCode(discount: Omit<DiscountCode, 'id' | 'usedCount'>) {
    const newDisc: DiscountCode = {
      ...discount,
      id: `disc-${Date.now()}`,
      code: discount.code.toUpperCase(),
      usedCount: 0
    };
    this.state.discountCodes.push(newDisc);
    this.save();
    return newDisc;
  }

  // --- NOTIFICATIONS ---
  public getNotifications(userId: string) {
    return this.state.notifications.filter(n => n.userId === userId || n.userId === 'all');
  }

  public markNotificationRead(id: string) {
    const notif = this.state.notifications.find(n => n.id === id);
    if (notif) notif.isRead = true;
    this.save();
  }

  // --- AUDIT LOGS ---
  public getAuditLogs() {
    return this.state.auditLogs;
  }
}

export const db = new DatabaseService();
