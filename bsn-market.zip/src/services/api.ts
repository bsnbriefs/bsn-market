/**
 * BSN Market Frontend API Client
 * Clean fetch wrapper connecting to Express /api endpoints with structured error handling
 */

import {
  UserProfile,
  RetailerProfile,
  RetailerApplication,
  Category,
  Product,
  Order,
  RetailerSubOrder,
  RetailerStats,
  PlatformMetrics,
  RetailerSettlement,
  DiscountCode,
  InAppNotification,
  AuditLogEntry
} from '../types/index.ts';

const API_BASE = '/api';

async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {})
    }
  });

  if (!res.ok) {
    let errorMsg = `API Error ${res.status}`;
    try {
      const json = await res.json();
      if (json.error) errorMsg = json.error;
    } catch {
      // ignore
    }
    throw new Error(errorMsg);
  }

  return res.json();
}

export const api = {
  // --- AUTH ---
  async getMe(): Promise<{ user: UserProfile; retailer?: RetailerProfile }> {
    return request('/auth/me');
  },

  async switchRole(role: 'customer' | 'retailer' | 'admin'): Promise<{ user: UserProfile }> {
    return request('/auth/switch', {
      method: 'POST',
      body: JSON.stringify({ role })
    });
  },

  async registerUser(data: { fullName: string; email: string; phoneNumber?: string; role?: string }): Promise<{ user: UserProfile }> {
    return request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  // --- CATEGORIES ---
  async getCategories(): Promise<Category[]> {
    return request('/categories');
  },

  async getAdminCategories(): Promise<Category[]> {
    return request('/admin/categories');
  },

  async createCategory(cat: Partial<Category>): Promise<Category> {
    return request('/admin/categories', {
      method: 'POST',
      body: JSON.stringify(cat)
    });
  },

  async updateCategory(id: string, updates: Partial<Category>): Promise<Category> {
    return request(`/admin/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  },

  // --- PRODUCTS ---
  async getProducts(params?: {
    categoryId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sortBy?: string;
    retailerId?: string;
  }): Promise<Product[]> {
    const q = new URLSearchParams();
    if (params?.categoryId && params.categoryId !== 'all') q.set('categoryId', params.categoryId);
    if (params?.search) q.set('search', params.search);
    if (params?.minPrice !== undefined) q.set('minPrice', params.minPrice.toString());
    if (params?.maxPrice !== undefined) q.set('maxPrice', params.maxPrice.toString());
    if (params?.sortBy) q.set('sortBy', params.sortBy);
    if (params?.retailerId) q.set('retailerId', params.retailerId);

    const queryString = q.toString() ? `?${q.toString()}` : '';
    return request(`/products${queryString}`);
  },

  async getProductById(id: string): Promise<Product> {
    return request(`/products/${id}`);
  },

  async submitReview(productId: string, review: { rating: number; title?: string; comment: string; customerName?: string }): Promise<any> {
    return request(`/products/${productId}/reviews`, {
      method: 'POST',
      body: JSON.stringify(review)
    });
  },

  // --- CART CALCULATION (Server-authoritative) ---
  async calculateCart(
    items: { productId: string; variantId?: string; quantity: number }[],
    discountCode?: string
  ): Promise<{
    items: any[];
    subtotalKobo: number;
    deliveryFeeKobo: number;
    discountKobo: number;
    totalKobo: number;
    appliedCode?: string;
    retailerCount: number;
  }> {
    return request('/cart/calculate', {
      method: 'POST',
      body: JSON.stringify({ items, discountCode })
    });
  },

  // --- ORDERS ---
  async createOrder(data: {
    customerId: string;
    customerName: string;
    customerEmail: string;
    customerPhone: string;
    deliveryAddress: string;
    deliveryCity: string;
    deliveryState: string;
    deliveryInstructions?: string;
    deliveryMethod: 'standard' | 'express' | 'pickup';
    items: { productId: string; variantId?: string; quantity: number }[];
    discountCode?: string;
  }): Promise<Order> {
    return request('/orders', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async getCustomerOrders(customerId?: string): Promise<Order[]> {
    const q = customerId ? `?customerId=${customerId}` : '';
    return request(`/orders${q}`);
  },

  async getOrderById(id: string): Promise<Order> {
    return request(`/orders/${id}`);
  },

  // --- PAYSTACK LIFECYCLE ---
  async initializePayment(orderId: string): Promise<{
    reference: string;
    amountKobo: number;
    currency: string;
    email: string;
    orderReference: string;
  }> {
    return request('/paystack/initialize', {
      method: 'POST',
      body: JSON.stringify({ orderId })
    });
  },

  async verifyPayment(reference: string, channel: string = 'card'): Promise<{
    success: boolean;
    payment: any;
    order: Order;
  }> {
    return request('/paystack/verify', {
      method: 'POST',
      body: JSON.stringify({ reference, channel })
    });
  },

  // --- RETAILER PORTAL ---
  async applyAsRetailer(data: any): Promise<RetailerApplication> {
    return request('/retailer/apply', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async getRetailerStats(retailerId?: string): Promise<RetailerStats> {
    const q = retailerId ? `?retailerId=${retailerId}` : '';
    return request(`/retailer/stats${q}`);
  },

  async getRetailerOrders(retailerId?: string): Promise<RetailerSubOrder[]> {
    const q = retailerId ? `?retailerId=${retailerId}` : '';
    return request(`/retailer/orders${q}`);
  },

  async updateRetailerOrderStatus(
    orderId: string,
    action: 'confirm' | 'reject' | 'processing' | 'dispatch' | 'delivered',
    payload?: { reason?: string; courierName?: string; trackingReference?: string; retailerId?: string }
  ): Promise<any> {
    return request(`/retailer/orders/${orderId}/action`, {
      method: 'POST',
      body: JSON.stringify({ action, ...payload })
    });
  },

  async getRetailerProducts(retailerId?: string): Promise<Product[]> {
    const q = retailerId ? `?retailerId=${retailerId}` : '';
    return request(`/retailer/products${q}`);
  },

  async createRetailerProduct(productData: any): Promise<Product> {
    return request('/retailer/products', {
      method: 'POST',
      body: JSON.stringify(productData)
    });
  },

  // --- ADMIN DASHBOARD ---
  async getAdminMetrics(): Promise<PlatformMetrics> {
    return request('/admin/metrics');
  },

  async getRetailerApplications(): Promise<RetailerApplication[]> {
    return request('/admin/retailer-applications');
  },

  async moderateRetailerApplication(id: string, status: 'approved' | 'rejected', rejectionReason?: string): Promise<any> {
    return request(`/admin/retailer-applications/${id}/moderate`, {
      method: 'POST',
      body: JSON.stringify({ status, rejectionReason })
    });
  },

  async getAdminRetailers(): Promise<RetailerProfile[]> {
    return request('/admin/retailers');
  },

  async updateRetailerStatus(id: string, status: 'approved' | 'suspended' | 'rejected'): Promise<any> {
    return request(`/admin/retailers/${id}/status`, {
      method: 'POST',
      body: JSON.stringify({ status })
    });
  },

  async getProductsForModeration(): Promise<Product[]> {
    return request('/admin/products-moderation');
  },

  async moderateProduct(id: string, status: 'approved' | 'rejected', rejectionReason?: string): Promise<any> {
    return request(`/admin/products/${id}/moderate`, {
      method: 'POST',
      body: JSON.stringify({ status, rejectionReason })
    });
  },

  async getSettlements(): Promise<RetailerSettlement[]> {
    return request('/admin/settlements');
  },

  async createSettlement(data: { retailerId: string; bankTransferReference: string; notes?: string }): Promise<RetailerSettlement> {
    return request('/admin/settlements', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async getAuditLogs(): Promise<AuditLogEntry[]> {
    return request('/admin/audit-logs');
  },

  async getDiscountCodes(): Promise<DiscountCode[]> {
    return request('/admin/discount-codes');
  },

  async createDiscountCode(discount: any): Promise<DiscountCode> {
    return request('/admin/discount-codes', {
      method: 'POST',
      body: JSON.stringify(discount)
    });
  },

  // --- NOTIFICATIONS ---
  async getNotifications(userId?: string): Promise<InAppNotification[]> {
    const q = userId ? `?userId=${userId}` : '';
    return request(`/notifications${q}`);
  },

  async markNotificationRead(id: string): Promise<any> {
    return request(`/notifications/${id}/read`, {
      method: 'POST'
    });
  }
};
