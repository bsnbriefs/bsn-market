/**
 * BSN Market Type Definitions
 * Nigerian Multi-Vendor E-Commerce Marketplace
 */

export type UserRole = 'customer' | 'retailer' | 'admin';

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phoneNumber?: string;
  role: UserRole;
  avatarUrl?: string;
  createdAt: string;
}

export type RetailerStatus = 'pending_review' | 'approved' | 'rejected' | 'suspended';

export interface RetailerProfile {
  id: string;
  ownerId: string;
  businessName: string;
  businessSlug: string;
  cacRegNumber?: string;
  description: string;
  logoUrl?: string;
  bannerUrl?: string;
  phone: string;
  email: string;
  state: string;
  city: string;
  physicalAddress: string;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  status: RetailerStatus;
  commissionRateOverride?: number; // e.g., 8.0 for 8%
  rating: number;
  reviewCount: number;
  verifiedBadge: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RetailerApplication {
  id: string;
  userId: string;
  businessName: string;
  cacRegNumber?: string;
  contactPerson: string;
  email: string;
  phone: string;
  businessType: string;
  state: string;
  city: string;
  address: string;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  documentUrl?: string;
  status: RetailerStatus;
  rejectionReason?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  iconName?: string;
  displayOrder: number;
  isActive: boolean;
  defaultCommissionRate: number; // default 10%
  imageUrl?: string;
}

export type ProductStatus = 'draft' | 'under_review' | 'approved' | 'rejected' | 'archived';

export interface ProductVariant {
  id: string;
  productId: string;
  name: string; // e.g. "Size 42 / Black"
  sku?: string;
  priceKobo: number;
  stockQuantity: number;
}

export interface ProductReview {
  id: string;
  productId: string;
  customerId: string;
  customerName: string;
  rating: number; // 1 to 5
  title?: string;
  comment: string;
  isVerifiedPurchase: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  retailerId: string;
  retailerName: string;
  categoryId: string;
  categoryName: string;
  name: string;
  slug: string;
  description: string;
  sku?: string;
  priceKobo: number; // in Kobo (100 Kobo = 1 NGN)
  compareAtPriceKobo?: number; // genuine previous price
  stockQuantity: number;
  lowStockThreshold: number;
  images: string[];
  variants: ProductVariant[];
  status: ProductStatus;
  rejectionReason?: string;
  deliveryInfo: string;
  returnPolicy: string;
  weightKg?: number;
  isFeatured?: boolean;
  rating: number;
  reviewCount: number;
  reviews?: ProductReview[];
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  variantId?: string;
  variantName?: string;
  quantity: number;
  unitPriceKobo: number;
}

export type OrderStatus =
  | 'order_placed'
  | 'payment_confirmed'
  | 'retailer_confirmed'
  | 'processing'
  | 'dispatched'
  | 'delivered'
  | 'cancelled'
  | 'refund_requested'
  | 'refunded';

export type PaymentStatus =
  | 'pending'
  | 'successful'
  | 'failed'
  | 'abandoned'
  | 'refund_pending'
  | 'partially_refunded'
  | 'refunded';

export type SettlementStatus =
  | 'not_due'
  | 'pending'
  | 'processing'
  | 'settled'
  | 'failed'
  | 'reversed';

export type DeliveryMethod = 'standard' | 'express' | 'pickup';

export interface OrderItem {
  id: string;
  orderId: string;
  retailerOrderId: string;
  retailerId: string;
  productId: string;
  variantId?: string;
  productName: string;
  variantName?: string;
  productImage: string;
  unitPriceKobo: number;
  quantity: number;
  subtotalKobo: number;
}

export interface RetailerSubOrder {
  id: string;
  orderId: string;
  retailerId: string;
  retailerName: string;
  retailerOrderRef: string;
  subtotalKobo: number;
  deliveryFeeKobo: number;
  commissionRateSnapshot: number; // e.g. 10.0
  commissionAmountKobo: number;
  retailerPayableKobo: number;
  fulfilmentStatus: OrderStatus;
  rejectionReason?: string;
  courierName?: string;
  trackingReference?: string;
  settlementStatus: SettlementStatus;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: string;
  orderReference: string; // e.g. BSN-2026-8941
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  deliveryCity: string;
  deliveryState: string;
  deliveryInstructions?: string;
  deliveryMethod: DeliveryMethod;
  subtotalKobo: number;
  deliveryFeeKobo: number;
  discountKobo: number;
  totalKobo: number;
  amountRefundedKobo: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentReference?: string;
  appliedDiscountCode?: string;
  retailerOrders: RetailerSubOrder[];
  items: OrderItem[];
  timeline: {
    status: OrderStatus;
    title: string;
    description: string;
    timestamp: string;
    actor?: string;
  }[];
  createdAt: string;
  updatedAt: string;
}

export interface PaymentRecord {
  id: string;
  orderId: string;
  orderReference: string;
  provider: 'paystack' | 'flutterwave';
  reference: string;
  accessCode?: string;
  amountKobo: number;
  currency: string;
  status: PaymentStatus;
  channel?: string;
  paidAt?: string;
  verifiedAt?: string;
  createdAt: string;
}

export interface RetailerSettlement {
  id: string;
  settlementReference: string;
  retailerId: string;
  retailerName: string;
  bankName: string;
  bankAccountNumber: string;
  bankAccountName: string;
  grossSalesKobo: number;
  commissionDeductionsKobo: number;
  netPayableKobo: number;
  status: SettlementStatus;
  bankTransferReference?: string;
  transferredAt?: string;
  orderReferences: string[];
  notes?: string;
  createdAt: string;
}

export interface DiscountCode {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed_kobo';
  value: number; // 10 = 10% or kobo
  minOrderKobo: number;
  maxDiscountKobo?: number;
  usageLimit?: number;
  usedCount: number;
  isActive: boolean;
  expiresAt?: string;
}

export interface InAppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'payment' | 'application' | 'system';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  actorId: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  entityType: string;
  entityId: string;
  details?: Record<string, unknown>;
  ipAddress?: string;
  createdAt: string;
}

export interface PlatformMetrics {
  gmvKobo: number;
  platformNetRevenueKobo: number; // Commission earned
  retailerPayableKobo: number; // Due to retailers
  totalRefundsKobo: number;
  totalOrdersCount: number;
  completedOrdersCount: number;
  pendingOrdersCount: number;
  activeRetailersCount: number;
  pendingApplicationsCount: number;
  productsAwaitingReviewCount: number;
}

export interface RetailerStats {
  retailerId: string;
  totalOrdersCount: number;
  awaitingConfirmationCount: number;
  processingCount: number;
  completedCount: number;
  grossSalesKobo: number;
  commissionDeductionsKobo: number;
  netPayableKobo: number;
  settledKobo: number;
  pendingSettlementKobo: number;
  lowStockItemsCount: number;
}
