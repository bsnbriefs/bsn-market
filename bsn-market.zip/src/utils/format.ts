/**
 * Currency & Formatting Utilities for BSN Market (Nigerian Naira NGN)
 */

export function formatNaira(kobo: number): string {
  if (kobo === undefined || kobo === null || isNaN(kobo)) return '₦0';
  const naira = Math.floor(kobo / 100);
  return `₦${naira.toLocaleString('en-NG')}`;
}

export function formatDate(isoString: string): string {
  if (!isoString) return '';
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-NG', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return isoString;
  }
}

export function formatShortDate(isoString: string): string {
  if (!isoString) return '';
  try {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-NG', {
      day: 'numeric',
      month: 'short'
    });
  } catch {
    return isoString;
  }
}

export const NIGERIAN_STATES = [
  'Lagos',
  'Abuja FCT',
  'Rivers',
  'Oyo',
  'Kano',
  'Anambra',
  'Enugu',
  'Delta',
  'Edo',
  'Kaduna',
  'Ogun',
  'Ondo',
  'Osun',
  'Kwara',
  'Imo',
  'Abia',
  'Akwa Ibom',
  'Plateau',
  'Cross River',
  'Benue'
];

export const STATUS_CONFIG: Record<
  string,
  { label: string; bg: string; text: string; border: string }
> = {
  order_placed: {
    label: 'Order Placed',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200'
  },
  payment_confirmed: {
    label: 'Payment Confirmed',
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    border: 'border-blue-200'
  },
  retailer_confirmed: {
    label: 'Retailer Confirmed',
    bg: 'bg-indigo-50',
    text: 'text-indigo-700',
    border: 'border-indigo-200'
  },
  processing: {
    label: 'Processing',
    bg: 'bg-purple-50',
    text: 'text-purple-700',
    border: 'border-purple-200'
  },
  dispatched: {
    label: 'Dispatched',
    bg: 'bg-cyan-50',
    text: 'text-cyan-700',
    border: 'border-cyan-200'
  },
  delivered: {
    label: 'Delivered',
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200'
  },
  cancelled: {
    label: 'Cancelled',
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    border: 'border-rose-200'
  },
  refund_requested: {
    label: 'Refund Requested',
    bg: 'bg-orange-50',
    text: 'text-orange-700',
    border: 'border-orange-200'
  },
  refunded: {
    label: 'Refunded',
    bg: 'bg-slate-50',
    text: 'text-slate-700',
    border: 'border-slate-200'
  },
  // Retailer statuses
  approved: {
    label: 'Approved',
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200'
  },
  pending_review: {
    label: 'Under Review',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200'
  },
  rejected: {
    label: 'Rejected',
    bg: 'bg-rose-50',
    text: 'text-rose-700',
    border: 'border-rose-200'
  },
  suspended: {
    label: 'Suspended',
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-300'
  },
  // Product status
  under_review: {
    label: 'Under Moderation',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200'
  },
  // Settlement status
  not_due: {
    label: 'Not Due',
    bg: 'bg-slate-50',
    text: 'text-slate-600',
    border: 'border-slate-200'
  },
  pending: {
    label: 'Pending Payout',
    bg: 'bg-amber-50',
    text: 'text-amber-700',
    border: 'border-amber-200'
  },
  settled: {
    label: 'Settled',
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-200'
  }
};
