-- BSN Market PostgreSQL Database Schema & Row Level Security Policies
-- Barrister Street Network (BSN) Multi-Vendor Marketplace

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. ENUMS & TYPES
CREATE TYPE user_role_type AS ENUM ('customer', 'retailer', 'admin');
CREATE TYPE retailer_status_type AS ENUM ('pending_review', 'approved', 'rejected', 'suspended');
CREATE TYPE product_status_type AS ENUM ('draft', 'under_review', 'approved', 'rejected', 'archived');
CREATE TYPE order_status_type AS ENUM (
  'order_placed',
  'payment_confirmed',
  'retailer_confirmed',
  'processing',
  'dispatched',
  'delivered',
  'cancelled',
  'refund_requested',
  'refunded'
);
CREATE TYPE payment_status_type AS ENUM (
  'pending',
  'successful',
  'failed',
  'abandoned',
  'refund_pending',
  'partially_refunded',
  'refunded'
);
CREATE TYPE settlement_status_type AS ENUM (
  'not_due',
  'pending',
  'processing',
  'settled',
  'failed',
  'reversed'
);
CREATE TYPE delivery_method_type AS ENUM ('standard', 'express', 'pickup');

-- 2. USER PROFILES
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  auth_user_id UUID UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone_number TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. USER ROLES
CREATE TABLE IF NOT EXISTS user_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  role user_role_type NOT NULL DEFAULT 'customer',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, role)
);

-- 4. RETAILER PROFILES
CREATE TABLE IF NOT EXISTS retailer_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id UUID REFERENCES profiles(id) ON DELETE RESTRICT,
  business_name TEXT NOT NULL,
  business_slug TEXT UNIQUE NOT NULL,
  cac_reg_number TEXT,
  description TEXT,
  logo_url TEXT,
  banner_url TEXT,
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  state TEXT NOT NULL,
  city TEXT NOT NULL,
  physical_address TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  bank_account_number TEXT NOT NULL,
  bank_account_name TEXT NOT NULL,
  bank_code TEXT,
  status retailer_status_type NOT NULL DEFAULT 'pending_review',
  commission_rate_override NUMERIC(5, 2), -- e.g. 8.5%
  rating NUMERIC(3, 2) DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  verified_badge BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. RETAILER APPLICATIONS
CREATE TABLE IF NOT EXISTS retailer_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  cac_reg_number TEXT,
  contact_person TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  business_type TEXT NOT NULL,
  state TEXT NOT NULL,
  city TEXT NOT NULL,
  address TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  bank_account_number TEXT NOT NULL,
  bank_account_name TEXT NOT NULL,
  document_url TEXT,
  status retailer_status_type NOT NULL DEFAULT 'pending_review',
  rejection_reason TEXT,
  reviewed_by UUID REFERENCES profiles(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. CATEGORIES
CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  icon_name TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  default_commission_rate NUMERIC(5, 2) DEFAULT 10.00, -- 10%
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. PRODUCTS
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  retailer_id UUID REFERENCES retailer_profiles(id) ON DELETE CASCADE,
  category_id UUID REFERENCES categories(id) ON DELETE RESTRICT,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT NOT NULL,
  sku TEXT,
  price_kobo BIGINT NOT NULL CHECK (price_kobo >= 0), -- Stored in kobo (100 kobo = 1 NGN)
  compare_at_price_kobo BIGINT CHECK (compare_at_price_kobo >= price_kobo),
  stock_quantity INTEGER NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
  low_stock_threshold INTEGER DEFAULT 5,
  images JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array of image URLs
  status product_status_type NOT NULL DEFAULT 'draft',
  rejection_reason TEXT,
  delivery_info TEXT,
  return_policy TEXT,
  weight_kg NUMERIC(6, 2),
  is_featured BOOLEAN DEFAULT FALSE,
  rating NUMERIC(3, 2) DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. PRODUCT VARIANTS
CREATE TABLE IF NOT EXISTS product_variants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  name TEXT NOT NULL, -- e.g. "Size 42 - Black"
  variant_sku TEXT,
  price_kobo BIGINT NOT NULL,
  stock_quantity INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. INVENTORY MOVEMENTS
CREATE TABLE IF NOT EXISTS inventory_movements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  variant_id UUID REFERENCES product_variants(id) ON DELETE SET NULL,
  quantity_change INTEGER NOT NULL, -- negative for sales, positive for restock
  reason TEXT NOT NULL, -- 'sale', 'restock', 'return', 'adjustment'
  reference_order_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. CARTS & CART ITEMS
CREATE TABLE IF NOT EXISTS carts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  session_token TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cart_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cart_id UUID REFERENCES carts(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  variant_id UUID REFERENCES product_variants(id) ON DELETE SET NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(cart_id, product_id, variant_id)
);

-- 11. DISCOUNT CODES
CREATE TABLE IF NOT EXISTS discount_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  discount_type TEXT NOT NULL, -- 'percentage' or 'fixed_kobo'
  value NUMERIC(10, 2) NOT NULL,
  min_order_kobo BIGINT DEFAULT 0,
  max_discount_kobo BIGINT,
  usage_limit INTEGER,
  used_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 12. ORDERS & ORDER ITEMS
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_reference TEXT UNIQUE NOT NULL, -- e.g. BSN-2026-8941
  customer_id UUID REFERENCES profiles(id) ON DELETE RESTRICT,
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  
  -- Delivery Address
  delivery_address TEXT NOT NULL,
  delivery_city TEXT NOT NULL,
  delivery_state TEXT NOT NULL,
  delivery_instructions TEXT,
  delivery_method delivery_method_type NOT NULL DEFAULT 'standard',
  
  -- Financial Snapshot in Kobo
  subtotal_kobo BIGINT NOT NULL,
  delivery_fee_kobo BIGINT NOT NULL,
  discount_kobo BIGINT DEFAULT 0,
  total_kobo BIGINT NOT NULL,
  amount_refunded_kobo BIGINT DEFAULT 0,
  
  -- Order Status
  status order_status_type NOT NULL DEFAULT 'order_placed',
  payment_status payment_status_type NOT NULL DEFAULT 'pending',
  
  applied_discount_code TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- RETAILER FULFILMENT SUB-ORDERS (Multi-Vendor Architecture)
CREATE TABLE IF NOT EXISTS retailer_orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  retailer_id UUID REFERENCES retailer_profiles(id) ON DELETE RESTRICT,
  retailer_order_ref TEXT NOT NULL,
  subtotal_kobo BIGINT NOT NULL,
  delivery_fee_kobo BIGINT NOT NULL,
  commission_rate_snapshot NUMERIC(5, 2) NOT NULL,
  commission_amount_kobo BIGINT NOT NULL,
  retailer_payable_kobo BIGINT NOT NULL,
  fulfilment_status order_status_type NOT NULL DEFAULT 'order_placed',
  rejection_reason TEXT,
  courier_name TEXT,
  tracking_reference TEXT,
  settlement_status settlement_status_type NOT NULL DEFAULT 'not_due',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  retailer_order_id UUID REFERENCES retailer_orders(id) ON DELETE CASCADE,
  retailer_id UUID REFERENCES retailer_profiles(id) ON DELETE RESTRICT,
  product_id UUID REFERENCES products(id) ON DELETE RESTRICT,
  variant_id UUID REFERENCES product_variants(id) ON DELETE SET NULL,
  product_name TEXT NOT NULL,
  variant_name TEXT,
  product_image TEXT,
  unit_price_kobo BIGINT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  subtotal_kobo BIGINT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. PAYMENTS & AUDIT EVENTS
CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  provider TEXT NOT NULL DEFAULT 'paystack',
  reference TEXT UNIQUE NOT NULL,
  access_code TEXT,
  amount_kobo BIGINT NOT NULL,
  currency TEXT NOT NULL DEFAULT 'NGN',
  status payment_status_type NOT NULL DEFAULT 'pending',
  gateway_response TEXT,
  paystack_transaction_id TEXT,
  channel TEXT,
  paid_at TIMESTAMPTZ,
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payment_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  payment_id UUID REFERENCES payments(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  idempotency_key TEXT UNIQUE,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. SETTLEMENTS & COMMISSIONS
CREATE TABLE IF NOT EXISTS retailer_settlements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  settlement_reference TEXT UNIQUE NOT NULL,
  retailer_id UUID REFERENCES retailer_profiles(id) ON DELETE RESTRICT,
  gross_sales_kobo BIGINT NOT NULL,
  commission_deductions_kobo BIGINT NOT NULL,
  net_payable_kobo BIGINT NOT NULL,
  status settlement_status_type NOT NULL DEFAULT 'pending',
  bank_reference TEXT,
  transferred_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS settlement_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  settlement_id UUID REFERENCES retailer_settlements(id) ON DELETE CASCADE,
  retailer_order_id UUID REFERENCES retailer_orders(id) ON DELETE RESTRICT,
  order_reference TEXT NOT NULL,
  amount_kobo BIGINT NOT NULL
);

-- 15. DELIVERIES
CREATE TABLE IF NOT EXISTS deliveries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  retailer_order_id UUID REFERENCES retailer_orders(id) ON DELETE CASCADE,
  carrier TEXT,
  tracking_code TEXT,
  pickup_address TEXT,
  recipient_address TEXT NOT NULL,
  recipient_phone TEXT NOT NULL,
  estimated_delivery_date TIMESTAMPTZ,
  actual_delivery_date TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 16. REVIEWS
CREATE TABLE IF NOT EXISTS product_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title TEXT,
  comment TEXT NOT NULL,
  is_verified_purchase BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 17. NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL, -- 'order', 'payment', 'application', 'system'
  link TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 18. AUDIT LOGS
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  actor_id UUID REFERENCES profiles(id),
  actor_email TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL, -- e.g. 'retailer.approved', 'commission.updated'
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  details JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 19. INDEXES FOR PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_retailer ON products(retailer_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_ref ON orders(order_reference);
CREATE INDEX IF NOT EXISTS idx_retailer_orders_retailer ON retailer_orders(retailer_id);
CREATE INDEX IF NOT EXISTS idx_payments_ref ON payments(reference);

-- 20. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE retailer_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE retailer_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper functions for RLS
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid() AND role = 'admin'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION is_retailer_owner(retailer_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM retailer_profiles
    WHERE id = retailer_id AND owner_id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles: Users can read and update their own profile; admins can read all
CREATE POLICY profiles_select ON profiles FOR SELECT USING (id = auth.uid() OR is_admin());
CREATE POLICY profiles_update ON profiles FOR UPDATE USING (id = auth.uid());

-- Products: Everyone can read approved products; retailers can manage their own; admins can manage all
CREATE POLICY products_public_select ON products FOR SELECT USING (status = 'approved' OR is_retailer_owner(retailer_id) OR is_admin());
CREATE POLICY products_retailer_insert ON products FOR INSERT WITH CHECK (is_retailer_owner(retailer_id) OR is_admin());
CREATE POLICY products_retailer_update ON products FOR UPDATE USING (is_retailer_owner(retailer_id) OR is_admin());

-- Orders: Customers can see their own orders; admins can see all
CREATE POLICY orders_customer_select ON orders FOR SELECT USING (customer_id = auth.uid() OR is_admin());

-- Retailer Orders: Retailers can only view and update their own sub-orders
CREATE POLICY retailer_orders_select ON retailer_orders FOR SELECT USING (is_retailer_owner(retailer_id) OR is_admin());
CREATE POLICY retailer_orders_update ON retailer_orders FOR UPDATE USING (is_retailer_owner(retailer_id) OR is_admin());

-- Notifications: Users only see their own notifications
CREATE POLICY notifications_select ON notifications FOR SELECT USING (user_id = auth.uid());
